--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.welcomechannel DROP CONSTRAINT welcomechannelfkchanneldata;
ALTER TABLE ONLY public.vouchervalidproduct DROP CONSTRAINT vouchervalidproductfkvoucher;
ALTER TABLE ONLY public.vouchervalidproduct DROP CONSTRAINT vouchervalidproductfkproduct;
ALTER TABLE ONLY public.vouchervalidpackage DROP CONSTRAINT vouchervalidpackagefkvoucher;
ALTER TABLE ONLY public.vouchervalidpackage DROP CONSTRAINT vouchervalidpackagefkbasicpackage;
ALTER TABLE ONLY public.videoserverwowza DROP CONSTRAINT videoserverwowzafkvideoserver;
ALTER TABLE ONLY public.videoservervodkatickets DROP CONSTRAINT videoservervodkaticketsfkvideoserver;
ALTER TABLE ONLY public.videoserverswisstv DROP CONSTRAINT videoserverswisstvfkvideoserver;
ALTER TABLE ONLY public.videoservergroupchanneldataplayinfo DROP CONSTRAINT videoservergroupfk;
ALTER TABLE ONLY public.videoservergroupvideoserver DROP CONSTRAINT videoservergroupfk;
ALTER TABLE ONLY public.videoserverstatus DROP CONSTRAINT videoserverfkvideoserverstatus;
ALTER TABLE ONLY public.videoservergroupvideoserver DROP CONSTRAINT videoserverfk;
ALTER TABLE ONLY public.videoserverdevicetype DROP CONSTRAINT videoserverdevicetypefkvideoserver;
ALTER TABLE ONLY public.videoserverdevicetype DROP CONSTRAINT videoserverdevicetypefkdevicetype;
ALTER TABLE ONLY public.videoservercontent DROP CONSTRAINT videoservercontentfkvideoserver;
ALTER TABLE ONLY public.videoserverstreamstatus DROP CONSTRAINT videoserverchannelstatusfkvideoserverstatus;
ALTER TABLE ONLY public.videoserveraction DROP CONSTRAINT videoserveractionfkvideoserver;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT userrolesfk;
ALTER TABLE ONLY public.desktopitem DROP CONSTRAINT userdesktopfkdesktopitem;
ALTER TABLE ONLY public.userdesktop DROP CONSTRAINT userdesktopfkdesktop;
ALTER TABLE ONLY public.userdesktop DROP CONSTRAINT userdesktopfkaccount;
ALTER TABLE ONLY public.stbtagtreenode DROP CONSTRAINT treeidfkstbtagtreenode;
ALTER TABLE ONLY public.desktopitem DROP CONSTRAINT titlei18nfk;
ALTER TABLE ONLY public.timezone DROP CONSTRAINT tagtreenodeidfkstbtagtreenode;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT tagtreenodefkbasicpackage;
ALTER TABLE ONLY public.systemapplication DROP CONSTRAINT systemapplicationfkdeviceclass;
ALTER TABLE ONLY public.subscriptiondependencies DROP CONSTRAINT subscriptiondependenciesproductfk;
ALTER TABLE ONLY public.subscriptiondependencies DROP CONSTRAINT subscriptiondependenciespackagefk;
ALTER TABLE ONLY public.subscriptioncatalog DROP CONSTRAINT subscriptioncatalogproductfk;
ALTER TABLE ONLY public.subscriptioncatalog DROP CONSTRAINT subscriptioncatalogpackagefk;
ALTER TABLE ONLY public.stbupgrade DROP CONSTRAINT stbupgradefkstb;
ALTER TABLE ONLY public.stbupgrade DROP CONSTRAINT stbupgradefkfirmware;
ALTER TABLE ONLY public.pluginscreen DROP CONSTRAINT stbtypefkpluginscreen;
ALTER TABLE ONLY public.pluginconfigurationstart DROP CONSTRAINT stbtypefkpluginconfigurationstart;
ALTER TABLE ONLY public.stbstatusstorage DROP CONSTRAINT stbstatusstoragefkstbstatus;
ALTER TABLE ONLY public.stbstatus DROP CONSTRAINT stbstatusfkstb;
ALTER TABLE ONLY public.mappingscreenconfiguration DROP CONSTRAINT stbmappingscreenconfigurationfkchanneldata;
ALTER TABLE ONLY public.itemmappingscreen DROP CONSTRAINT stbitemmappingscreenfkchanneldata;
ALTER TABLE ONLY public.stbsession DROP CONSTRAINT stbfkstbsession;
ALTER TABLE ONLY public.accountpreference DROP CONSTRAINT stbfkstbpreference;
ALTER TABLE ONLY public.stbinformationscreen DROP CONSTRAINT stbfkstbinformationscreen;
ALTER TABLE ONLY public.rule DROP CONSTRAINT stbfkrule;
ALTER TABLE ONLY public.rent DROP CONSTRAINT stbfkrent;
ALTER TABLE ONLY public.channelvisibility DROP CONSTRAINT stbfkchannelvisibility;
ALTER TABLE ONLY public.channelnumber DROP CONSTRAINT stbfkchannelnumber;
ALTER TABLE ONLY public.device DROP CONSTRAINT stb_stbtagtreenodeid_fkey;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT shortdescriptioni18nfk;
ALTER TABLE ONLY public.sessionaccounting DROP CONSTRAINT sessionaccountingfkroom;
ALTER TABLE ONLY public.screensaver DROP CONSTRAINT screensaveri18nfk;
ALTER TABLE ONLY public.schedulelink DROP CONSTRAINT schedulelinkfki18n;
ALTER TABLE ONLY public.rule DROP CONSTRAINT rulescollectionfkrule;
ALTER TABLE ONLY public.rule DROP CONSTRAINT rulefkroom;
ALTER TABLE ONLY public.rent DROP CONSTRAINT rulefkrent;
ALTER TABLE ONLY public.periodicity DROP CONSTRAINT rulefkperiodicity;
ALTER TABLE ONLY public.collectionrule DROP CONSTRAINT rulefkcollectionrule;
ALTER TABLE ONLY public.rss DROP CONSTRAINT rssfki18n;
ALTER TABLE ONLY public.room DROP CONSTRAINT roomfktagtreenode;
ALTER TABLE ONLY public.device DROP CONSTRAINT roomfkstb;
ALTER TABLE ONLY public.rolemenuoption DROP CONSTRAINT rolefk;
ALTER TABLE ONLY public.roleattribute DROP CONSTRAINT roleattributefkrole;
ALTER TABLE ONLY public.roleassetcollection DROP CONSTRAINT roleassetcollectionfkroleassetcollectioncontent;
ALTER TABLE ONLY public.roleassetcollection DROP CONSTRAINT roleassetcollectionfkrole;
ALTER TABLE ONLY public.visualization DROP CONSTRAINT rentfkvisualization;
ALTER TABLE ONLY public.rent DROP CONSTRAINT rentfksessionaccounting;
ALTER TABLE ONLY public.pvrtask DROP CONSTRAINT pvrtaskfkstb;
ALTER TABLE ONLY public.pvrtask DROP CONSTRAINT pvrtaskfkchanneldata;
ALTER TABLE ONLY public.pvrtask DROP CONSTRAINT pvrtaskfkaccount;
ALTER TABLE ONLY public.purchase DROP CONSTRAINT purchasesessionaccountingfk;
ALTER TABLE ONLY public.purchase DROP CONSTRAINT purchaseproductfk;
ALTER TABLE ONLY public.purchase DROP CONSTRAINT purchasefkvoucher;
ALTER TABLE ONLY public.product DROP CONSTRAINT productstbtagtreenodefk;
ALTER TABLE ONLY public.product DROP CONSTRAINT productproductshortdesci18nfk;
ALTER TABLE ONLY public.product DROP CONSTRAINT productproductnamei18nfk;
ALTER TABLE ONLY public.product DROP CONSTRAINT productproductdesci18nfk;
ALTER TABLE ONLY public.product DROP CONSTRAINT productlogofk;
ALTER TABLE ONLY public.productitemuserserviceid DROP CONSTRAINT productitemuserserviceidfkuserservice;
ALTER TABLE ONLY public.productitemuserserviceid DROP CONSTRAINT productitemuserserviceidfkproductitem;
ALTER TABLE ONLY public.productitem DROP CONSTRAINT productitemproductfk;
ALTER TABLE ONLY public.productitempluginid DROP CONSTRAINT productitempluginidproductitemfk;
ALTER TABLE ONLY public.productitempluginid DROP CONSTRAINT productitempluginidpluginconfigurationfk;
ALTER TABLE ONLY public.productitemdeviceclassid DROP CONSTRAINT productitemdeviceclassidfkproductitem;
ALTER TABLE ONLY public.productitemdeviceclassid DROP CONSTRAINT productitemdeviceclassidfkdeviceclass;
ALTER TABLE ONLY public.productitemconcurrentusers DROP CONSTRAINT productitemconcurrentusersfkproductitem;
ALTER TABLE ONLY public.productitemconcurrentusers DROP CONSTRAINT productitemconcurrentusersfkdeviceclass;
ALTER TABLE ONLY public.productitemchannelid DROP CONSTRAINT productitemchannelidproductitemfk;
ALTER TABLE ONLY public.productitemchannelid DROP CONSTRAINT productitemchannelidfkchanneldata;
ALTER TABLE ONLY public.productitemchannelcategory DROP CONSTRAINT productitemchannelcategoryproductitemfk;
ALTER TABLE ONLY public.productitemchannelcategory DROP CONSTRAINT productitemchannelcategorycontentcategoryfk;
ALTER TABLE ONLY public.productitemappid DROP CONSTRAINT productitemappidproductitemfk;
ALTER TABLE ONLY public.productitemappid DROP CONSTRAINT productitemappidpluginconfigurationfk;
ALTER TABLE ONLY public.productitemallplugins DROP CONSTRAINT productitemallpluginsproductitemfk;
ALTER TABLE ONLY public.productitemalldeviceclasses DROP CONSTRAINT productitemalldeviceclassesfkproductitem;
ALTER TABLE ONLY public.productitemallchannels DROP CONSTRAINT productitemallchannelsproductitemfk;
ALTER TABLE ONLY public.productitemallapps DROP CONSTRAINT productitemallappsproductitemfk;
ALTER TABLE ONLY public.product DROP CONSTRAINT productimagefk;
ALTER TABLE ONLY public.productincluded DROP CONSTRAINT productfkproductincluded;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_currencyid_fkey;
ALTER TABLE ONLY public.pluginscreen DROP CONSTRAINT pluginconfigurationfkpluginscreen;
ALTER TABLE ONLY public.pluginconfigurationstart DROP CONSTRAINT pluginconfigurationfkpluginconfigurationstart;
ALTER TABLE ONLY public.desktopitemplugin DROP CONSTRAINT pluginconfigurationfkdesktopitemplugin;
ALTER TABLE ONLY public.plugin_webbrows_stburlitemlang DROP CONSTRAINT plugin_webbrows_stburlitemidfk;
ALTER TABLE ONLY public.plugin_webbrows_stburlitem DROP CONSTRAINT plugin_webbrows_stbfkstburlitem;
ALTER TABLE ONLY public.playlistmappingscreen DROP CONSTRAINT playlistmappingscreenfkroom;
ALTER TABLE ONLY public.itemmappingscreen DROP CONSTRAINT playlistmappingscreenfkitemmappingscreen;
ALTER TABLE ONLY public.stbtagtreenode DROP CONSTRAINT parentidfkstbtagtreenode;
ALTER TABLE ONLY public.parentalratingmapping DROP CONSTRAINT parentalratingmappingfkparentalrating;
ALTER TABLE ONLY public.parentalcontrollevel DROP CONSTRAINT parentalcontrollevelfkaccount;
ALTER TABLE ONLY public.productincluded DROP CONSTRAINT packagefkproductincluded;
ALTER TABLE ONLY public.outputsprotection DROP CONSTRAINT outputsprotectionfkaccount;
ALTER TABLE ONLY public.networkareaipv4subnet DROP CONSTRAINT networkareaipv4subnetfknetworkarea;
ALTER TABLE ONLY public.videoserver DROP CONSTRAINT networkareafkvideoserver;
ALTER TABLE ONLY public.networkareacountry DROP CONSTRAINT networkareacountryfknetworkarea;
ALTER TABLE ONLY public.messagewakeup DROP CONSTRAINT messagewakeupmessagefk;
ALTER TABLE ONLY public.messagescript DROP CONSTRAINT messagescriptmessagefk;
ALTER TABLE ONLY public.messagepopup DROP CONSTRAINT messagepopupmessagefk;
ALTER TABLE ONLY public.messagemail DROP CONSTRAINT messagemailmessagefk;
ALTER TABLE ONLY public.message DROP CONSTRAINT messagedeviceidfk;
ALTER TABLE ONLY public.message DROP CONSTRAINT messageaccountidfk;
ALTER TABLE ONLY public.menuoption DROP CONSTRAINT menuoptionlabeli18nfki18n;
ALTER TABLE ONLY public.menuoption DROP CONSTRAINT menuoptionhelpmessagei18nfki18n;
ALTER TABLE ONLY public.menuoption DROP CONSTRAINT menuoptionfkmenuoption;
ALTER TABLE ONLY public.logging_event_property DROP CONSTRAINT logging_event_property_event_id_fkey;
ALTER TABLE ONLY public.logging_event_exception DROP CONSTRAINT logging_event_exception_event_id_fkey;
ALTER TABLE ONLY public.filterlistconfiguration DROP CONSTRAINT listconfigurationfkfilterlistconfiguration;
ALTER TABLE ONLY public.listconfigurationasset DROP CONSTRAINT listconfigurationassetfklistconfiguration;
ALTER TABLE ONLY public.link DROP CONSTRAINT linkfki18n;
ALTER TABLE ONLY public.language DROP CONSTRAINT languagei18nfk;
ALTER TABLE ONLY public.incompatibleproduct DROP CONSTRAINT incompatibleproductproductfk;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT i18nfkbasicpackage;
ALTER TABLE ONLY public.guestservices DROP CONSTRAINT guestservicesimagefk;
ALTER TABLE ONLY public.guest DROP CONSTRAINT guestfksessionaccounting;
ALTER TABLE ONLY public.channeldataplayinfo DROP CONSTRAINT fk_channeldataplayinfo_devicetypeid;
ALTER TABLE ONLY public.favoritechannel DROP CONSTRAINT favoritechannelfkchanneldata;
ALTER TABLE ONLY public.favoritechannel DROP CONSTRAINT favoritechannelfkaccount;
ALTER TABLE ONLY public.emailtemplate DROP CONSTRAINT emailtemplatesubjectfki18n;
ALTER TABLE ONLY public.emailtemplate DROP CONSTRAINT emailtemplatecontentfki18n;
ALTER TABLE ONLY public.devicetype DROP CONSTRAINT devicetypedeviceclassfk;
ALTER TABLE ONLY public.devicestatuseventsserver DROP CONSTRAINT devicestatuseventsserverfkdevice;
ALTER TABLE ONLY public.devicestatuseventsserver DROP CONSTRAINT devicestatuseventsserverfkauthtoken;
ALTER TABLE ONLY public.device DROP CONSTRAINT deviceclassfkdevice;
ALTER TABLE ONLY public.desktopitemmedia DROP CONSTRAINT desktopitemwidgetfkchanneldata;
ALTER TABLE ONLY public.desktopitemwidget DROP CONSTRAINT desktopitemfkdesktopitemwidget;
ALTER TABLE ONLY public.desktopitemweb DROP CONSTRAINT desktopitemfkdesktopitemweb;
ALTER TABLE ONLY public.desktopitemplugin DROP CONSTRAINT desktopitemfkdesktopitemplugin;
ALTER TABLE ONLY public.desktopitemmedia DROP CONSTRAINT desktopitemfkdesktopitemmedia;
ALTER TABLE ONLY public.desktopitemapp DROP CONSTRAINT desktopitemfkdesktopitemapp;
ALTER TABLE ONLY public.desktopitem DROP CONSTRAINT desktopfkdesktopitem;
ALTER TABLE ONLY public.desktopconfigdesktop DROP CONSTRAINT desktopfkdesktopconfigdesktop;
ALTER TABLE ONLY public.desktoparea DROP CONSTRAINT desktopfkdesktoparea;
ALTER TABLE ONLY public.desktopconfigdesktop DROP CONSTRAINT desktopconfigfkdesktopconfigdesktop;
ALTER TABLE ONLY public.desktoparea DROP CONSTRAINT desktopareatexti18nfk;
ALTER TABLE ONLY public.desktoparea DROP CONSTRAINT desktopareabackgroundi18nfk;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT descriptioni18nfk;
ALTER TABLE ONLY public.defaultbasicpackage DROP CONSTRAINT defaultbasicpackagefktagtreenode;
ALTER TABLE ONLY public.defaultbasicpackage DROP CONSTRAINT defaultbasicpackagefkbasicpackage;
ALTER TABLE ONLY public.customizationpath DROP CONSTRAINT customizationpathfkdeviceclass;
ALTER TABLE ONLY public.customizationpath DROP CONSTRAINT customizationpathfkcustomization;
ALTER TABLE ONLY public.customization DROP CONSTRAINT customizationimagefk;
ALTER TABLE ONLY public.customization DROP CONSTRAINT customizationfksystemapplication;
ALTER TABLE ONLY public.customization DROP CONSTRAINT customizationfkdeviceclass;
ALTER TABLE ONLY public.customizationsystemapplication DROP CONSTRAINT customizationapplicationfksystemapplication;
ALTER TABLE ONLY public.customizationsystemapplication DROP CONSTRAINT customizationapplicationfkcustomization;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT currencyfkbasicpackage;
ALTER TABLE ONLY public.account DROP CONSTRAINT creditfkaccount;
ALTER TABLE ONLY public.channelcategory DROP CONSTRAINT contentcategorychannelcategory;
ALTER TABLE ONLY public.channelaudiopid DROP CONSTRAINT codecfkcodec;
ALTER TABLE ONLY public.channelvideopid DROP CONSTRAINT codecfkcodec;
ALTER TABLE ONLY public.channelvisibility DROP CONSTRAINT channelvisibilityfkchanneldata;
ALTER TABLE ONLY public.channelvideopid DROP CONSTRAINT channelvideopidfkchanneldataplayinfoid;
ALTER TABLE ONLY public.channelsourceuri DROP CONSTRAINT channelsourceuripkchanneldataplayinfoid;
ALTER TABLE ONLY public.channelnumber DROP CONSTRAINT channelnumberfkchanneldata;
ALTER TABLE ONLY public.channelaccessarea DROP CONSTRAINT channelnetworkareafknetworkarea;
ALTER TABLE ONLY public.stbtagtreenodechannellist DROP CONSTRAINT channellisttagfkstbtagtreenodeid;
ALTER TABLE ONLY public.stbtagtreenodechannellist DROP CONSTRAINT channellisttagfkchannellistid;
ALTER TABLE ONLY public.channellistitem DROP CONSTRAINT channellistitemfkchanneldata;
ALTER TABLE ONLY public.channellistitem DROP CONSTRAINT channellistidfkchannellistitem;
ALTER TABLE ONLY public.channeldataplayinfo DROP CONSTRAINT channeldataplayinfofkchanneldata;
ALTER TABLE ONLY public.videoservergroupchanneldataplayinfo DROP CONSTRAINT channeldataplayinfofk;
ALTER TABLE ONLY public.channeldata DROP CONSTRAINT channeldatafkparentalrating;
ALTER TABLE ONLY public.channelcategory DROP CONSTRAINT channelcategoryfkchanneldata;
ALTER TABLE ONLY public.channelaudiopid DROP CONSTRAINT channelaudiopidfkchanneldataplayinfoid;
ALTER TABLE ONLY public.channelaccesstypesubscription DROP CONSTRAINT channelaccesstypesubscriptionfkaccount;
ALTER TABLE ONLY public.channelaccessarea DROP CONSTRAINT channelaccessareafktagtreenode;
ALTER TABLE ONLY public.channelaccessarea DROP CONSTRAINT channelaccessareafkchanneldata;
ALTER TABLE ONLY public.rule DROP CONSTRAINT categoryfkrule;
ALTER TABLE ONLY public.catalogtreenoderole DROP CONSTRAINT catalogtreenoderolefkcatalogtreenode;
ALTER TABLE ONLY public.catalogtreenoderole DROP CONSTRAINT catalogtreenoderolefkaccountrole;
ALTER TABLE ONLY public.catalogtreenodeproperty DROP CONSTRAINT catalogtreenodepropertyfkcatalogtreenode;
ALTER TABLE ONLY public.catalogtreenodename DROP CONSTRAINT catalogtreenodefkcatalogtreenodename;
ALTER TABLE ONLY public.catalogtreenode DROP CONSTRAINT catalogtreenodefkcatalogtreenode;
ALTER TABLE ONLY public.catalogtreenodeasset DROP CONSTRAINT catalogtreenodeassetfkcatalogtreenode;
ALTER TABLE ONLY public.catalogtreenode DROP CONSTRAINT catalogtreefkcatalogtreenode;
ALTER TABLE ONLY public.billing DROP CONSTRAINT billingsessionaccountingfk;
ALTER TABLE ONLY public.billing DROP CONSTRAINT billingpurchasefk;
ALTER TABLE ONLY public.billing DROP CONSTRAINT billingfkcurrency;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT basicpackagelogofk;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT basicpackageimagefk;
ALTER TABLE ONLY public.purchase DROP CONSTRAINT basicpackagefkpurchase;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT basicpackagefkpccustomization;
ALTER TABLE ONLY public.desktopconfig DROP CONSTRAINT basicpackagefkdesktopconfig;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT basicpackagefkcustomization;
ALTER TABLE ONLY public.banner DROP CONSTRAINT bannerimagefk;
ALTER TABLE ONLY public.banner DROP CONSTRAINT bannerfktagtreenode;
ALTER TABLE ONLY public.banner DROP CONSTRAINT bannerfki18n;
ALTER TABLE ONLY public.asseti18n DROP CONSTRAINT asseti18nfkuserid;
ALTER TABLE ONLY public.applicationorder DROP CONSTRAINT applicationorderparentfkapplication;
ALTER TABLE ONLY public.applicationorder DROP CONSTRAINT applicationorderfkapplication;
ALTER TABLE ONLY public.desktopitemwidget DROP CONSTRAINT applicationfkdesktopitemwidget;
ALTER TABLE ONLY public.desktopitemapp DROP CONSTRAINT applicationfkdesktopitemapp;
ALTER TABLE ONLY public.advertisingvisualization DROP CONSTRAINT advertisingvisualizationfkaccount;
ALTER TABLE ONLY public.advertisingtagtreenode DROP CONSTRAINT advertisingtagnodefkstbtagtreenode;
ALTER TABLE ONLY public.accountscreensaver DROP CONSTRAINT accountscreensaverscreensaverfk;
ALTER TABLE ONLY public.accountrecordingchannel DROP CONSTRAINT accountrecordingchannelfkchanneldata;
ALTER TABLE ONLY public.accountpin DROP CONSTRAINT accountpinfkaccount;
ALTER TABLE ONLY public.accountlastplayedmedia DROP CONSTRAINT accountlastplayedmediafkaccount;
ALTER TABLE ONLY public.accountpreference DROP CONSTRAINT accountfkstbpreference;
ALTER TABLE ONLY public.account DROP CONSTRAINT accountfksessionaccounting;
ALTER TABLE ONLY public.rent DROP CONSTRAINT accountfkrent;
ALTER TABLE ONLY public.interaction DROP CONSTRAINT accountfkinteraction;
ALTER TABLE ONLY public.favorite DROP CONSTRAINT accountfkfavorite;
ALTER TABLE ONLY public.accountremoteaccess DROP CONSTRAINT accountfkaccountremoteaccess;
ALTER TABLE ONLY public.accountrecordingchannel DROP CONSTRAINT accountfkaccountrecordingchannel;
ALTER TABLE ONLY public.accountaccountrole DROP CONSTRAINT accountaccountroleaccountrolefk;
ALTER TABLE ONLY public.accountaccountrole DROP CONSTRAINT accountaccountroleaccountfk;
ALTER TABLE ONLY public.accessrightuserserviceid DROP CONSTRAINT accessrightuserserviceiduserservicefk;
ALTER TABLE ONLY public.accessrightuserserviceid DROP CONSTRAINT accessrightuserserviceidaccessrightfk;
ALTER TABLE ONLY public.accessright DROP CONSTRAINT accessrightpurchasefk;
ALTER TABLE ONLY public.accessright DROP CONSTRAINT accessrightproductitemfk;
ALTER TABLE ONLY public.accessright DROP CONSTRAINT accessrightproductfk;
ALTER TABLE ONLY public.accessrightpluginid DROP CONSTRAINT accessrightpluginidpluginconfigurationfk;
ALTER TABLE ONLY public.accessrightpluginid DROP CONSTRAINT accessrightpluginidaccessrightfk;
ALTER TABLE ONLY public.accessright DROP CONSTRAINT accessrightfksessionaccounting;
ALTER TABLE ONLY public.accessrightcasstatus DROP CONSTRAINT accessrightfkaccessrightcasstatus;
ALTER TABLE ONLY public.accessrightdeviceclassid DROP CONSTRAINT accessrightdeviceclassidfkdevice;
ALTER TABLE ONLY public.accessrightdeviceclassid DROP CONSTRAINT accessrightdeviceclassiddeviceclassfk;
ALTER TABLE ONLY public.accessrightdeviceclassid DROP CONSTRAINT accessrightdeviceclassidaccessrightfk;
ALTER TABLE ONLY public.accessrightconcurrentusers DROP CONSTRAINT accessrightconcurrentusersdeviceclassfk;
ALTER TABLE ONLY public.accessrightconcurrentusers DROP CONSTRAINT accessrightconcurrentusersaccessrightfk;
ALTER TABLE ONLY public.accessrightchannelid DROP CONSTRAINT accessrightchannelidfkchanneldata;
ALTER TABLE ONLY public.accessrightchannelid DROP CONSTRAINT accessrightchannelidaccessrightfk;
ALTER TABLE ONLY public.accessrightchannelcategory DROP CONSTRAINT accessrightchannelcategorycontentcategoryfk;
ALTER TABLE ONLY public.accessrightchannelcategory DROP CONSTRAINT accessrightchannelcategoryaccessrightfk;
ALTER TABLE ONLY public.accessrightcasstatus DROP CONSTRAINT accessrightcasstatusfkchanneldata;
ALTER TABLE ONLY public.accessrightappid DROP CONSTRAINT accessrightappidapplicationfk;
ALTER TABLE ONLY public.accessrightappid DROP CONSTRAINT accessrightappidaccessrightfk;
ALTER TABLE ONLY public.accessrightallplugins DROP CONSTRAINT accessrightallpluginsaccessrightfk;
ALTER TABLE ONLY public.accessrightalldeviceclasses DROP CONSTRAINT accessrightalldeviceclassesaccessrightfk;
ALTER TABLE ONLY public.accessrightallchannels DROP CONSTRAINT accessrightallchannelsaccessrightfk;
ALTER TABLE ONLY public.accessrightallapps DROP CONSTRAINT accessrightallappsidaccessrightfk;
DROP RULE delete_parent_productitemuserserviceid ON public.productitemuserserviceid;
DROP RULE delete_parent_productitempluginid ON public.productitempluginid;
DROP RULE delete_parent_productitemdeviceclassid ON public.productitemdeviceclassid;
DROP RULE delete_parent_productitemconcurrentusers ON public.productitemconcurrentusers;
DROP RULE delete_parent_productitemchannelid ON public.productitemchannelid;
DROP RULE delete_parent_productitemchannelcategory ON public.productitemchannelcategory;
DROP RULE delete_parent_productitemappid ON public.productitemappid;
DROP RULE delete_parent_desktopitemwidget ON public.desktopitemwidget;
DROP RULE delete_parent_desktopitemweb ON public.desktopitemweb;
DROP RULE delete_parent_desktopitemplugin ON public.desktopitemplugin;
DROP RULE delete_parent_desktopitemmedia ON public.desktopitemmedia;
DROP RULE delete_parent_desktopitemapp ON public.desktopitemapp;
DROP RULE delete_parent_accessrightuserserviceid ON public.accessrightuserserviceid;
DROP RULE delete_parent_accessrightpluginid ON public.accessrightpluginid;
DROP RULE delete_parent_accessrightdeviceclassid ON public.accessrightdeviceclassid;
DROP RULE delete_parent_accessrightconcurrentusers ON public.accessrightconcurrentusers;
DROP RULE delete_parent_accessrightchannelid ON public.accessrightchannelid;
DROP RULE delete_parent_accessrightchannelcategory ON public.accessrightchannelcategory;
DROP RULE delete_parent_accessrightappid ON public.accessrightappid;
DROP INDEX public.welcomechannelindexbywelcomechannelid;
DROP INDEX public.webbrowsingpluginconfigbyid;
DROP INDEX public.visualizationindexbyvisualizationid;
DROP INDEX public.videoserverstreamstatusbyvideoserverandappname;
DROP INDEX public.videoserveractionbyvideoserveridandappname;
DROP INDEX public.videoclubpluginconfigbyid;
DROP INDEX public.userdesktopbyid;
DROP INDEX public.timezonebytagtreenodeid;
DROP INDEX public.timezonebyid;
DROP INDEX public.systemapplicationbyid;
DROP INDEX public.stbupgradestbid;
DROP INDEX public.stbupgradeid;
DROP INDEX public.stbtypeindexbystbtypeid;
DROP INDEX public.stbtagtreenodeaccessbytreeid;
DROP INDEX public.stbstatuslastupdatetime;
DROP INDEX public.stbstatusid;
DROP INDEX public.stbpreferenceindexbystb_account_key;
DROP INDEX public.stbpreferenceindexbystb_account;
DROP INDEX public.stbinformationscreenbystbid;
DROP INDEX public.stbindexbystbphysicalid;
DROP INDEX public.stbindexbystbid;
DROP INDEX public.stbchannelvisibilityindexbystbchannelvisibilityid;
DROP INDEX public.stbchannelnumberindexbystbchannelnumberid;
DROP INDEX public.sessionaccountingindexbysessionaccountingid;
DROP INDEX public.rulescollectionindexbyrulescollectionname;
DROP INDEX public.ruleindexbyruleid;
DROP INDEX public.roomindexbyroomid;
DROP INDEX public.rentingvalidityindexbyrentingvalidityid;
DROP INDEX public.rentingvalidityindexbyassetcollectionid;
DROP INDEX public.rentindexbyrentid;
DROP INDEX public.pvrtaskindexbystbid;
DROP INDEX public.pvrtaskindexbypvrstate;
DROP INDEX public.pvrtaskindexbyprvtaskid;
DROP INDEX public.purchasebysessionaccountingid;
DROP INDEX public.purchasebypurchaseid;
DROP INDEX public.purchasebyproductid;
DROP INDEX public.protectedtargetaudiencebytargetaudienceid;
DROP INDEX public.propertyindexbypropertyid;
DROP INDEX public.productitempluginidbyproductitemid;
DROP INDEX public.productitemchannelidbyproductitemid;
DROP INDEX public.productitemchannelcategorybyproductitemid;
DROP INDEX public.productitemappidbyproductitemid;
DROP INDEX public.productitemallpluginsbyproductitemid;
DROP INDEX public.productitemallchannelsbyproductitemid;
DROP INDEX public.productitemallappsbyproductitemid;
DROP INDEX public.productincludedbyid;
DROP INDEX public.preferencemenuoptionindexbypreferencemenuoptionidid;
DROP INDEX public.predefinedmessageindexbymessageid;
DROP INDEX public.prdocutitembyproductitemid;
DROP INDEX public.prdocutitembyproductid;
DROP INDEX public.prdocutbystbtagtreenodeid;
DROP INDEX public.prdocutbyproductid;
DROP INDEX public.pluginscreenbypluginid;
DROP INDEX public.pluginconfigurationstartbypluginconfigurationstartid;
DROP INDEX public.pluginconfigurationbypluginconfigurationid;
DROP INDEX public.plugin_webbrows_stburlitemaccessbystbid;
DROP INDEX public.playlistmappingscreenbyplaylistmappingscreenid;
DROP INDEX public.playerconfigurationbyprotocol;
DROP INDEX public.playerconfigurationbyid;
DROP INDEX public.photoindexbyid;
DROP INDEX public.periodicityindexbyperiodicityid;
DROP INDEX public.parentalcontrollevelbyaccountid;
DROP INDEX public.outputsprotectionbyaccountid;
DROP INDEX public.networkareaipv4subnetbyid;
DROP INDEX public.messagewakeupbyid;
DROP INDEX public.messagescriptbyid;
DROP INDEX public.messagepopupbyid;
DROP INDEX public.messagemailbyid;
DROP INDEX public.messageindexby_id;
DROP INDEX public.memcachedkeyvaliduntilindex;
DROP INDEX public.memcachedkeyindexbysessionaccountingid;
DROP INDEX public.memcachedkeyindexbyid;
DROP INDEX public.memcachedkeyindexbydeviceid;
DROP INDEX public.memcachedkeyindexbyaccountid;
DROP INDEX public.memcachedkeycachekeycachetypeindex;
DROP INDEX public.masternodeindexbyid;
DROP INDEX public.listconfigurationbylistconfigurationid;
DROP INDEX public.listconfigurationassetindexbylistconfigurationassetid;
DROP INDEX public.itemmappingscreenbyitemmappingscreenid;
DROP INDEX public.interactionindexbyinteractionkey;
DROP INDEX public.hotelindexbyid;
DROP INDEX public.guestservicesid;
DROP INDEX public.guestindexbyguestid;
DROP INDEX public.genericinfoindexbyid;
DROP INDEX public.firmwareversion;
DROP INDEX public.filterlistconfigurationindexbyfilterlistconfigurationid;
DROP INDEX public.favoriteindexbyfavoriteid;
DROP INDEX public.favoritechannelbyid;
DROP INDEX public.favoritechannelbyaccountid;
DROP INDEX public.dialingcodeindexbyid;
DROP INDEX public.developerindexbydeveloperid;
DROP INDEX public.desktopitemwidgetbyid;
DROP INDEX public.desktopitemwebbyid;
DROP INDEX public.desktopitempluginbyid;
DROP INDEX public.desktopitemmediabyid;
DROP INDEX public.desktopitembyid;
DROP INDEX public.desktopitemappbyid;
DROP INDEX public.desktopconfigdesktopbyid;
DROP INDEX public.desktopconfigbyid;
DROP INDEX public.desktopbyid;
DROP INDEX public.desktopareabyid;
DROP INDEX public.defaultbasicpackageindexbyid;
DROP INDEX public.customizationpathbyid;
DROP INDEX public.customizationpathbydeviceclasspath;
DROP INDEX public.customizationbyid;
DROP INDEX public.customizationapplicationbyid;
DROP INDEX public.currencybyvisualname;
DROP INDEX public.currencybycurrencyid;
DROP INDEX public.creditindexbycreditid;
DROP INDEX public.contentcategorybycategoryname;
DROP INDEX public.contentcategorybycategoryid;
DROP INDEX public.collectionruleindexbycollectionruleid;
DROP INDEX public.channelvideopidindexbychannelvideopidid;
DROP INDEX public.channelvideopidindexbychanneldataplayinfoid;
DROP INDEX public.channelsourceuriindexbychannelsourceuriid;
DROP INDEX public.channelsourceuriindexbychanneldataplayinfoid;
DROP INDEX public.channellistitemaccessbychannellistid;
DROP INDEX public.channeldataindexbychannelid;
DROP INDEX public.channelcategorybychannelcategoryid;
DROP INDEX public.channelaudiopidindexbychanneldataplayinfoid;
DROP INDEX public.channelaudiopidindexbychannelaudiopidid;
DROP INDEX public.channelaccesstypesubscriptionbychannelaccesstypesubscriptionid;
DROP INDEX public.channelaccesstypesubscriptionbyaccountid;
DROP INDEX public.categoryindexbycategoryid;
DROP INDEX public.catalogtreenodepropertyindexbycatalogtreenodeid;
DROP INDEX public.catalogtreenodenameindexbycatalogtreenodenameid;
DROP INDEX public.catalogtreenodeindexbycatalogtreenodeid;
DROP INDEX public.catalogtreenodeassetindexbycatalogtreenodeid;
DROP INDEX public.catalogtreeindexbycatalogtreeid;
DROP INDEX public.cacheversionbyid;
DROP INDEX public.billingbybillingid;
DROP INDEX public.basicpackagebyid;
DROP INDEX public.authtokensessionaccountingidindex;
DROP INDEX public.authtokendeviceidindex;
DROP INDEX public.authtokenaccountidindex;
DROP INDEX public.asseti18nindexbyasseti18nid;
DROP INDEX public.applicationorderid;
DROP INDEX public.applicationbyappid;
DROP INDEX public.am_stbalarmindexbyid;
DROP INDEX public.am_multicastgroupalarmindexbyid;
DROP INDEX public.accountremoteaccessindexbyid;
DROP INDEX public.accountrecordingchannelindexbyvodkatvchannelid;
DROP INDEX public.accountrecordingchannelindexbyaccountrecordingchannelid;
DROP INDEX public.accountrecordingchannelindexbyaccountingid;
DROP INDEX public.accountpinbyaccountid;
DROP INDEX public.accountlastplayedmediaid;
DROP INDEX public.accountindexbyaccountid;
DROP INDEX public.accountaccountrolebyaccountid;
DROP INDEX public.accessrightuserserviceidbyaccessrightid;
DROP INDEX public.accessrightpluginidbyaccessrightid;
DROP INDEX public.accessrightchannelidbyaccessrightid;
DROP INDEX public.accessrightchannelcategorybyaccessrightid;
DROP INDEX public.accessrightcasstatusid;
DROP INDEX public.accessrightbysessionaccountingid;
DROP INDEX public.accessrightbyaccessrightid;
DROP INDEX public.accessrightappidbyaccessrightid;
DROP INDEX public.accessrightallpluginsbyaccessrightid;
DROP INDEX public.accessrightallchannelsbyaccessrightid;
DROP INDEX public.accessrightallappsbyaccessrightid;
ALTER TABLE ONLY public.wowzaaessharedkey DROP CONSTRAINT wowzaaessharedkeypk;
ALTER TABLE ONLY public.welcomechannel DROP CONSTRAINT welcomechanneluniquelocale;
ALTER TABLE ONLY public.welcomechannel DROP CONSTRAINT welcomechannelpk;
ALTER TABLE ONLY public.vouchervalidproduct DROP CONSTRAINT vouchervalidproductpk;
ALTER TABLE ONLY public.vouchervalidpackage DROP CONSTRAINT vouchervalidpackagepk;
ALTER TABLE ONLY public.voucher DROP CONSTRAINT voucherpk;
ALTER TABLE ONLY public.channeldata DROP CONSTRAINT vodkatvchannelidunique;
ALTER TABLE ONLY public.channeldataplayinfo DROP CONSTRAINT vodkatvchanneliddeviceunique;
ALTER TABLE ONLY public.visualization DROP CONSTRAINT visualizationpk;
ALTER TABLE ONLY public.videoserverwowza DROP CONSTRAINT videoserverwowzapk;
ALTER TABLE ONLY public.videoservervodkatickets DROP CONSTRAINT videoservervodkaticketspk;
ALTER TABLE ONLY public.videoserver DROP CONSTRAINT videoserverunique;
ALTER TABLE ONLY public.videoserverswisstv DROP CONSTRAINT videoserverswisstvpk;
ALTER TABLE ONLY public.videoserverstreamstatus DROP CONSTRAINT videoserverstreamstatus_pkey;
ALTER TABLE ONLY public.videoserverstatus DROP CONSTRAINT videoserverstatusunique;
ALTER TABLE ONLY public.videoserverstatus DROP CONSTRAINT videoserverstatuspk;
ALTER TABLE ONLY public.videoserver DROP CONSTRAINT videoserveridpk;
ALTER TABLE ONLY public.videoservergroupvideoserver DROP CONSTRAINT videoservergroupvideoserverpk;
ALTER TABLE ONLY public.videoservergroup DROP CONSTRAINT videoservergrouppk;
ALTER TABLE ONLY public.videoservergroupchanneldataplayinfo DROP CONSTRAINT videoservergroupchanneldataplayinfopk;
ALTER TABLE ONLY public.videoserverdevicetype DROP CONSTRAINT videoserverdevicetypepk;
ALTER TABLE ONLY public.videoservercontent DROP CONSTRAINT videoservercontentpk;
ALTER TABLE ONLY public.videoserverstreamstatus DROP CONSTRAINT videoserverchannelstatusunique;
ALTER TABLE ONLY public.videoserveraction DROP CONSTRAINT videoserveractionpk;
ALTER TABLE ONLY public.videocodec DROP CONSTRAINT videocodecpk;
ALTER TABLE ONLY public.videocodec DROP CONSTRAINT videocodec_codec_key;
ALTER TABLE ONLY public.userservice DROP CONSTRAINT userservicepk;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.userdesktop DROP CONSTRAINT userdesktoppk;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_pkey;
ALTER TABLE ONLY public.timezone DROP CONSTRAINT timezoneunique;
ALTER TABLE ONLY public.timezone DROP CONSTRAINT timezonepk;
ALTER TABLE ONLY public.systemapplication DROP CONSTRAINT systemapplicationuniqueversion;
ALTER TABLE ONLY public.systemapplication DROP CONSTRAINT systemapplicationpk;
ALTER TABLE ONLY public.subscriptiondependencies DROP CONSTRAINT subscriptiondependenciespk;
ALTER TABLE ONLY public.subscriptioncatalog DROP CONSTRAINT subscriptioncatalogpk;
ALTER TABLE ONLY public.stbupgrade DROP CONSTRAINT stbupgradepk;
ALTER TABLE ONLY public.device DROP CONSTRAINT stbunique;
ALTER TABLE ONLY public.deviceclass DROP CONSTRAINT stbtypepk;
ALTER TABLE ONLY public.stbtagtree DROP CONSTRAINT stbtagtreepk;
ALTER TABLE ONLY public.stbtagtreenode DROP CONSTRAINT stbtagtreenodepk;
ALTER TABLE ONLY public.stbstatusstorage DROP CONSTRAINT stbstatusstorage_pkey;
ALTER TABLE ONLY public.stbstatus DROP CONSTRAINT stbstatuspk;
ALTER TABLE ONLY public.stbsession DROP CONSTRAINT stbsessionpk;
ALTER TABLE ONLY public.accountpreference DROP CONSTRAINT stbpreferenceunique_stb_account_key;
ALTER TABLE ONLY public.accountpreference DROP CONSTRAINT stbpreferencepk;
ALTER TABLE ONLY public.device DROP CONSTRAINT stbpk;
ALTER TABLE ONLY public.stbinformationscreen DROP CONSTRAINT stbinformationscreenpk;
ALTER TABLE ONLY public.channelvisibility DROP CONSTRAINT stbchannelvisibilitypk;
ALTER TABLE ONLY public.channelnumber DROP CONSTRAINT stbchannelnumberpk;
ALTER TABLE ONLY public.sessionaccounting DROP CONSTRAINT sessionaccountingpk;
ALTER TABLE ONLY public.accountscreensaver DROP CONSTRAINT screensaverpk;
ALTER TABLE ONLY public.schedulelink DROP CONSTRAINT schedulelinkpk;
ALTER TABLE ONLY public.schedulelink DROP CONSTRAINT schedulelinknameunique;
ALTER TABLE ONLY public.rulescollection DROP CONSTRAINT rullescollectionpk;
ALTER TABLE ONLY public.rule DROP CONSTRAINT rulepositionandrulescollectionnameuniquerule;
ALTER TABLE ONLY public.rule DROP CONSTRAINT rulepk;
ALTER TABLE ONLY public.rule DROP CONSTRAINT rulenameandrulescollectionnameuniquerule;
ALTER TABLE ONLY public.rss DROP CONSTRAINT rsspk;
ALTER TABLE ONLY public.rss DROP CONSTRAINT rssnameunique;
ALTER TABLE ONLY public.room DROP CONSTRAINT roompk;
ALTER TABLE ONLY public.role DROP CONSTRAINT rolepk;
ALTER TABLE ONLY public.rolemenuoption DROP CONSTRAINT rolenamemenuoptionidunique;
ALTER TABLE ONLY public.rolemenuoption DROP CONSTRAINT rolemenuoption_pkey;
ALTER TABLE ONLY public.roleattribute DROP CONSTRAINT roleattributepk;
ALTER TABLE ONLY public.roleassetcollection DROP CONSTRAINT roleassetcollectionunique;
ALTER TABLE ONLY public.roleassetcollection DROP CONSTRAINT roleassetcollectionpk;
ALTER TABLE ONLY public.roleassetcollectioncontent DROP CONSTRAINT roleassetcollectioncontentpk;
ALTER TABLE ONLY public.rent DROP CONSTRAINT rentpk;
ALTER TABLE ONLY public.rentingvalidity DROP CONSTRAINT rentingvalidityunique;
ALTER TABLE ONLY public.rentingvalidity DROP CONSTRAINT rentingvaliditypk;
ALTER TABLE ONLY public.parentalrating DROP CONSTRAINT ratingorderunique;
ALTER TABLE ONLY public.pvrtask DROP CONSTRAINT pvrtaskpk;
ALTER TABLE ONLY public.purchase DROP CONSTRAINT purchasepk;
ALTER TABLE ONLY public.protectedtargetaudience DROP CONSTRAINT protectedtargetaudiencepk;
ALTER TABLE ONLY public.property DROP CONSTRAINT propertypk;
ALTER TABLE ONLY public.product DROP CONSTRAINT productpk;
ALTER TABLE ONLY public.productitemuserserviceid DROP CONSTRAINT productitemuserserviceidpk;
ALTER TABLE ONLY public.productitempluginid DROP CONSTRAINT productitempluginidpk;
ALTER TABLE ONLY public.productitem DROP CONSTRAINT productitempk;
ALTER TABLE ONLY public.productitemdeviceclassid DROP CONSTRAINT productitemdeviceclassidpk;
ALTER TABLE ONLY public.productitemconcurrentusers DROP CONSTRAINT productitemconcurrentuserspk;
ALTER TABLE ONLY public.productitemchannelid DROP CONSTRAINT productitemchannelidpk;
ALTER TABLE ONLY public.productitemchannelcategory DROP CONSTRAINT productitemchannelcategorypk;
ALTER TABLE ONLY public.productitemappid DROP CONSTRAINT productitemappidpk;
ALTER TABLE ONLY public.productitemallplugins DROP CONSTRAINT productitemallpluginspk;
ALTER TABLE ONLY public.productitemalldeviceclasses DROP CONSTRAINT productitemalldeviceclassespk;
ALTER TABLE ONLY public.productitemallchannels DROP CONSTRAINT productitemallchannelspk;
ALTER TABLE ONLY public.productitemallapps DROP CONSTRAINT productitemallappspk;
ALTER TABLE ONLY public.productincluded DROP CONSTRAINT productincludedpk;
ALTER TABLE ONLY public.preferencemenuoption DROP CONSTRAINT preferencemenuoptionunique;
ALTER TABLE ONLY public.preferencemenuoption DROP CONSTRAINT preferencemenuoptionpk;
ALTER TABLE ONLY public.pluginscreen DROP CONSTRAINT pluginscreenpk;
ALTER TABLE ONLY public.pluginconfigurationstart DROP CONSTRAINT pluginconfigurationstartpk;
ALTER TABLE ONLY public.pluginconfiguration DROP CONSTRAINT pluginconfigurationpk;
ALTER TABLE ONLY public.plugin_webbrows_stburlitem DROP CONSTRAINT plugin_webbrows_stburlitempk;
ALTER TABLE ONLY public.plugin_webbrows_stburlitemlang DROP CONSTRAINT plugin_webbrows_stburlitemlangpk;
ALTER TABLE ONLY public.plugin_webbrows_stburlitemlang DROP CONSTRAINT plugin_webbrows_stburlitemlang_stburlitemid_code_key;
ALTER TABLE ONLY public.plugin_webbrows_stburlitem DROP CONSTRAINT plugin_webbrows_stburlitem_stbid_itemid_key;
ALTER TABLE ONLY public.playlistmappingscreen DROP CONSTRAINT playlistmappingscreenpk;
ALTER TABLE ONLY public.playerconfiguration DROP CONSTRAINT playerconfigurationpk;
ALTER TABLE ONLY public.playerconfiguration DROP CONSTRAINT playerconfiguration_protocol_key;
ALTER TABLE ONLY public.databasechangeloglock DROP CONSTRAINT pk_databasechangeloglock;
ALTER TABLE ONLY public.photo DROP CONSTRAINT photopkid;
ALTER TABLE ONLY public.periodicity DROP CONSTRAINT periodicitypk;
ALTER TABLE ONLY public.parentalratingmapping DROP CONSTRAINT parentalratingmappingpk;
ALTER TABLE ONLY public.parentalrating DROP CONSTRAINT parentalrating_pkey;
ALTER TABLE ONLY public.parentalcontrollevel DROP CONSTRAINT parentalcontrollevelpk;
ALTER TABLE ONLY public.outputsprotection DROP CONSTRAINT outputsprotectionpk;
ALTER TABLE ONLY public.networkareaipv4subnet DROP CONSTRAINT networkareaipv4subnetpk;
ALTER TABLE ONLY public.networkarea DROP CONSTRAINT networkareaidpk;
ALTER TABLE ONLY public.networkareacountry DROP CONSTRAINT networkareacountrypk;
ALTER TABLE ONLY public.stbtagtree DROP CONSTRAINT nameuniquestbtagtree;
ALTER TABLE ONLY public.channellist DROP CONSTRAINT nameandtypeuniquechannellist;
ALTER TABLE ONLY public.messagewakeup DROP CONSTRAINT messagewakeuppk;
ALTER TABLE ONLY public.message DROP CONSTRAINT messagespk;
ALTER TABLE ONLY public.messagescript DROP CONSTRAINT messagescriptmessagepk;
ALTER TABLE ONLY public.messagepopup DROP CONSTRAINT messagepopuppk;
ALTER TABLE ONLY public.predefinedmessage DROP CONSTRAINT messagepk;
ALTER TABLE ONLY public.messagemail DROP CONSTRAINT messagemailmessagepk;
ALTER TABLE ONLY public.menuoption DROP CONSTRAINT menuoptionpk;
ALTER TABLE ONLY public.memcachedkey DROP CONSTRAINT memcachedkeypk;
ALTER TABLE ONLY public.masternode DROP CONSTRAINT masternodepkid;
ALTER TABLE ONLY public.accountremoteaccess DROP CONSTRAINT loginnameunique;
ALTER TABLE ONLY public.logging_event_property DROP CONSTRAINT logging_event_property_pkey;
ALTER TABLE ONLY public.logging_event DROP CONSTRAINT logging_event_pkey;
ALTER TABLE ONLY public.logging_event_exception DROP CONSTRAINT logging_event_exception_pkey;
ALTER TABLE ONLY public.listconfiguration DROP CONSTRAINT listconfigurationpk;
ALTER TABLE ONLY public.listconfigurationasset DROP CONSTRAINT listconfigurationassetpk;
ALTER TABLE ONLY public.link DROP CONSTRAINT linkpk;
ALTER TABLE ONLY public.link DROP CONSTRAINT linknameunique;
ALTER TABLE ONLY public.language DROP CONSTRAINT languagepk;
ALTER TABLE ONLY public.itemmappingscreen DROP CONSTRAINT itemmappingscreenpk;
ALTER TABLE ONLY public.interaction DROP CONSTRAINT interactionpk;
ALTER TABLE ONLY public.incompatibleproduct DROP CONSTRAINT incompatibleproductpk;
ALTER TABLE ONLY public.image DROP CONSTRAINT imagepk;
ALTER TABLE ONLY public.i18n DROP CONSTRAINT i18npk;
ALTER TABLE ONLY public.hotel DROP CONSTRAINT hotelpkid;
ALTER TABLE ONLY public.guestservices DROP CONSTRAINT guestservicespk;
ALTER TABLE ONLY public.guest DROP CONSTRAINT guestpk;
ALTER TABLE ONLY public.genericinfo DROP CONSTRAINT genericinfopkid;
ALTER TABLE ONLY public.firmware DROP CONSTRAINT firmwarepk;
ALTER TABLE ONLY public.filterlistconfiguration DROP CONSTRAINT filterlistconfigurationpk;
ALTER TABLE ONLY public.favorite DROP CONSTRAINT favoritepk;
ALTER TABLE ONLY public.favoritechannel DROP CONSTRAINT favoritechannelunique;
ALTER TABLE ONLY public.favoritechannel DROP CONSTRAINT favoritechannelpk;
ALTER TABLE ONLY public.eventsserver DROP CONSTRAINT eventsserverpk;
ALTER TABLE ONLY public.emailtemplate DROP CONSTRAINT emailtemplatepk;
ALTER TABLE ONLY public.dialingcode DROP CONSTRAINT dialingcodepkid;
ALTER TABLE ONLY public.devicetype DROP CONSTRAINT devicetypepk;
ALTER TABLE ONLY public.devicestatuseventsserver DROP CONSTRAINT devicestatuseventsserverpk;
ALTER TABLE ONLY public.developer DROP CONSTRAINT developerpk;
ALTER TABLE ONLY public.desktop DROP CONSTRAINT desktoppk;
ALTER TABLE ONLY public.desktopitemwidget DROP CONSTRAINT desktopitemwidgetpk;
ALTER TABLE ONLY public.desktopitemweb DROP CONSTRAINT desktopitemwebpk;
ALTER TABLE ONLY public.desktopitemplugin DROP CONSTRAINT desktopitempluginpk;
ALTER TABLE ONLY public.desktopitem DROP CONSTRAINT desktopitempk;
ALTER TABLE ONLY public.desktopitemmedia DROP CONSTRAINT desktopitemmediapk;
ALTER TABLE ONLY public.desktopitemapp DROP CONSTRAINT desktopitemapppk;
ALTER TABLE ONLY public.desktopconfig DROP CONSTRAINT desktopconfigpk;
ALTER TABLE ONLY public.desktopconfigdesktop DROP CONSTRAINT desktopconfigdesktoppk;
ALTER TABLE ONLY public.desktoparea DROP CONSTRAINT desktopareapk;
ALTER TABLE ONLY public.defaultbasicpackage DROP CONSTRAINT defaultbasicpackagepk;
ALTER TABLE ONLY public.customization DROP CONSTRAINT customizationuniquefilename;
ALTER TABLE ONLY public.customization DROP CONSTRAINT customizationpk;
ALTER TABLE ONLY public.customizationpath DROP CONSTRAINT customizationpathuniquedeviceclasspath;
ALTER TABLE ONLY public.customizationpath DROP CONSTRAINT customizationpathpk;
ALTER TABLE ONLY public.customizationsystemapplication DROP CONSTRAINT customizationapplicationunique;
ALTER TABLE ONLY public.customizationsystemapplication DROP CONSTRAINT customizationapplicationpk;
ALTER TABLE ONLY public.currency DROP CONSTRAINT currencypk;
ALTER TABLE ONLY public.currency DROP CONSTRAINT currencycurrencykeyunique;
ALTER TABLE ONLY public.credit DROP CONSTRAINT creditpk;
ALTER TABLE ONLY public.contentcategory DROP CONSTRAINT contentcategoryunique;
ALTER TABLE ONLY public.contentcategory DROP CONSTRAINT contentcategorypk;
ALTER TABLE ONLY public.collectionrule DROP CONSTRAINT collectionrulepk;
ALTER TABLE ONLY public.channelvideopid DROP CONSTRAINT channelvideopidpk;
ALTER TABLE ONLY public.channelsourceuri DROP CONSTRAINT channelsourceuripk;
ALTER TABLE ONLY public.channelaudiopid DROP CONSTRAINT channelplayinfoiduniquelanguage;
ALTER TABLE ONLY public.channelaccessarea DROP CONSTRAINT channelnetworkareapk;
ALTER TABLE ONLY public.stbtagtreenodechannellist DROP CONSTRAINT channellisttagpk;
ALTER TABLE ONLY public.channellist DROP CONSTRAINT channellistpk;
ALTER TABLE ONLY public.channellistitem DROP CONSTRAINT channellistitempk;
ALTER TABLE ONLY public.channellistitem DROP CONSTRAINT channellistidandchannelnumberuniquechannellistitem;
ALTER TABLE ONLY public.channeldataplayinfo DROP CONSTRAINT channeldataplayinfo_pkey;
ALTER TABLE ONLY public.channeldata DROP CONSTRAINT channeldata_pkey;
ALTER TABLE ONLY public.channelcategory DROP CONSTRAINT channelcategorypk;
ALTER TABLE ONLY public.channelaudiopid DROP CONSTRAINT channelaudiopidpk;
ALTER TABLE ONLY public.channelaccesstypesubscription DROP CONSTRAINT channelaccesstypesubscriptionunique;
ALTER TABLE ONLY public.channelaccesstypesubscription DROP CONSTRAINT channelaccesstypesubscriptionpk;
ALTER TABLE ONLY public.category DROP CONSTRAINT categorypk;
ALTER TABLE ONLY public.catalogtree DROP CONSTRAINT catalogtreepk;
ALTER TABLE ONLY public.catalogtreenode DROP CONSTRAINT catalogtreenodeunique;
ALTER TABLE ONLY public.catalogtreenoderole DROP CONSTRAINT catalogtreenoderolepk;
ALTER TABLE ONLY public.catalogtreenodeproperty DROP CONSTRAINT catalogtreenodepropertyunique;
ALTER TABLE ONLY public.catalogtreenodeproperty DROP CONSTRAINT catalogtreenodepropertypk;
ALTER TABLE ONLY public.catalogtreenode DROP CONSTRAINT catalogtreenodepk;
ALTER TABLE ONLY public.catalogtreenodename DROP CONSTRAINT catalogtreenodenameunique;
ALTER TABLE ONLY public.catalogtreenodename DROP CONSTRAINT catalogtreenodenamepk;
ALTER TABLE ONLY public.catalogtreenodeasset DROP CONSTRAINT catalogtreenodeassetpk;
ALTER TABLE ONLY public.cacheversion DROP CONSTRAINT cacheversionpk;
ALTER TABLE ONLY public.cacheserver DROP CONSTRAINT cacheserverpk;
ALTER TABLE ONLY public.billing DROP CONSTRAINT billingpk;
ALTER TABLE ONLY public.basicpackage DROP CONSTRAINT basicpackagepk;
ALTER TABLE ONLY public.banner DROP CONSTRAINT banner_pkey;
ALTER TABLE ONLY public.banner DROP CONSTRAINT banner_bannerid_key;
ALTER TABLE ONLY public.authtoken DROP CONSTRAINT auth_token_pkey;
ALTER TABLE ONLY public.audiocodec DROP CONSTRAINT audiocodecpk;
ALTER TABLE ONLY public.audiocodec DROP CONSTRAINT audiocodec_codec_key;
ALTER TABLE ONLY public.asseti18n DROP CONSTRAINT asseti18unique;
ALTER TABLE ONLY public.asseti18n DROP CONSTRAINT asseti18npk;
ALTER TABLE ONLY public.rentingvalidity DROP CONSTRAINT assetcollectionidunique;
ALTER TABLE ONLY public.application DROP CONSTRAINT applicationpk;
ALTER TABLE ONLY public.applicationorder DROP CONSTRAINT applicationorderpk;
ALTER TABLE ONLY public.am_stbalarm DROP CONSTRAINT am_stbalarmpkid;
ALTER TABLE ONLY public.am_multicastgroupalarm DROP CONSTRAINT am_multicastgrouppkid;
ALTER TABLE ONLY public.advertisingvisualization DROP CONSTRAINT advertisingvisualizationpk;
ALTER TABLE ONLY public.advertisingtagtreenode DROP CONSTRAINT advertisingtagnodepk;
ALTER TABLE ONLY public.advertisingmetadataserver DROP CONSTRAINT advertisingmetadataserverpk;
ALTER TABLE ONLY public.advertisingmedia DROP CONSTRAINT advertisingmediauniqueassetidadvertisingtype;
ALTER TABLE ONLY public.advertisingmedia DROP CONSTRAINT advertisingmediapk;
ALTER TABLE ONLY public.advertisingconfig DROP CONSTRAINT advertisingconfigpk;
ALTER TABLE ONLY public.screensaver DROP CONSTRAINT accountscreensaverpk;
ALTER TABLE ONLY public.accountrole DROP CONSTRAINT accountrolepk;
ALTER TABLE ONLY public.accountremoteaccess DROP CONSTRAINT accountremoteaccesspk;
ALTER TABLE ONLY public.accountremoteaccess DROP CONSTRAINT accountremoteaccessactivationcodeunique;
ALTER TABLE ONLY public.accountrecordingchannel DROP CONSTRAINT accountrecordingchannelpk;
ALTER TABLE ONLY public.account DROP CONSTRAINT accountpk;
ALTER TABLE ONLY public.accountpin DROP CONSTRAINT accountpinunique;
ALTER TABLE ONLY public.accountpin DROP CONSTRAINT accountpinpk;
ALTER TABLE ONLY public.accountlastplayedmedia DROP CONSTRAINT accountlastplayedmediapk;
ALTER TABLE ONLY public.accountaccountrole DROP CONSTRAINT accountaccountrolepk;
ALTER TABLE ONLY public.accessrightuserserviceid DROP CONSTRAINT accessrightuserserviceidpk;
ALTER TABLE ONLY public.accessrightpluginid DROP CONSTRAINT accessrightpluginidpk;
ALTER TABLE ONLY public.accessright DROP CONSTRAINT accessrightpk;
ALTER TABLE ONLY public.accessrightdeviceclassid DROP CONSTRAINT accessrightdeviceclassidpk;
ALTER TABLE ONLY public.accessrightconcurrentusers DROP CONSTRAINT accessrightconcurrentuserspk;
ALTER TABLE ONLY public.accessrightchannelid DROP CONSTRAINT accessrightchannelidpk;
ALTER TABLE ONLY public.accessrightchannelcategory DROP CONSTRAINT accessrightchannelcategorypk;
ALTER TABLE ONLY public.accessrightcasstatus DROP CONSTRAINT accessrightcasstatuspk;
ALTER TABLE ONLY public.accessrightappid DROP CONSTRAINT accessrightappidpk;
ALTER TABLE ONLY public.accessrightallplugins DROP CONSTRAINT accessrightallpluginspk;
ALTER TABLE ONLY public.accessrightalldeviceclasses DROP CONSTRAINT accessrightalldeviceclassespk;
ALTER TABLE ONLY public.accessrightallchannels DROP CONSTRAINT accessrightallchannelspk;
ALTER TABLE ONLY public.accessrightallapps DROP CONSTRAINT accessrightallappspk;
DROP SEQUENCE public.wowzaaessharedkeyseq;
DROP TABLE public.wowzaaessharedkey;
DROP SEQUENCE public.welcomechannelseq;
DROP TABLE public.welcomechannel;
DROP SEQUENCE public.webbrowsingpluginconfigseq;
DROP TABLE public.webbrowsingpluginconfig;
DROP SEQUENCE public.vouchervalidproductseq;
DROP TABLE public.vouchervalidproduct;
DROP SEQUENCE public.vouchervalidpackageseq;
DROP TABLE public.vouchervalidpackage;
DROP SEQUENCE public.voucherseq;
DROP TABLE public.voucher;
DROP SEQUENCE public.visualizationseq;
DROP TABLE public.visualization;
DROP TABLE public.videoserverwowza;
DROP TABLE public.videoservervodkatickets;
DROP TABLE public.videoserverswisstv;
DROP SEQUENCE public.videoserverstreamstatusseq;
DROP TABLE public.videoserverstreamstatus;
DROP SEQUENCE public.videoserverstatusseq;
DROP TABLE public.videoserverstatus;
DROP SEQUENCE public.videoserverseq;
DROP TABLE public.videoservergroupvideoserver;
DROP SEQUENCE public.videoservergroupseq;
DROP TABLE public.videoservergroupchanneldataplayinfo;
DROP TABLE public.videoservergroup;
DROP SEQUENCE public.videoserverdevicetypeseq;
DROP TABLE public.videoserverdevicetype;
DROP SEQUENCE public.videoservercontentseq;
DROP TABLE public.videoservercontent;
DROP SEQUENCE public.videoserveractionseq;
DROP TABLE public.videoserveraction;
DROP TABLE public.videoserver;
DROP SEQUENCE public.videocodecseq;
DROP TABLE public.videocodec;
DROP SEQUENCE public.videoclubpluginconfigseq;
DROP TABLE public.videoclubpluginconfig;
DROP TABLE public.userservice;
DROP TABLE public.users;
DROP SEQUENCE public.userdesktopseq;
DROP TABLE public.userdesktop;
DROP TABLE public.user_roles;
DROP SEQUENCE public.timezoneseq;
DROP TABLE public.timezone;
DROP TABLE public.tahitiversion;
DROP SEQUENCE public.systemapplicationseq;
DROP TABLE public.systemapplication;
DROP SEQUENCE public.subscriptiondependenciesseq;
DROP TABLE public.subscriptiondependencies;
DROP SEQUENCE public.subscriptioncatalogseq;
DROP TABLE public.subscriptioncatalog;
DROP SEQUENCE public.stbupgradeseq;
DROP TABLE public.stbupgrade;
DROP SEQUENCE public.stbtagtreeseq;
DROP SEQUENCE public.stbtagtreenodeseq;
DROP TABLE public.stbtagtreenodechannellist;
DROP TABLE public.stbtagtree;
DROP SEQUENCE public.stbstatusstorageseq;
DROP SEQUENCE public.stbstatusseq;
DROP TABLE public.stbstatus;
DROP TABLE public.stbsession;
DROP SEQUENCE public.stblanguageseq;
DROP TABLE public.stbinformationscreen;
DROP SEQUENCE public.sessionaccountingseq;
DROP SEQUENCE public.screensaverseq;
DROP TABLE public.screensaver;
DROP SEQUENCE public.schedulelinkseq;
DROP TABLE public.schedulelink;
DROP SEQUENCE public.ruleseq;
DROP TABLE public.rulescollection;
DROP TABLE public.rule;
DROP SEQUENCE public.rssseq;
DROP TABLE public.rss;
DROP SEQUENCE public.rolemenuoptionseq;
DROP TABLE public.rolemenuoption;
DROP SEQUENCE public.roleattributeseq;
DROP TABLE public.roleattribute;
DROP SEQUENCE public.roleassetcollectionseq;
DROP TABLE public.roleassetcollectioncontent;
DROP TABLE public.roleassetcollection;
DROP TABLE public.role;
DROP SEQUENCE public.rentseq;
DROP SEQUENCE public.rentingvalidityseq;
DROP TABLE public.rentingvalidity;
DROP TABLE public.rent;
DROP SEQUENCE public.pvrtaskseq;
DROP TABLE public.pvrtask;
DROP SEQUENCE public.purchaseseq;
DROP SEQUENCE public.purchaseconfigseq;
DROP SEQUENCE public.protectedtargetaudienceseq;
DROP TABLE public.protectedtargetaudience;
DROP SEQUENCE public.propertyseq;
DROP TABLE public.property;
DROP SEQUENCE public.productseq;
DROP TABLE public.productitemuserserviceid;
DROP SEQUENCE public.productitemseq;
DROP TABLE public.productitempluginid;
DROP TABLE public.productitemdeviceclassid;
DROP TABLE public.productitemconcurrentusers;
DROP TABLE public.productitemchannelid;
DROP TABLE public.productitemchannelcategory;
DROP TABLE public.productitemappid;
DROP TABLE public.productitemallplugins;
DROP TABLE public.productitemalldeviceclasses;
DROP TABLE public.productitemallchannels;
DROP TABLE public.productitemallapps;
DROP TABLE public.productitem;
DROP SEQUENCE public.productincludedseq;
DROP TABLE public.productincluded;
DROP TABLE public.product;
DROP TABLE public.preferencemenuoption;
DROP SEQUENCE public.predefinedmessageseq;
DROP TABLE public.predefinedmessage;
DROP SEQUENCE public.pluginscreenseq;
DROP TABLE public.pluginscreen;
DROP SEQUENCE public.pluginconfigurationstartseq;
DROP TABLE public.pluginconfigurationstart;
DROP TABLE public.pluginconfiguration;
DROP SEQUENCE public.plugin_webbrows_stburlitemseq;
DROP SEQUENCE public.plugin_webbrows_stburlitemlangseq;
DROP TABLE public.plugin_webbrows_stburlitemlang;
DROP TABLE public.plugin_webbrows_stburlitem;
DROP SEQUENCE public.playlistmappingscreenseq;
DROP TABLE public.playlistmappingscreen;
DROP SEQUENCE public.playerconfigurationseq;
DROP TABLE public.playerconfiguration;
DROP TABLE public.pingtable;
DROP SEQUENCE public.photoseq;
DROP TABLE public.photo;
DROP SEQUENCE public.periodicityseq;
DROP TABLE public.periodicity;
DROP SEQUENCE public.parentalratingseq;
DROP SEQUENCE public.parentalratingmappingseq;
DROP TABLE public.parentalratingmapping;
DROP TABLE public.parentalrating;
DROP TABLE public.parentalcontrollevel;
DROP TABLE public.outputsprotection;
DROP SEQUENCE public.networkareaseq;
DROP SEQUENCE public.networkareaipv4subnetseq;
DROP TABLE public.networkareaipv4subnet;
DROP SEQUENCE public.networkareacountryseq;
DROP TABLE public.networkareacountry;
DROP TABLE public.networkarea;
DROP TABLE public.messagewakeup;
DROP SEQUENCE public.messageseq;
DROP TABLE public.messagescript;
DROP TABLE public.messagepopup;
DROP TABLE public.messagemail;
DROP TABLE public.message;
DROP SEQUENCE public.menuseq;
DROP SEQUENCE public.menuoptionseq;
DROP TABLE public.menuoption;
DROP SEQUENCE public.memcachedkeyseq;
DROP TABLE public.memcachedkey;
DROP TABLE public.masternode;
DROP TABLE public.mappingscreenconfiguration;
DROP TABLE public.logging_event_property;
DROP TABLE public.logging_event_exception;
DROP TABLE public.logging_event;
DROP SEQUENCE public.logging_event_id_seq;
DROP SEQUENCE public.listconfigurationseq;
DROP SEQUENCE public.listconfigurationassetseq;
DROP TABLE public.listconfigurationasset;
DROP TABLE public.listconfiguration;
DROP SEQUENCE public.linkseq;
DROP TABLE public.link;
DROP TABLE public.language;
DROP SEQUENCE public.itemmappingscreenseq;
DROP TABLE public.itemmappingscreen;
DROP TABLE public.interaction;
DROP SEQUENCE public.incompatibleproductseq;
DROP TABLE public.incompatibleproduct;
DROP TABLE public.image;
DROP SEQUENCE public.i18nseq;
DROP TABLE public.i18n;
DROP SEQUENCE public.hotelseq;
DROP TABLE public.hotel;
DROP SEQUENCE public.guestservicesseq;
DROP TABLE public.guestservices;
DROP TABLE public.guest;
DROP SEQUENCE public.genericinfoseq;
DROP TABLE public.genericinfo;
DROP SEQUENCE public.firmwareseq;
DROP TABLE public.firmware;
DROP SEQUENCE public.filterlistconfigurationseq;
DROP TABLE public.filterlistconfiguration;
DROP SEQUENCE public.favoriteseq;
DROP SEQUENCE public.favoritechannelseq;
DROP TABLE public.favoritechannel;
DROP TABLE public.favorite;
DROP SEQUENCE public.eventsserverseq;
DROP TABLE public.eventsserver;
DROP SEQUENCE public.emailtemplateseq;
DROP TABLE public.emailtemplate;
DROP SEQUENCE public.dialingcodeseq;
DROP TABLE public.dialingcode;
DROP SEQUENCE public.devicetypeseq;
DROP TABLE public.devicetype;
DROP TABLE public.devicestatuseventsserver;
DROP SEQUENCE public.deviceseq;
DROP TABLE public.deviceclass;
DROP SEQUENCE public.developerseq;
DROP TABLE public.developer;
DROP SEQUENCE public.desktopseq;
DROP TABLE public.desktopitemwidget;
DROP TABLE public.desktopitemweb;
DROP SEQUENCE public.desktopitemseq;
DROP TABLE public.desktopitemplugin;
DROP TABLE public.desktopitemmedia;
DROP TABLE public.desktopitemapp;
DROP TABLE public.desktopitem;
DROP SEQUENCE public.desktopconfigseq;
DROP SEQUENCE public.desktopconfigdesktopseq;
DROP TABLE public.desktopconfigdesktop;
DROP TABLE public.desktopconfig;
DROP SEQUENCE public.desktopareaseq;
DROP TABLE public.desktoparea;
DROP TABLE public.desktop;
DROP SEQUENCE public.defaultbasicpackageseq;
DROP TABLE public.defaultbasicpackage;
DROP TABLE public.databasechangeloglock;
DROP TABLE public.databasechangelog;
DROP SEQUENCE public.customizationsystemapplicationseq;
DROP TABLE public.customizationsystemapplication;
DROP SEQUENCE public.customizationseq;
DROP SEQUENCE public.customizationpathseq;
DROP TABLE public.customizationpath;
DROP TABLE public.customization;
DROP SEQUENCE public.currencyseq;
DROP TABLE public.currency;
DROP SEQUENCE public.creditseq;
DROP TABLE public.credit;
DROP SEQUENCE public.contentcategoryseq;
DROP TABLE public.contentcategory;
DROP SEQUENCE public.collectionruleseq;
DROP TABLE public.collectionrule;
DROP SEQUENCE public.channelvisibilityseq;
DROP TABLE public.channelvisibility;
DROP SEQUENCE public.channelvideopidseq;
DROP TABLE public.channelvideopid;
DROP SEQUENCE public.channelsourceuriseq;
DROP TABLE public.channelsourceuri;
DROP SEQUENCE public.channelnumberseq;
DROP TABLE public.channelnumber;
DROP SEQUENCE public.channellistseq;
DROP SEQUENCE public.channellistitemseq;
DROP TABLE public.channellistitem;
DROP TABLE public.channellist;
DROP SEQUENCE public.channeldataseq;
DROP SEQUENCE public.channeldataplayinfoseq;
DROP TABLE public.channeldataplayinfo;
DROP TABLE public.channeldata;
DROP SEQUENCE public.channelcategoryseq;
DROP TABLE public.channelcategory;
DROP SEQUENCE public.channelaudiopidseq;
DROP TABLE public.channelaudiopid;
DROP SEQUENCE public.channelaccesstypesubscriptionseq;
DROP TABLE public.channelaccesstypesubscription;
DROP SEQUENCE public.channelaccessareaseq;
DROP TABLE public.channelaccessarea;
DROP TABLE public.category;
DROP SEQUENCE public.catalogtreenodeseq;
DROP SEQUENCE public.catalogtreenoderoleseq;
DROP TABLE public.catalogtreenoderole;
DROP SEQUENCE public.catalogtreenodepropertyseq;
DROP TABLE public.catalogtreenodeproperty;
DROP SEQUENCE public.catalogtreenodenameseq;
DROP TABLE public.catalogtreenodename;
DROP SEQUENCE public.catalogtreenodeassetseq;
DROP TABLE public.catalogtreenodeasset;
DROP TABLE public.catalogtreenode;
DROP TABLE public.catalogtree;
DROP TABLE public.cacheversion;
DROP SEQUENCE public.cacheserverseq;
DROP TABLE public.cacheserver;
DROP VIEW public.billingservice;
DROP TABLE public.stbtagtreenode;
DROP TABLE public.sessionaccounting;
DROP TABLE public.room;
DROP TABLE public.purchase;
DROP TABLE public.device;
DROP SEQUENCE public.billingseq;
DROP TABLE public.billing;
DROP SEQUENCE public.basicpackageseq;
DROP TABLE public.basicpackage;
DROP SEQUENCE public.bannerseq;
DROP TABLE public.banner;
DROP VIEW public.authtokenandstbstatusstorage;
DROP TABLE public.stbstatusstorage;
DROP TABLE public.authtoken;
DROP SEQUENCE public.audiocodecseq;
DROP TABLE public.audiocodec;
DROP SEQUENCE public.asseti18nseq;
DROP TABLE public.asseti18n;
DROP SEQUENCE public.applicationorderseq;
DROP TABLE public.applicationorder;
DROP TABLE public.application;
DROP TABLE public.am_stbalarm;
DROP TABLE public.am_multicastgroupalarm;
DROP SEQUENCE public.am_alarmobjectseq;
DROP SEQUENCE public.advertisingvisualizationseq;
DROP TABLE public.advertisingvisualization;
DROP SEQUENCE public.advertisingtagtreenodeseq;
DROP TABLE public.advertisingtagtreenode;
DROP SEQUENCE public.advertisingmetadataserverseq;
DROP TABLE public.advertisingmetadataserver;
DROP SEQUENCE public.advertisingmediaseq;
DROP TABLE public.advertisingmedia;
DROP SEQUENCE public.advertisingconfigseq;
DROP TABLE public.advertisingconfig;
DROP SEQUENCE public.accountseq;
DROP SEQUENCE public.accountscreensaverseq;
DROP TABLE public.accountscreensaver;
DROP TABLE public.accountrole;
DROP SEQUENCE public.accountremoteaccessseq;
DROP TABLE public.accountremoteaccess;
DROP SEQUENCE public.accountrecordingchannelseq;
DROP TABLE public.accountrecordingchannel;
DROP SEQUENCE public.accountpreferenceseq;
DROP TABLE public.accountpreference;
DROP SEQUENCE public.accountpinseq;
DROP TABLE public.accountpin;
DROP TABLE public.accountlastplayedmedia;
DROP SEQUENCE public.accountaccountroleseq;
DROP TABLE public.accountaccountrole;
DROP TABLE public.account;
DROP SEQUENCE public.accessvideoseq;
DROP SEQUENCE public.accessseq;
DROP TABLE public.accessrightuserserviceid;
DROP SEQUENCE public.accessrightseq;
DROP TABLE public.accessrightpluginid;
DROP TABLE public.accessrightdeviceclassid;
DROP TABLE public.accessrightconcurrentusers;
DROP TABLE public.accessrightchannelid;
DROP TABLE public.accessrightchannelcategory;
DROP SEQUENCE public.accessrightcasstatusseq;
DROP TABLE public.accessrightcasstatus;
DROP TABLE public.accessrightappid;
DROP TABLE public.accessrightallplugins;
DROP TABLE public.accessrightalldeviceclasses;
DROP TABLE public.accessrightallchannels;
DROP TABLE public.accessrightallapps;
DROP TABLE public.accessright;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accessright; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessright (
    accessrightid bigint NOT NULL,
    starttime timestamp with time zone,
    finishtime timestamp with time zone,
    sessionaccountingid text NOT NULL,
    purchaseid bigint,
    productitemid bigint,
    accessrighttype character varying(45) NOT NULL,
    enabled boolean NOT NULL,
    productid bigint,
    packageid bigint
);


ALTER TABLE public.accessright OWNER TO tahiti;

--
-- Name: accessrightallapps; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightallapps (
    accessrightid bigint NOT NULL
);


ALTER TABLE public.accessrightallapps OWNER TO tahiti;

--
-- Name: accessrightallchannels; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightallchannels (
    accessrightid bigint NOT NULL,
    casstatus text
);


ALTER TABLE public.accessrightallchannels OWNER TO tahiti;

--
-- Name: accessrightalldeviceclasses; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightalldeviceclasses (
    accessrightid bigint NOT NULL
);


ALTER TABLE public.accessrightalldeviceclasses OWNER TO tahiti;

--
-- Name: accessrightallplugins; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightallplugins (
    accessrightid bigint NOT NULL
);


ALTER TABLE public.accessrightallplugins OWNER TO tahiti;

--
-- Name: accessrightappid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightappid (
    accessrightid bigint NOT NULL,
    appid character varying(255) NOT NULL
);


ALTER TABLE public.accessrightappid OWNER TO tahiti;

--
-- Name: accessrightcasstatus; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightcasstatus (
    accessrightcasstatusid bigint NOT NULL,
    accessrightid bigint NOT NULL,
    vodkatvchannelid text,
    casresult text
);


ALTER TABLE public.accessrightcasstatus OWNER TO tahiti;

--
-- Name: accessrightcasstatusseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accessrightcasstatusseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accessrightcasstatusseq OWNER TO tahiti;

--
-- Name: accessrightchannelcategory; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightchannelcategory (
    accessrightid bigint NOT NULL,
    categoryid bigint NOT NULL,
    casstatus text
);


ALTER TABLE public.accessrightchannelcategory OWNER TO tahiti;

--
-- Name: accessrightchannelid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightchannelid (
    accessrightid bigint NOT NULL,
    vodkatvchannelid character varying(255) NOT NULL,
    casstatus text
);


ALTER TABLE public.accessrightchannelid OWNER TO tahiti;

--
-- Name: accessrightconcurrentusers; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightconcurrentusers (
    accessrightid bigint NOT NULL,
    deviceclassid character varying(20),
    usersnum integer
);


ALTER TABLE public.accessrightconcurrentusers OWNER TO tahiti;

--
-- Name: accessrightdeviceclassid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightdeviceclassid (
    accessrightid bigint NOT NULL,
    deviceclassid character varying(20) NOT NULL,
    deviceid bigint
);


ALTER TABLE public.accessrightdeviceclassid OWNER TO tahiti;

--
-- Name: accessrightpluginid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightpluginid (
    accessrightid bigint NOT NULL,
    pluginconfigurationid character varying(255) NOT NULL
);


ALTER TABLE public.accessrightpluginid OWNER TO tahiti;

--
-- Name: accessrightseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accessrightseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accessrightseq OWNER TO tahiti;

--
-- Name: accessrightuserserviceid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accessrightuserserviceid (
    accessrightid bigint NOT NULL,
    userserviceid bigint NOT NULL
);


ALTER TABLE public.accessrightuserserviceid OWNER TO tahiti;

--
-- Name: accessseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accessseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accessseq OWNER TO tahiti;

--
-- Name: accessvideoseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accessvideoseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accessvideoseq OWNER TO tahiti;

--
-- Name: account; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE account (
    accountid bigint NOT NULL,
    accountname text NOT NULL,
    creditid bigint,
    sessionaccountingid text NOT NULL,
    startday timestamp with time zone,
    finishday timestamp with time zone
);


ALTER TABLE public.account OWNER TO tahiti;

--
-- Name: accountaccountrole; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accountaccountrole (
    id bigint NOT NULL,
    rolename text NOT NULL,
    accountid bigint NOT NULL
);


ALTER TABLE public.accountaccountrole OWNER TO tahiti;

--
-- Name: accountaccountroleseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accountaccountroleseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accountaccountroleseq OWNER TO tahiti;

--
-- Name: accountlastplayedmedia; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accountlastplayedmedia (
    accountid bigint NOT NULL,
    mediatype character varying(50) NOT NULL,
    mediaid character varying(255) NOT NULL
);


ALTER TABLE public.accountlastplayedmedia OWNER TO tahiti;

--
-- Name: accountpin; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accountpin (
    accountpinid bigint NOT NULL,
    accountid bigint NOT NULL,
    pinvalue text NOT NULL,
    pintype text NOT NULL
);


ALTER TABLE public.accountpin OWNER TO tahiti;

--
-- Name: accountpinseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accountpinseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accountpinseq OWNER TO tahiti;

--
-- Name: accountpreference; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accountpreference (
    id bigint NOT NULL,
    deviceid bigint,
    preferencekey character varying(255) NOT NULL,
    preferencevalue character varying(255) NOT NULL,
    accountid bigint NOT NULL
);


ALTER TABLE public.accountpreference OWNER TO tahiti;

--
-- Name: accountpreferenceseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accountpreferenceseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accountpreferenceseq OWNER TO tahiti;

--
-- Name: accountrecordingchannel; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accountrecordingchannel (
    accountrecordingchannelid bigint NOT NULL,
    accountid bigint NOT NULL,
    vodkatvchannelid character varying(255) NOT NULL,
    recconfirmdate timestamp with time zone,
    recactive boolean NOT NULL
);


ALTER TABLE public.accountrecordingchannel OWNER TO tahiti;

--
-- Name: accountrecordingchannelseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accountrecordingchannelseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accountrecordingchannelseq OWNER TO tahiti;

--
-- Name: accountremoteaccess; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accountremoteaccess (
    id bigint NOT NULL,
    accountid bigint NOT NULL,
    loginname text,
    encpassword text,
    creationdate timestamp with time zone NOT NULL,
    activationdate timestamp with time zone,
    activationcode text,
    activationcodevaliduntil timestamp with time zone,
    passwordrecoverycode text,
    passwordrecoverycodevaliduntil timestamp with time zone
);


ALTER TABLE public.accountremoteaccess OWNER TO tahiti;

--
-- Name: accountremoteaccessseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accountremoteaccessseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accountremoteaccessseq OWNER TO tahiti;

--
-- Name: accountrole; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accountrole (
    name text NOT NULL
);


ALTER TABLE public.accountrole OWNER TO tahiti;

--
-- Name: accountscreensaver; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE accountscreensaver (
    id bigint NOT NULL,
    accountid bigint NOT NULL,
    screensaverid bigint NOT NULL
);


ALTER TABLE public.accountscreensaver OWNER TO tahiti;

--
-- Name: accountscreensaverseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accountscreensaverseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accountscreensaverseq OWNER TO tahiti;

--
-- Name: accountseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE accountseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accountseq OWNER TO tahiti;

--
-- Name: advertisingconfig; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE advertisingconfig (
    id bigint NOT NULL,
    frequencyonplay double precision,
    frequencyonzapping double precision,
    skipoffset bigint,
    maxperday integer,
    maxperweek integer,
    maxpermonth integer
);


ALTER TABLE public.advertisingconfig OWNER TO tahiti;

--
-- Name: advertisingconfigseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE advertisingconfigseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertisingconfigseq OWNER TO tahiti;

--
-- Name: advertisingmedia; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE advertisingmedia (
    id bigint NOT NULL,
    assetid text NOT NULL,
    advertisingtype text NOT NULL,
    clickurl text,
    maxperday integer,
    maxperweek integer,
    maxpermonth integer
);


ALTER TABLE public.advertisingmedia OWNER TO tahiti;

--
-- Name: advertisingmediaseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE advertisingmediaseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertisingmediaseq OWNER TO tahiti;

--
-- Name: advertisingmetadataserver; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE advertisingmetadataserver (
    id bigint NOT NULL,
    hostmetadataserver text NOT NULL,
    portmetadataserver text NOT NULL,
    loginmetadataserver text,
    passwordmetadataserver text
);


ALTER TABLE public.advertisingmetadataserver OWNER TO tahiti;

--
-- Name: advertisingmetadataserverseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE advertisingmetadataserverseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertisingmetadataserverseq OWNER TO tahiti;

--
-- Name: advertisingtagtreenode; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE advertisingtagtreenode (
    id bigint NOT NULL,
    tagnodeid bigint,
    assetid text NOT NULL
);


ALTER TABLE public.advertisingtagtreenode OWNER TO tahiti;

--
-- Name: advertisingtagtreenodeseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE advertisingtagtreenodeseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertisingtagtreenodeseq OWNER TO tahiti;

--
-- Name: advertisingvisualization; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE advertisingvisualization (
    id bigint NOT NULL,
    accountid bigint NOT NULL,
    assetid text NOT NULL,
    advertisingtype text NOT NULL,
    creationtime timestamp with time zone NOT NULL
);


ALTER TABLE public.advertisingvisualization OWNER TO tahiti;

--
-- Name: advertisingvisualizationseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE advertisingvisualizationseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advertisingvisualizationseq OWNER TO tahiti;

--
-- Name: am_alarmobjectseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE am_alarmobjectseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.am_alarmobjectseq OWNER TO tahiti;

--
-- Name: am_multicastgroupalarm; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE am_multicastgroupalarm (
    id bigint NOT NULL,
    state character varying NOT NULL,
    multicastgroup character varying(15) NOT NULL,
    port integer NOT NULL
);


ALTER TABLE public.am_multicastgroupalarm OWNER TO tahiti;

--
-- Name: am_stbalarm; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE am_stbalarm (
    id bigint NOT NULL,
    state character varying NOT NULL,
    ipaddress character varying(15) NOT NULL
);


ALTER TABLE public.am_stbalarm OWNER TO tahiti;

--
-- Name: application; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE application (
    id character varying(255) NOT NULL,
    appname text NOT NULL,
    iconpathenabled text NOT NULL,
    iconpathdisabled text,
    installerpath text,
    enabled boolean NOT NULL,
    exectype text NOT NULL,
    appid text,
    version text
);


ALTER TABLE public.application OWNER TO tahiti;

--
-- Name: applicationorder; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE applicationorder (
    appid character varying(255) NOT NULL,
    parentappid character varying(255),
    "position" integer NOT NULL,
    id bigint NOT NULL
);


ALTER TABLE public.applicationorder OWNER TO tahiti;

--
-- Name: applicationorderseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE applicationorderseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.applicationorderseq OWNER TO tahiti;

--
-- Name: asseti18n; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE asseti18n (
    asseti18nid bigint NOT NULL,
    userid character varying(50) NOT NULL,
    assetid character varying NOT NULL,
    assettitle character varying NOT NULL,
    localeid character varying(255) NOT NULL
);


ALTER TABLE public.asseti18n OWNER TO tahiti;

--
-- Name: asseti18nseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE asseti18nseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asseti18nseq OWNER TO tahiti;

--
-- Name: audiocodec; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE audiocodec (
    audiocodecid bigint NOT NULL,
    codec text NOT NULL
);


ALTER TABLE public.audiocodec OWNER TO tahiti;

--
-- Name: audiocodecseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE audiocodecseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audiocodecseq OWNER TO tahiti;

--
-- Name: authtoken; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE authtoken (
    deviceid bigint,
    physicalid text,
    accountid bigint,
    sessionaccountingid character varying(254),
    deviceip character varying(254),
    finishdate timestamp with time zone,
    token character varying(254) NOT NULL,
    useragent text,
    userid text,
    finishdatepersistence timestamp with time zone,
    creationdate timestamp with time zone NOT NULL,
    renewdate timestamp with time zone,
    lastupdatedeviceip character varying(254),
    deviceclass text,
    deletiondate timestamp with time zone,
    lastaccessdate timestamp with time zone
);


ALTER TABLE public.authtoken OWNER TO tahiti;

--
-- Name: stbstatusstorage; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE stbstatusstorage (
    token text,
    version text,
    mwversion character varying(255),
    updatetime timestamp with time zone NOT NULL,
    id bigint NOT NULL,
    stbid bigint NOT NULL
);


ALTER TABLE public.stbstatusstorage OWNER TO tahiti;

--
-- Name: authtokenandstbstatusstorage; Type: VIEW; Schema: public; Owner: tahiti
--

CREATE VIEW authtokenandstbstatusstorage AS
 SELECT a.deviceid,
    a.physicalid,
    a.accountid,
    a.sessionaccountingid,
    a.deviceip,
    a.finishdate,
    a.token,
    a.useragent,
    a.userid,
    a.finishdatepersistence,
    a.creationdate,
    a.renewdate,
    a.lastupdatedeviceip,
    a.deviceclass,
    a.deletiondate,
    a.lastaccessdate,
    b.version,
    b.mwversion
   FROM (authtoken a
     LEFT JOIN stbstatusstorage b ON (((a.token)::text = b.token)));


ALTER TABLE public.authtokenandstbstatusstorage OWNER TO tahiti;

--
-- Name: banner; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE banner (
    filename character varying(255),
    bannerid bigint NOT NULL,
    tagtreenodeid bigint,
    name character varying(255),
    link character varying(255),
    namei18nid bigint
);


ALTER TABLE public.banner OWNER TO tahiti;

--
-- Name: bannerseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE bannerseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bannerseq OWNER TO tahiti;

--
-- Name: basicpackage; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE basicpackage (
    id bigint NOT NULL,
    name character varying(45) NOT NULL,
    namei18n bigint,
    price double precision NOT NULL,
    subscriptiontype character varying(45) NOT NULL,
    renovationtype character varying(45) NOT NULL,
    tagtreenodeid bigint,
    initialprice double precision,
    initialpricedurationdays integer,
    starttime timestamp with time zone,
    endtime timestamp with time zone,
    active boolean NOT NULL,
    currencyid bigint NOT NULL,
    logofilename character varying,
    descriptioni18n bigint,
    shortdescriptioni18n bigint,
    stbcustomizationid bigint,
    pccustomizationid bigint,
    discount double precision,
    registrationfee double precision,
    imagefilename text,
    trialdays integer,
    clientpurchasedenied boolean DEFAULT false NOT NULL
);


ALTER TABLE public.basicpackage OWNER TO tahiti;

--
-- Name: basicpackageseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE basicpackageseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.basicpackageseq OWNER TO tahiti;

--
-- Name: billing; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE billing (
    billingid bigint NOT NULL,
    purchaseid bigint,
    starttime timestamp with time zone NOT NULL,
    finishtime timestamp with time zone,
    price double precision NOT NULL,
    creationtime timestamp with time zone NOT NULL,
    sessionaccountingid text NOT NULL,
    currencyid bigint,
    billingtype text NOT NULL
);


ALTER TABLE public.billing OWNER TO tahiti;

--
-- Name: billingseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE billingseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.billingseq OWNER TO tahiti;

--
-- Name: device; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE device (
    id bigint NOT NULL,
    deviceclass character varying(20),
    roomid text NOT NULL,
    physicalid text NOT NULL,
    description text,
    tagtreenodeid bigint,
    finishtime timestamp with time zone
);


ALTER TABLE public.device OWNER TO tahiti;

--
-- Name: purchase; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE purchase (
    purchaseid bigint NOT NULL,
    sessionaccountingid text NOT NULL,
    productid bigint,
    productname text,
    contractdate timestamp with time zone NOT NULL,
    cancelationdate timestamp with time zone,
    subscriptiontype character varying(45) NOT NULL,
    renovationtype character varying(45) NOT NULL,
    lastprocessdate timestamp with time zone,
    enabled boolean NOT NULL,
    packageid bigint,
    validuntil timestamp with time zone,
    renewalday integer,
    initialperiod boolean NOT NULL,
    activationdate timestamp with time zone,
    trialfinishdate timestamp with time zone,
    purchasedate timestamp with time zone NOT NULL,
    roomdescription text,
    tagtreenodename text,
    voucherid bigint,
    voucher text,
    voucherfinishdate timestamp with time zone
);


ALTER TABLE public.purchase OWNER TO tahiti;

--
-- Name: room; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE room (
    roomid character varying(50) NOT NULL,
    description text,
    tagtreenodeid bigint
);


ALTER TABLE public.room OWNER TO tahiti;

--
-- Name: sessionaccounting; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE sessionaccounting (
    sessionaccountingid text NOT NULL,
    roomid text,
    startday timestamp with time zone NOT NULL,
    finishday timestamp with time zone,
    disabled boolean NOT NULL,
    datefirstuse timestamp with time zone,
    inactive boolean NOT NULL,
    datelastaccess timestamp with time zone
);


ALTER TABLE public.sessionaccounting OWNER TO tahiti;

--
-- Name: stbtagtreenode; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE stbtagtreenode (
    id bigint NOT NULL,
    treeid bigint NOT NULL,
    name text NOT NULL,
    lft integer NOT NULL,
    rgt integer NOT NULL,
    parentid bigint,
    pos integer NOT NULL
);


ALTER TABLE public.stbtagtreenode OWNER TO tahiti;

--
-- Name: billingservice; Type: VIEW; Schema: public; Owner: tahiti
--

CREATE VIEW billingservice AS
 SELECT b.billingid,
    r.roomid,
    r.description AS roomdescription,
    t.id AS tagtreenodeid,
    t.name AS tagtreenodename,
    p.productid,
    p.packageid,
    p.productname,
    b.starttime,
    b.finishtime,
    p.contractdate,
    count(d.physicalid) AS numberstbs
   FROM (((((billing b
     JOIN purchase p ON ((b.purchaseid = p.purchaseid)))
     JOIN sessionaccounting s ON ((p.sessionaccountingid = s.sessionaccountingid)))
     JOIN room r ON ((s.roomid = (r.roomid)::text)))
     LEFT JOIN stbtagtreenode t ON ((r.tagtreenodeid = t.id)))
     JOIN device d ON (((r.roomid)::text = d.roomid)))
  WHERE ((d.deviceclass)::text ~~ '%STB%'::text)
  GROUP BY b.billingid, r.roomid, r.description, t.id, t.name, p.productid, p.packageid, p.productname, b.starttime, b.finishtime, p.contractdate;


ALTER TABLE public.billingservice OWNER TO tahiti;

--
-- Name: cacheserver; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE cacheserver (
    id bigint NOT NULL,
    host character varying NOT NULL,
    port bigint NOT NULL
);


ALTER TABLE public.cacheserver OWNER TO tahiti;

--
-- Name: cacheserverseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE cacheserverseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cacheserverseq OWNER TO tahiti;

--
-- Name: cacheversion; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE cacheversion (
    cachetype character varying(100) NOT NULL,
    version integer NOT NULL
);


ALTER TABLE public.cacheversion OWNER TO tahiti;

--
-- Name: catalogtree; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE catalogtree (
    catalogtreename character varying(255) NOT NULL
);


ALTER TABLE public.catalogtree OWNER TO tahiti;

--
-- Name: catalogtreenode; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE catalogtreenode (
    catalogtreename character varying(255) NOT NULL,
    catalogtreenodeid bigint NOT NULL,
    parentcatalogtreenodeid bigint,
    catalogtreenodenameid character varying(255) NOT NULL,
    "position" integer NOT NULL
);


ALTER TABLE public.catalogtreenode OWNER TO tahiti;

--
-- Name: catalogtreenodeasset; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE catalogtreenodeasset (
    catalogtreenodeassetid bigint NOT NULL,
    catalogtreenodeid bigint NOT NULL,
    assetid character varying(255) NOT NULL,
    "position" integer NOT NULL
);


ALTER TABLE public.catalogtreenodeasset OWNER TO tahiti;

--
-- Name: catalogtreenodeassetseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE catalogtreenodeassetseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalogtreenodeassetseq OWNER TO tahiti;

--
-- Name: catalogtreenodename; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE catalogtreenodename (
    catalogtreenodenameid bigint NOT NULL,
    catalogtreenodeid bigint NOT NULL,
    shortname character varying(255),
    name character varying(255),
    locale character varying(255)
);


ALTER TABLE public.catalogtreenodename OWNER TO tahiti;

--
-- Name: catalogtreenodenameseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE catalogtreenodenameseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalogtreenodenameseq OWNER TO tahiti;

--
-- Name: catalogtreenodeproperty; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE catalogtreenodeproperty (
    catalogtreenodepropertyid bigint NOT NULL,
    catalogtreenodeid bigint NOT NULL,
    skey character varying(255) NOT NULL,
    svalue character varying(255) NOT NULL
);


ALTER TABLE public.catalogtreenodeproperty OWNER TO tahiti;

--
-- Name: catalogtreenodepropertyseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE catalogtreenodepropertyseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalogtreenodepropertyseq OWNER TO tahiti;

--
-- Name: catalogtreenoderole; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE catalogtreenoderole (
    id bigint NOT NULL,
    catalogtreenodeid bigint NOT NULL,
    roleid text NOT NULL
);


ALTER TABLE public.catalogtreenoderole OWNER TO tahiti;

--
-- Name: catalogtreenoderoleseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE catalogtreenoderoleseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalogtreenoderoleseq OWNER TO tahiti;

--
-- Name: catalogtreenodeseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE catalogtreenodeseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalogtreenodeseq OWNER TO tahiti;

--
-- Name: category; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE category (
    categoryid character varying(20) NOT NULL,
    miliseconds bigint,
    ispremiere boolean NOT NULL
);


ALTER TABLE public.category OWNER TO tahiti;

--
-- Name: channelaccessarea; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channelaccessarea (
    id bigint NOT NULL,
    vodkatvchannelid text NOT NULL,
    networkareaid bigint,
    tagnodeid bigint
);


ALTER TABLE public.channelaccessarea OWNER TO tahiti;

--
-- Name: channelaccessareaseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channelaccessareaseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channelaccessareaseq OWNER TO tahiti;

--
-- Name: channelaccesstypesubscription; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channelaccesstypesubscription (
    channelaccesstypesubscriptionid bigint NOT NULL,
    accountid bigint NOT NULL,
    channelaccesstype character varying(255) NOT NULL
);


ALTER TABLE public.channelaccesstypesubscription OWNER TO tahiti;

--
-- Name: channelaccesstypesubscriptionseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channelaccesstypesubscriptionseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channelaccesstypesubscriptionseq OWNER TO tahiti;

--
-- Name: channelaudiopid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channelaudiopid (
    channelaudiopidid bigint NOT NULL,
    language character varying(50) NOT NULL,
    pid integer NOT NULL,
    channeldataplayinfoid bigint NOT NULL,
    codec text
);


ALTER TABLE public.channelaudiopid OWNER TO tahiti;

--
-- Name: channelaudiopidseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channelaudiopidseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channelaudiopidseq OWNER TO tahiti;

--
-- Name: channelcategory; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channelcategory (
    channelcategoryid bigint NOT NULL,
    vodkatvchannelid text NOT NULL,
    categoryid bigint NOT NULL
);


ALTER TABLE public.channelcategory OWNER TO tahiti;

--
-- Name: channelcategoryseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channelcategoryseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channelcategoryseq OWNER TO tahiti;

--
-- Name: channeldata; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channeldata (
    vodkatvchannelid character varying(255) NOT NULL,
    channeltype character varying(50),
    languagecode character varying(3),
    countrycode character varying(3),
    textchannelid character varying(50),
    npvrpausesupported character varying(12),
    npvrstartoversupported character varying(12),
    npvrprerollassetid text,
    pauselivetvtgaptimestart integer,
    pauselivetvtgaptimeend integer,
    startovergaptimestart integer,
    startovergaptimeend integer,
    channelid character varying(255),
    npvrfragmentsize integer,
    npvrstartoverdefaulttimestart integer,
    npvrstartoverdefaulttimeend integer,
    channeldescription text,
    npvrrectime integer,
    channelname text,
    logourl text,
    pvrsupported boolean NOT NULL,
    accesstype character varying(50) NOT NULL,
    caschannelid text,
    availableepgdays integer,
    active boolean DEFAULT true NOT NULL,
    localpvrsupported boolean,
    hbbtvurl text,
    id bigint NOT NULL,
    parentalratingid bigint
);


ALTER TABLE public.channeldata OWNER TO tahiti;

--
-- Name: channeldataplayinfo; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channeldataplayinfo (
    channeldataplayinfoid bigint NOT NULL,
    vodkatvchannelid character varying(255) NOT NULL,
    devicetypeid bigint,
    "position" integer NOT NULL,
    channelurl text,
    prebuffermillis integer,
    prebuffernetpvrmillis integer,
    netpvrurl text,
    netpvrchannelid text,
    aclchannelid text,
    aclchannelprotocol character varying(50),
    sourceuri character varying(255),
    streamname character varying(50)
);


ALTER TABLE public.channeldataplayinfo OWNER TO tahiti;

--
-- Name: channeldataplayinfoseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channeldataplayinfoseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channeldataplayinfoseq OWNER TO tahiti;

--
-- Name: channeldataseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channeldataseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channeldataseq OWNER TO tahiti;

--
-- Name: channellist; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channellist (
    id bigint NOT NULL,
    name text NOT NULL,
    typelist integer NOT NULL
);


ALTER TABLE public.channellist OWNER TO tahiti;

--
-- Name: channellistitem; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channellistitem (
    id bigint NOT NULL,
    channellistid bigint NOT NULL,
    channelnumber integer NOT NULL,
    visible boolean NOT NULL,
    internalchannelid bigint NOT NULL
);


ALTER TABLE public.channellistitem OWNER TO tahiti;

--
-- Name: channellistitemseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channellistitemseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channellistitemseq OWNER TO tahiti;

--
-- Name: channellistseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channellistseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channellistseq OWNER TO tahiti;

--
-- Name: channelnumber; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channelnumber (
    id bigint NOT NULL,
    deviceid bigint,
    vodkatvchannelid character varying(255) NOT NULL,
    channelnumber integer,
    ord timestamp with time zone,
    accountid bigint
);


ALTER TABLE public.channelnumber OWNER TO tahiti;

--
-- Name: channelnumberseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channelnumberseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channelnumberseq OWNER TO tahiti;

--
-- Name: channelsourceuri; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channelsourceuri (
    channelsourceuriid bigint NOT NULL,
    channeldataplayinfoid bigint NOT NULL,
    sourceuri character varying(250),
    bitrate bigint
);


ALTER TABLE public.channelsourceuri OWNER TO tahiti;

--
-- Name: channelsourceuriseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channelsourceuriseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channelsourceuriseq OWNER TO tahiti;

--
-- Name: channelvideopid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channelvideopid (
    channelvideopidid bigint NOT NULL,
    channeldataplayinfoid bigint NOT NULL,
    codec text,
    pid integer NOT NULL
);


ALTER TABLE public.channelvideopid OWNER TO tahiti;

--
-- Name: channelvideopidseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channelvideopidseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channelvideopidseq OWNER TO tahiti;

--
-- Name: channelvisibility; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE channelvisibility (
    id bigint NOT NULL,
    deviceid bigint,
    vodkatvchannelid character varying(255) NOT NULL,
    visible boolean,
    accountid bigint
);


ALTER TABLE public.channelvisibility OWNER TO tahiti;

--
-- Name: channelvisibilityseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE channelvisibilityseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channelvisibilityseq OWNER TO tahiti;

--
-- Name: collectionrule; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE collectionrule (
    collectionruleid bigint NOT NULL,
    ruleid bigint NOT NULL,
    collectionid character varying(20) NOT NULL
);


ALTER TABLE public.collectionrule OWNER TO tahiti;

--
-- Name: collectionruleseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE collectionruleseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.collectionruleseq OWNER TO tahiti;

--
-- Name: contentcategory; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE contentcategory (
    categoryid bigint NOT NULL,
    categoryname text
);


ALTER TABLE public.contentcategory OWNER TO tahiti;

--
-- Name: contentcategoryseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE contentcategoryseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contentcategoryseq OWNER TO tahiti;

--
-- Name: credit; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE credit (
    creditid bigint NOT NULL,
    amount double precision
);


ALTER TABLE public.credit OWNER TO tahiti;

--
-- Name: creditseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE creditseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.creditseq OWNER TO tahiti;

--
-- Name: currency; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE currency (
    currencyid bigint NOT NULL,
    visualname text NOT NULL,
    defaultcurrency boolean DEFAULT false NOT NULL,
    currencykey character varying(3)
);


ALTER TABLE public.currency OWNER TO tahiti;

--
-- Name: currencyseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE currencyseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.currencyseq OWNER TO tahiti;

--
-- Name: customization; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE customization (
    id bigint NOT NULL,
    name text NOT NULL,
    description text,
    screenshotfilename character varying,
    deviceclass character varying(20) NOT NULL,
    mainapplicationid bigint
);


ALTER TABLE public.customization OWNER TO tahiti;

--
-- Name: customizationpath; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE customizationpath (
    id bigint NOT NULL,
    deviceclass character varying(20) NOT NULL,
    customizationid bigint NOT NULL,
    path character varying(255) NOT NULL
);


ALTER TABLE public.customizationpath OWNER TO tahiti;

--
-- Name: customizationpathseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE customizationpathseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customizationpathseq OWNER TO tahiti;

--
-- Name: customizationseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE customizationseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customizationseq OWNER TO tahiti;

--
-- Name: customizationsystemapplication; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE customizationsystemapplication (
    id bigint NOT NULL,
    customizationid bigint NOT NULL,
    systemapplicationid bigint NOT NULL
);


ALTER TABLE public.customizationsystemapplication OWNER TO tahiti;

--
-- Name: customizationsystemapplicationseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE customizationsystemapplicationseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customizationsystemapplicationseq OWNER TO tahiti;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20)
);


ALTER TABLE public.databasechangelog OWNER TO tahiti;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO tahiti;

--
-- Name: defaultbasicpackage; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE defaultbasicpackage (
    id bigint NOT NULL,
    packageid bigint NOT NULL,
    tagtreenodeid bigint NOT NULL
);


ALTER TABLE public.defaultbasicpackage OWNER TO tahiti;

--
-- Name: defaultbasicpackageseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE defaultbasicpackageseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.defaultbasicpackageseq OWNER TO tahiti;

--
-- Name: desktop; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktop (
    id bigint NOT NULL,
    title text
);


ALTER TABLE public.desktop OWNER TO tahiti;

--
-- Name: desktoparea; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktoparea (
    id bigint NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    name text,
    desktopareatype text,
    desktopid bigint,
    texti18n bigint,
    backgroundi18n bigint
);


ALTER TABLE public.desktoparea OWNER TO tahiti;

--
-- Name: desktopareaseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE desktopareaseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktopareaseq OWNER TO tahiti;

--
-- Name: desktopconfig; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktopconfig (
    id bigint NOT NULL,
    packageid bigint
);


ALTER TABLE public.desktopconfig OWNER TO tahiti;

--
-- Name: desktopconfigdesktop; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktopconfigdesktop (
    id bigint NOT NULL,
    desktopconfigid bigint NOT NULL,
    desktopid bigint NOT NULL,
    defaultdesktop boolean NOT NULL,
    "position" integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.desktopconfigdesktop OWNER TO tahiti;

--
-- Name: desktopconfigdesktopseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE desktopconfigdesktopseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktopconfigdesktopseq OWNER TO tahiti;

--
-- Name: desktopconfigseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE desktopconfigseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktopconfigseq OWNER TO tahiti;

--
-- Name: desktopitem; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktopitem (
    id bigint NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    title text,
    iconfocus text,
    iconblur text,
    desktopitemtype text,
    desktopid bigint,
    useritem boolean DEFAULT false NOT NULL,
    userdesktopid bigint,
    focusable boolean DEFAULT true NOT NULL,
    titlei18n bigint
);


ALTER TABLE public.desktopitem OWNER TO tahiti;

--
-- Name: desktopitemapp; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktopitemapp (
    id bigint NOT NULL,
    appid text
);


ALTER TABLE public.desktopitemapp OWNER TO tahiti;

--
-- Name: desktopitemmedia; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktopitemmedia (
    id bigint NOT NULL,
    subtype text,
    vodkatvchannelid text,
    file text,
    assetid text,
    url text,
    dtvchannelid text,
    filetype text,
    device text,
    path text,
    playlistid text,
    elementid text
);


ALTER TABLE public.desktopitemmedia OWNER TO tahiti;

--
-- Name: desktopitemplugin; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktopitemplugin (
    id bigint NOT NULL,
    appid text,
    pluginconfigurationid text
);


ALTER TABLE public.desktopitemplugin OWNER TO tahiti;

--
-- Name: desktopitemseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE desktopitemseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktopitemseq OWNER TO tahiti;

--
-- Name: desktopitemweb; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktopitemweb (
    id bigint NOT NULL,
    url text
);


ALTER TABLE public.desktopitemweb OWNER TO tahiti;

--
-- Name: desktopitemwidget; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE desktopitemwidget (
    id bigint NOT NULL,
    subtype text,
    appid text,
    url text,
    refreshsecs integer
);


ALTER TABLE public.desktopitemwidget OWNER TO tahiti;

--
-- Name: desktopseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE desktopseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktopseq OWNER TO tahiti;

--
-- Name: developer; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE developer (
    developerid character varying(30) NOT NULL,
    description text
);


ALTER TABLE public.developer OWNER TO tahiti;

--
-- Name: developerseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE developerseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.developerseq OWNER TO tahiti;

--
-- Name: deviceclass; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE deviceclass (
    id character varying(20) NOT NULL,
    visualname character varying(50) NOT NULL
);


ALTER TABLE public.deviceclass OWNER TO tahiti;

--
-- Name: deviceseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE deviceseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deviceseq OWNER TO tahiti;

--
-- Name: devicestatuseventsserver; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE devicestatuseventsserver (
    deviceid bigint NOT NULL,
    token text,
    lastconnectiontoeventsserver timestamp with time zone,
    lastdisconnectionfromeventsserver timestamp with time zone
);


ALTER TABLE public.devicestatuseventsserver OWNER TO tahiti;

--
-- Name: devicetype; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE devicetype (
    devicetypeid bigint NOT NULL,
    useragent character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    deviceclass character varying(20) DEFAULT 'OTHER'::character varying
);


ALTER TABLE public.devicetype OWNER TO tahiti;

--
-- Name: devicetypeseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE devicetypeseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devicetypeseq OWNER TO tahiti;

--
-- Name: dialingcode; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE dialingcode (
    id bigint NOT NULL,
    code character varying NOT NULL,
    country character varying(2) NOT NULL
);


ALTER TABLE public.dialingcode OWNER TO tahiti;

--
-- Name: dialingcodeseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE dialingcodeseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dialingcodeseq OWNER TO tahiti;

--
-- Name: emailtemplate; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE emailtemplate (
    id bigint NOT NULL,
    subject bigint,
    content bigint,
    type character varying(50)
);


ALTER TABLE public.emailtemplate OWNER TO tahiti;

--
-- Name: emailtemplateseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE emailtemplateseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.emailtemplateseq OWNER TO tahiti;

--
-- Name: eventsserver; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE eventsserver (
    id bigint NOT NULL,
    internalhost text,
    internalwsport integer,
    httpport integer,
    publichost text,
    publicwsport text
);


ALTER TABLE public.eventsserver OWNER TO tahiti;

--
-- Name: eventsserverseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE eventsserverseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.eventsserverseq OWNER TO tahiti;

--
-- Name: favorite; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE favorite (
    favoriteid bigint NOT NULL,
    accountid bigint NOT NULL,
    assetid character varying(255) NOT NULL,
    favoritedate timestamp with time zone
);


ALTER TABLE public.favorite OWNER TO tahiti;

--
-- Name: favoritechannel; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE favoritechannel (
    id bigint NOT NULL,
    vodkatvchannelid character varying(255) NOT NULL,
    accountid bigint NOT NULL,
    "position" integer NOT NULL
);


ALTER TABLE public.favoritechannel OWNER TO tahiti;

--
-- Name: favoritechannelseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE favoritechannelseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.favoritechannelseq OWNER TO tahiti;

--
-- Name: favoriteseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE favoriteseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.favoriteseq OWNER TO tahiti;

--
-- Name: filterlistconfiguration; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE filterlistconfiguration (
    filterlistconfigurationid bigint NOT NULL,
    listconfigurationid bigint NOT NULL,
    count integer,
    assetcollectionid character varying(255)
);


ALTER TABLE public.filterlistconfiguration OWNER TO tahiti;

--
-- Name: filterlistconfigurationseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE filterlistconfigurationseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.filterlistconfigurationseq OWNER TO tahiti;

--
-- Name: firmware; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE firmware (
    version text NOT NULL,
    filename text NOT NULL,
    description text,
    creationtime timestamp with time zone NOT NULL
);


ALTER TABLE public.firmware OWNER TO tahiti;

--
-- Name: firmwareseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE firmwareseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.firmwareseq OWNER TO tahiti;

--
-- Name: genericinfo; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE genericinfo (
    id bigint NOT NULL,
    type character varying,
    name character varying,
    description character varying,
    address character varying,
    phone character varying
);


ALTER TABLE public.genericinfo OWNER TO tahiti;

--
-- Name: genericinfoseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE genericinfoseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genericinfoseq OWNER TO tahiti;

--
-- Name: guest; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE guest (
    sessionaccountingid text NOT NULL,
    name text NOT NULL,
    locale text,
    guesttitle character varying(10),
    surname text,
    birthday timestamp with time zone,
    phonenumber text,
    mobilephonenumber text,
    email text,
    address text,
    zipcode text,
    city text,
    countrycode character varying(10),
    countryoforigincode character varying(10)
);


ALTER TABLE public.guest OWNER TO tahiti;

--
-- Name: guestservices; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE guestservices (
    id bigint NOT NULL,
    hotelservicesurl text,
    hotelservicesurltopcss text,
    hotelservicesurlleftcss text,
    hotelservicesurlwidthcss text,
    hotelservicesurlheightcss text,
    hotelnamei18n bigint,
    hotelimagefilename character varying(255),
    expresscheckoutinfomessagei18n bigint,
    expresscheckoutconfirmationmessagei18n bigint,
    expresscheckouterrormessagei18n bigint,
    hotelhelpurl text,
    hotelhelpurltopcss text,
    hotelhelpurlleftcss text,
    hotelhelpurlwidthcss text,
    hotelhelpurlheightcss text,
    showremotecheckoutoption boolean NOT NULL,
    welcomemessagei18n bigint
);


ALTER TABLE public.guestservices OWNER TO tahiti;

--
-- Name: guestservicesseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE guestservicesseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guestservicesseq OWNER TO tahiti;

--
-- Name: hotel; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE hotel (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description character varying
);


ALTER TABLE public.hotel OWNER TO tahiti;

--
-- Name: hotelseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE hotelseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hotelseq OWNER TO tahiti;

--
-- Name: i18n; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE i18n (
    i18nid bigint NOT NULL,
    es text,
    en text,
    it text,
    fr text,
    ar text,
    de text
);


ALTER TABLE public.i18n OWNER TO tahiti;

--
-- Name: i18nseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE i18nseq
    START WITH 7
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.i18nseq OWNER TO tahiti;

--
-- Name: image; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE image (
    filename text NOT NULL,
    bytes bytea
);


ALTER TABLE public.image OWNER TO tahiti;

--
-- Name: incompatibleproduct; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE incompatibleproduct (
    id bigint NOT NULL,
    productid bigint,
    incompatibleproductid bigint
);


ALTER TABLE public.incompatibleproduct OWNER TO tahiti;

--
-- Name: incompatibleproductseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE incompatibleproductseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.incompatibleproductseq OWNER TO tahiti;

--
-- Name: interaction; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE interaction (
    assetid character varying(255) NOT NULL,
    accountid bigint NOT NULL,
    points integer NOT NULL
);


ALTER TABLE public.interaction OWNER TO tahiti;

--
-- Name: itemmappingscreen; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE itemmappingscreen (
    itemmappingscreenid bigint NOT NULL,
    playlistmappingscreenid bigint NOT NULL,
    "position" integer NOT NULL,
    assetid character varying(255),
    runtime bigint,
    vodkatvchannelid character varying(255)
);


ALTER TABLE public.itemmappingscreen OWNER TO tahiti;

--
-- Name: itemmappingscreenseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE itemmappingscreenseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.itemmappingscreenseq OWNER TO tahiti;

--
-- Name: language; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE language (
    languageid character varying(5) NOT NULL,
    language character varying(25) NOT NULL,
    languagei18n bigint
);


ALTER TABLE public.language OWNER TO tahiti;

--
-- Name: link; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE link (
    id bigint NOT NULL,
    name text NOT NULL,
    namei18nid bigint NOT NULL,
    description text,
    url text NOT NULL
);


ALTER TABLE public.link OWNER TO tahiti;

--
-- Name: linkseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE linkseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.linkseq OWNER TO tahiti;

--
-- Name: listconfiguration; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE listconfiguration (
    listconfigurationid bigint NOT NULL,
    name text NOT NULL,
    description text,
    count integer,
    assetcollectionid text,
    sortby character varying(255),
    newassetsposition character varying(255),
    sortbynewassetsposition character varying(255),
    orderassets character varying(255),
    ordernewassetsposition character varying(255)
);


ALTER TABLE public.listconfiguration OWNER TO tahiti;

--
-- Name: listconfigurationasset; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE listconfigurationasset (
    listconfigurationassetid bigint NOT NULL,
    listconfigurationid bigint NOT NULL,
    assetid text NOT NULL,
    "position" integer NOT NULL
);


ALTER TABLE public.listconfigurationasset OWNER TO tahiti;

--
-- Name: listconfigurationassetseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE listconfigurationassetseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.listconfigurationassetseq OWNER TO tahiti;

--
-- Name: listconfigurationseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE listconfigurationseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.listconfigurationseq OWNER TO tahiti;

--
-- Name: logging_event_id_seq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE logging_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logging_event_id_seq OWNER TO tahiti;

--
-- Name: logging_event; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE logging_event (
    timestmp bigint NOT NULL,
    formatted_message text NOT NULL,
    logger_name character varying(254) NOT NULL,
    level_string character varying(254) NOT NULL,
    thread_name character varying(254),
    reference_flag smallint,
    caller_filename character varying(254) NOT NULL,
    caller_class character varying(254) NOT NULL,
    caller_method character varying(254) NOT NULL,
    caller_line character(4) NOT NULL,
    event_id integer DEFAULT nextval('logging_event_id_seq'::regclass) NOT NULL
);


ALTER TABLE public.logging_event OWNER TO tahiti;

--
-- Name: logging_event_exception; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE logging_event_exception (
    event_id integer NOT NULL,
    i smallint NOT NULL,
    trace_line character varying(254) NOT NULL
);


ALTER TABLE public.logging_event_exception OWNER TO tahiti;

--
-- Name: logging_event_property; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE logging_event_property (
    event_id integer NOT NULL,
    mapped_key character varying(254) NOT NULL,
    mapped_value character varying(1024)
);


ALTER TABLE public.logging_event_property OWNER TO tahiti;

--
-- Name: mappingscreenconfiguration; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE mappingscreenconfiguration (
    reloadeversec integer,
    reloadonstartvideo boolean NOT NULL,
    reloadonstartcycle boolean NOT NULL,
    vodkatvchannelid character varying(255)
);


ALTER TABLE public.mappingscreenconfiguration OWNER TO tahiti;

--
-- Name: masternode; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE masternode (
    ip character varying(255) NOT NULL,
    lasttime timestamp with time zone
);


ALTER TABLE public.masternode OWNER TO tahiti;

--
-- Name: memcachedkey; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE memcachedkey (
    id bigint NOT NULL,
    cachekey text,
    accountid bigint,
    sessionaccountingid text,
    deviceid bigint,
    creationtime timestamp with time zone NOT NULL,
    validuntil timestamp with time zone NOT NULL,
    cachetype text NOT NULL
);


ALTER TABLE public.memcachedkey OWNER TO tahiti;

--
-- Name: memcachedkeyseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE memcachedkeyseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.memcachedkeyseq OWNER TO tahiti;

--
-- Name: menuoption; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE menuoption (
    id text NOT NULL,
    labeli18n bigint,
    helpmessagei18n bigint,
    type character varying(100),
    path text,
    "position" integer NOT NULL,
    parentmenuid text
);


ALTER TABLE public.menuoption OWNER TO tahiti;

--
-- Name: menuoptionseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE menuoptionseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menuoptionseq OWNER TO tahiti;

--
-- Name: menuseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE menuseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menuseq OWNER TO tahiti;

--
-- Name: message; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE message (
    id bigint NOT NULL,
    creationdate timestamp with time zone,
    type character varying(255) DEFAULT 'TEXT'::character varying,
    status character varying(255) NOT NULL,
    statuschangedate timestamp with time zone NOT NULL,
    stbid bigint,
    accountid bigint,
    messageidpms character varying(255),
    expirationdate timestamp with time zone
);


ALTER TABLE public.message OWNER TO tahiti;

--
-- Name: messagemail; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE messagemail (
    id bigint NOT NULL,
    subject text,
    content text
);


ALTER TABLE public.messagemail OWNER TO tahiti;

--
-- Name: messagepopup; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE messagepopup (
    id bigint NOT NULL,
    title text,
    text text,
    size character varying(25) DEFAULT 'MEDIUM'::character varying NOT NULL
);


ALTER TABLE public.messagepopup OWNER TO tahiti;

--
-- Name: messagescript; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE messagescript (
    id bigint NOT NULL,
    script text NOT NULL
);


ALTER TABLE public.messagescript OWNER TO tahiti;

--
-- Name: messageseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE messageseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messageseq OWNER TO tahiti;

--
-- Name: messagewakeup; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE messagewakeup (
    id bigint NOT NULL,
    wakeupdate timestamp with time zone NOT NULL,
    label text,
    state character varying(25) NOT NULL
);


ALTER TABLE public.messagewakeup OWNER TO tahiti;

--
-- Name: networkarea; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE networkarea (
    id bigint NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.networkarea OWNER TO tahiti;

--
-- Name: networkareacountry; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE networkareacountry (
    id bigint NOT NULL,
    networkareaid bigint NOT NULL,
    countrycode character varying(10)
);


ALTER TABLE public.networkareacountry OWNER TO tahiti;

--
-- Name: networkareacountryseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE networkareacountryseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.networkareacountryseq OWNER TO tahiti;

--
-- Name: networkareaipv4subnet; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE networkareaipv4subnet (
    id bigint NOT NULL,
    networkareaid bigint NOT NULL,
    subnet text,
    mask text
);


ALTER TABLE public.networkareaipv4subnet OWNER TO tahiti;

--
-- Name: networkareaipv4subnetseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE networkareaipv4subnetseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.networkareaipv4subnetseq OWNER TO tahiti;

--
-- Name: networkareaseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE networkareaseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.networkareaseq OWNER TO tahiti;

--
-- Name: outputsprotection; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE outputsprotection (
    accountid bigint NOT NULL,
    outputsprotection boolean
);


ALTER TABLE public.outputsprotection OWNER TO tahiti;

--
-- Name: parentalcontrollevel; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE parentalcontrollevel (
    accountid bigint NOT NULL,
    maxratingid text
);


ALTER TABLE public.parentalcontrollevel OWNER TO tahiti;

--
-- Name: parentalrating; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE parentalrating (
    name text NOT NULL,
    "position" integer NOT NULL,
    id bigint NOT NULL
);


ALTER TABLE public.parentalrating OWNER TO tahiti;

--
-- Name: parentalratingmapping; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE parentalratingmapping (
    id bigint NOT NULL,
    parentalratingid bigint NOT NULL,
    mediaparentalratingid text
);


ALTER TABLE public.parentalratingmapping OWNER TO tahiti;

--
-- Name: parentalratingmappingseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE parentalratingmappingseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parentalratingmappingseq OWNER TO tahiti;

--
-- Name: parentalratingseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE parentalratingseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parentalratingseq OWNER TO tahiti;

--
-- Name: periodicity; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE periodicity (
    periodicityid bigint NOT NULL,
    ruleid bigint NOT NULL,
    weekday character varying(9),
    starttime time without time zone,
    finishtime time without time zone,
    day timestamp with time zone,
    CONSTRAINT periodicity_weekday_check CHECK (((weekday)::text = ANY (ARRAY[('Monday'::character varying)::text, ('Tuesday'::character varying)::text, ('Wednesday'::character varying)::text, ('Thursday'::character varying)::text, ('Friday'::character varying)::text, ('Saturday'::character varying)::text, ('Sunday'::character varying)::text])))
);


ALTER TABLE public.periodicity OWNER TO tahiti;

--
-- Name: periodicityseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE periodicityseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.periodicityseq OWNER TO tahiti;

--
-- Name: photo; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE photo (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description character varying,
    image bytea,
    filename character varying
);


ALTER TABLE public.photo OWNER TO tahiti;

--
-- Name: photoseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE photoseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.photoseq OWNER TO tahiti;

--
-- Name: pingtable; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE pingtable (
    foo character(1)
);


ALTER TABLE public.pingtable OWNER TO tahiti;

--
-- Name: playerconfiguration; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE playerconfiguration (
    playerconfigurationid bigint NOT NULL,
    protocol text NOT NULL,
    prebuffermillis integer,
    inactivitynotificationtimeminutes integer
);


ALTER TABLE public.playerconfiguration OWNER TO tahiti;

--
-- Name: playerconfigurationseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE playerconfigurationseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.playerconfigurationseq OWNER TO tahiti;

--
-- Name: playlistmappingscreen; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE playlistmappingscreen (
    playlistmappingscreenid bigint NOT NULL,
    roomid text,
    active character varying(50) NOT NULL
);


ALTER TABLE public.playlistmappingscreen OWNER TO tahiti;

--
-- Name: playlistmappingscreenseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE playlistmappingscreenseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.playlistmappingscreenseq OWNER TO tahiti;

--
-- Name: plugin_webbrows_stburlitem; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE plugin_webbrows_stburlitem (
    id bigint NOT NULL,
    stbid bigint NOT NULL,
    lft integer NOT NULL,
    rgt integer NOT NULL,
    itemid text,
    typenode integer NOT NULL,
    url text,
    topcss text,
    leftcss text,
    widthcss text,
    heightcss text
);


ALTER TABLE public.plugin_webbrows_stburlitem OWNER TO tahiti;

--
-- Name: plugin_webbrows_stburlitemlang; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE plugin_webbrows_stburlitemlang (
    id bigint NOT NULL,
    stburlitemid bigint NOT NULL,
    code text NOT NULL,
    str text NOT NULL
);


ALTER TABLE public.plugin_webbrows_stburlitemlang OWNER TO tahiti;

--
-- Name: plugin_webbrows_stburlitemlangseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE plugin_webbrows_stburlitemlangseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plugin_webbrows_stburlitemlangseq OWNER TO tahiti;

--
-- Name: plugin_webbrows_stburlitemseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE plugin_webbrows_stburlitemseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plugin_webbrows_stburlitemseq OWNER TO tahiti;

--
-- Name: pluginconfiguration; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE pluginconfiguration (
    pluginconfigurationid character varying(50) NOT NULL,
    pluginscreenid character varying(50),
    selectaccount boolean NOT NULL,
    password boolean NOT NULL,
    classnameinformation character varying(255),
    imgmenuon character varying(255) NOT NULL,
    imgmenuoff character varying(255) NOT NULL,
    beta boolean NOT NULL,
    version character varying(15),
    applicationid character varying(50),
    corelib character varying(15),
    jsdk character varying(15)
);


ALTER TABLE public.pluginconfiguration OWNER TO tahiti;

--
-- Name: pluginconfigurationstart; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE pluginconfigurationstart (
    pluginconfigurationstartid bigint NOT NULL,
    pluginconfigurationid character varying(50) NOT NULL,
    paramname character varying(50) NOT NULL,
    paramvalue character varying(255) NOT NULL,
    paramvariable character varying(255) NOT NULL,
    paramproperty character varying(255) NOT NULL,
    stbtypeid character varying(20)
);


ALTER TABLE public.pluginconfigurationstart OWNER TO tahiti;

--
-- Name: pluginconfigurationstartseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE pluginconfigurationstartseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pluginconfigurationstartseq OWNER TO tahiti;

--
-- Name: pluginscreen; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE pluginscreen (
    pluginscreenid character varying(50) NOT NULL,
    pluginconfigurationid character varying(50) NOT NULL,
    actionclass character varying(255),
    returnpage character varying(255),
    id bigint NOT NULL,
    stbtypeid character varying(20)
);


ALTER TABLE public.pluginscreen OWNER TO tahiti;

--
-- Name: pluginscreenseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE pluginscreenseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pluginscreenseq OWNER TO tahiti;

--
-- Name: predefinedmessage; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE predefinedmessage (
    id bigint NOT NULL,
    title character varying(45),
    size character varying(50) DEFAULT 'LARGE'::character varying NOT NULL,
    type character varying(255) DEFAULT 'TEXT'::character varying,
    subject text,
    content text,
    text text,
    script text
);


ALTER TABLE public.predefinedmessage OWNER TO tahiti;

--
-- Name: predefinedmessageseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE predefinedmessageseq
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.predefinedmessageseq OWNER TO tahiti;

--
-- Name: preferencemenuoption; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE preferencemenuoption (
    preferencemenuoptionid character varying(255) NOT NULL,
    preferencemenuoptionparentid character varying(255),
    preferencemenuoptionposition integer NOT NULL
);


ALTER TABLE public.preferencemenuoption OWNER TO tahiti;

--
-- Name: product; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE product (
    id bigint NOT NULL,
    name character varying(45) NOT NULL,
    price double precision NOT NULL,
    subscriptiontype character varying(45) NOT NULL,
    renovationtype character varying(45) NOT NULL,
    tagtreenodeid bigint,
    initialprice double precision,
    initialpricedurationdays integer,
    starttime timestamp with time zone,
    endtime timestamp with time zone,
    active boolean NOT NULL,
    currencyid bigint NOT NULL,
    namei18n bigint,
    descriptioni18n bigint,
    logofilename character varying,
    shortdescriptioni18n bigint,
    discount double precision,
    registrationfee double precision,
    imagefilename text,
    trialdays integer,
    clientpurchasedenied boolean DEFAULT false NOT NULL
);


ALTER TABLE public.product OWNER TO tahiti;

--
-- Name: productincluded; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productincluded (
    id bigint NOT NULL,
    packageid bigint NOT NULL,
    productid bigint NOT NULL
);


ALTER TABLE public.productincluded OWNER TO tahiti;

--
-- Name: productincludedseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE productincludedseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.productincludedseq OWNER TO tahiti;

--
-- Name: productitem; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitem (
    productitemid bigint NOT NULL,
    productid bigint NOT NULL,
    itemtype character varying(45) NOT NULL,
    starttime timestamp with time zone,
    endtime timestamp with time zone,
    durationtimedays integer
);


ALTER TABLE public.productitem OWNER TO tahiti;

--
-- Name: productitemallapps; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemallapps (
    productitemid bigint NOT NULL
);


ALTER TABLE public.productitemallapps OWNER TO tahiti;

--
-- Name: productitemallchannels; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemallchannels (
    productitemid bigint NOT NULL
);


ALTER TABLE public.productitemallchannels OWNER TO tahiti;

--
-- Name: productitemalldeviceclasses; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemalldeviceclasses (
    productitemid bigint NOT NULL
);


ALTER TABLE public.productitemalldeviceclasses OWNER TO tahiti;

--
-- Name: productitemallplugins; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemallplugins (
    productitemid bigint NOT NULL
);


ALTER TABLE public.productitemallplugins OWNER TO tahiti;

--
-- Name: productitemappid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemappid (
    productitemid bigint NOT NULL,
    appid character varying(255) NOT NULL
);


ALTER TABLE public.productitemappid OWNER TO tahiti;

--
-- Name: productitemchannelcategory; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemchannelcategory (
    productitemid bigint NOT NULL,
    categoryid bigint NOT NULL
);


ALTER TABLE public.productitemchannelcategory OWNER TO tahiti;

--
-- Name: productitemchannelid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemchannelid (
    productitemid bigint NOT NULL,
    vodkatvchannelid character varying(255) NOT NULL
);


ALTER TABLE public.productitemchannelid OWNER TO tahiti;

--
-- Name: productitemconcurrentusers; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemconcurrentusers (
    productitemid bigint NOT NULL,
    deviceclassid character varying(20),
    usersnum integer
);


ALTER TABLE public.productitemconcurrentusers OWNER TO tahiti;

--
-- Name: productitemdeviceclassid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemdeviceclassid (
    productitemid bigint NOT NULL,
    deviceclassid character varying(20) NOT NULL
);


ALTER TABLE public.productitemdeviceclassid OWNER TO tahiti;

--
-- Name: productitempluginid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitempluginid (
    productitemid bigint NOT NULL,
    pluginconfigurationid character varying(255) NOT NULL
);


ALTER TABLE public.productitempluginid OWNER TO tahiti;

--
-- Name: productitemseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE productitemseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.productitemseq OWNER TO tahiti;

--
-- Name: productitemuserserviceid; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE productitemuserserviceid (
    productitemid bigint NOT NULL,
    userserviceid bigint NOT NULL
);


ALTER TABLE public.productitemuserserviceid OWNER TO tahiti;

--
-- Name: productseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE productseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.productseq OWNER TO tahiti;

--
-- Name: property; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE property (
    propertyid bigint NOT NULL,
    propertyname character varying(255) NOT NULL,
    propertyvalue bytea,
    propertyvalueasstring text
);


ALTER TABLE public.property OWNER TO tahiti;

--
-- Name: propertyseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE propertyseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.propertyseq OWNER TO tahiti;

--
-- Name: protectedtargetaudience; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE protectedtargetaudience (
    targetaudienceid character varying(255) NOT NULL,
    isprotected boolean NOT NULL
);


ALTER TABLE public.protectedtargetaudience OWNER TO tahiti;

--
-- Name: protectedtargetaudienceseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE protectedtargetaudienceseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.protectedtargetaudienceseq OWNER TO tahiti;

--
-- Name: purchaseconfigseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE purchaseconfigseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchaseconfigseq OWNER TO tahiti;

--
-- Name: purchaseseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE purchaseseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchaseseq OWNER TO tahiti;

--
-- Name: pvrtask; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE pvrtask (
    pvrtaskid bigint NOT NULL,
    pvrhedid character varying(255),
    stbid bigint NOT NULL,
    vodkatvchannelid character varying(255),
    starttime timestamp with time zone NOT NULL,
    finishtime timestamp with time zone NOT NULL,
    pvrstate character varying(20) NOT NULL,
    name text NOT NULL,
    observation character varying(255),
    accountid bigint NOT NULL,
    archived boolean NOT NULL,
    filename text,
    dtvchannelid text,
    channelname text
);


ALTER TABLE public.pvrtask OWNER TO tahiti;

--
-- Name: pvrtaskseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE pvrtaskseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pvrtaskseq OWNER TO tahiti;

--
-- Name: rent; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE rent (
    rentid bigint NOT NULL,
    stbid bigint,
    accountid bigint NOT NULL,
    assetid character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    rulename character varying(20),
    ruleid bigint,
    price double precision,
    sessionaccountingid text,
    currency character varying(255),
    starttime timestamp with time zone,
    finishtime timestamp with time zone,
    pmsstate character varying(20) NOT NULL
);


ALTER TABLE public.rent OWNER TO tahiti;

--
-- Name: rentingvalidity; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE rentingvalidity (
    rentingvalidityid bigint NOT NULL,
    assetcollectionid text,
    validity bigint,
    rentingvalidityposition bigint NOT NULL
);


ALTER TABLE public.rentingvalidity OWNER TO tahiti;

--
-- Name: rentingvalidityseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE rentingvalidityseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rentingvalidityseq OWNER TO tahiti;

--
-- Name: rentseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE rentseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rentseq OWNER TO tahiti;

--
-- Name: role; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE role (
    name character varying(100) NOT NULL
);


ALTER TABLE public.role OWNER TO tahiti;

--
-- Name: roleassetcollection; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE roleassetcollection (
    id bigint NOT NULL,
    roleid text NOT NULL,
    assetcollectioncontentid text NOT NULL
);


ALTER TABLE public.roleassetcollection OWNER TO tahiti;

--
-- Name: roleassetcollectioncontent; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE roleassetcollectioncontent (
    id text NOT NULL,
    showcontents boolean NOT NULL
);


ALTER TABLE public.roleassetcollectioncontent OWNER TO tahiti;

--
-- Name: roleassetcollectionseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE roleassetcollectionseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roleassetcollectionseq OWNER TO tahiti;

--
-- Name: roleattribute; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE roleattribute (
    id bigint NOT NULL,
    rolename character varying(100) NOT NULL,
    classname text NOT NULL,
    attrtohide text NOT NULL
);


ALTER TABLE public.roleattribute OWNER TO tahiti;

--
-- Name: roleattributeseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE roleattributeseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roleattributeseq OWNER TO tahiti;

--
-- Name: rolemenuoption; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE rolemenuoption (
    rolename character varying(100) NOT NULL,
    menuoptionid character varying(100) NOT NULL,
    id bigint NOT NULL
);


ALTER TABLE public.rolemenuoption OWNER TO tahiti;

--
-- Name: rolemenuoptionseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE rolemenuoptionseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rolemenuoptionseq OWNER TO tahiti;

--
-- Name: rss; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE rss (
    id bigint NOT NULL,
    name text NOT NULL,
    namei18nid bigint NOT NULL,
    description text,
    url text NOT NULL,
    count integer
);


ALTER TABLE public.rss OWNER TO tahiti;

--
-- Name: rssseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE rssseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rssseq OWNER TO tahiti;

--
-- Name: rule; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE rule (
    ruleid bigint NOT NULL,
    rulename character varying(20) NOT NULL,
    ruleposition integer NOT NULL,
    categoryid character varying(20),
    genreid character varying(20),
    floornumber integer,
    rulescollectionname character varying(20) NOT NULL,
    roomid text,
    price double precision,
    factorbahamasprice double precision,
    stbid bigint
);


ALTER TABLE public.rule OWNER TO tahiti;

--
-- Name: rulescollection; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE rulescollection (
    rulescollectionname character varying(20) NOT NULL,
    startvalidtime timestamp with time zone,
    finishvalidtime timestamp with time zone
);


ALTER TABLE public.rulescollection OWNER TO tahiti;

--
-- Name: ruleseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE ruleseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ruleseq OWNER TO tahiti;

--
-- Name: schedulelink; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE schedulelink (
    id bigint NOT NULL,
    name text NOT NULL,
    namei18nid bigint NOT NULL,
    description text,
    url text NOT NULL,
    starttime timestamp with time zone,
    finishtime timestamp with time zone,
    enabled boolean NOT NULL
);


ALTER TABLE public.schedulelink OWNER TO tahiti;

--
-- Name: schedulelinkseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE schedulelinkseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedulelinkseq OWNER TO tahiti;

--
-- Name: screensaver; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE screensaver (
    id bigint NOT NULL,
    name character varying NOT NULL,
    version character varying NOT NULL,
    namei18nid bigint NOT NULL,
    url character varying NOT NULL
);


ALTER TABLE public.screensaver OWNER TO tahiti;

--
-- Name: screensaverseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE screensaverseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.screensaverseq OWNER TO tahiti;

--
-- Name: sessionaccountingseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE sessionaccountingseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sessionaccountingseq OWNER TO tahiti;

--
-- Name: stbinformationscreen; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE stbinformationscreen (
    stbid bigint NOT NULL,
    forceupdate boolean,
    isplaying boolean,
    lastcode character varying(10),
    firstrequest timestamp with time zone,
    lastrequest timestamp with time zone,
    lastrequestforceupdate timestamp with time zone
);


ALTER TABLE public.stbinformationscreen OWNER TO tahiti;

--
-- Name: stblanguageseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE stblanguageseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stblanguageseq OWNER TO tahiti;

--
-- Name: stbsession; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE stbsession (
    stbid bigint NOT NULL,
    newsession boolean,
    startdate timestamp with time zone
);


ALTER TABLE public.stbsession OWNER TO tahiti;

--
-- Name: stbstatus; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE stbstatus (
    stbid bigint NOT NULL,
    version text,
    ean character varying(255),
    batch character varying(255),
    id character varying(255),
    serverup character varying(255),
    mwversion character varying(255),
    wifidevice character varying(255),
    wifimac character varying(255),
    wifistatus character varying(255),
    wifiap character varying(255),
    wifiessid character varying(255),
    wifikey character varying(255),
    wifiquality character varying(255),
    wifiip character varying(255),
    wifimask character varying(255),
    wifigw character varying(255),
    wifidns character varying(255),
    wifidhcp character varying(255),
    wireddevice character varying(255),
    wiredmac character varying(255),
    wiredstatus character varying(255),
    wiredip character varying(255),
    wiredmask character varying(255),
    wiredgw character varying(255),
    wireddns character varying(255),
    wireddhcp character varying(255),
    lastupdatetime timestamp with time zone NOT NULL,
    useragent text,
    remoteaddr text,
    token text
);


ALTER TABLE public.stbstatus OWNER TO tahiti;

--
-- Name: stbstatusseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE stbstatusseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stbstatusseq OWNER TO tahiti;

--
-- Name: stbstatusstorageseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE stbstatusstorageseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stbstatusstorageseq OWNER TO tahiti;

--
-- Name: stbtagtree; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE stbtagtree (
    id bigint NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.stbtagtree OWNER TO tahiti;

--
-- Name: stbtagtreenodechannellist; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE stbtagtreenodechannellist (
    stbtagtreenodeid bigint NOT NULL,
    channellistid bigint NOT NULL
);


ALTER TABLE public.stbtagtreenodechannellist OWNER TO tahiti;

--
-- Name: stbtagtreenodeseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE stbtagtreenodeseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stbtagtreenodeseq OWNER TO tahiti;

--
-- Name: stbtagtreeseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE stbtagtreeseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stbtagtreeseq OWNER TO tahiti;

--
-- Name: stbupgrade; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE stbupgrade (
    id bigint NOT NULL,
    fromversion text,
    toversion text NOT NULL,
    stbid bigint NOT NULL,
    forced boolean DEFAULT false NOT NULL,
    creationtime timestamp with time zone NOT NULL,
    scheduletime timestamp with time zone NOT NULL,
    notifiedtime timestamp with time zone,
    lasttime timestamp with time zone,
    lastprogress integer,
    laststatus character varying(255),
    state character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    result character varying(255)
);


ALTER TABLE public.stbupgrade OWNER TO tahiti;

--
-- Name: stbupgradeseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE stbupgradeseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stbupgradeseq OWNER TO tahiti;

--
-- Name: subscriptioncatalog; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE subscriptioncatalog (
    id bigint NOT NULL,
    productid bigint,
    packageid bigint,
    "position" integer NOT NULL
);


ALTER TABLE public.subscriptioncatalog OWNER TO tahiti;

--
-- Name: subscriptioncatalogseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE subscriptioncatalogseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscriptioncatalogseq OWNER TO tahiti;

--
-- Name: subscriptiondependencies; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE subscriptiondependencies (
    id bigint NOT NULL,
    productid bigint,
    packageid bigint
);


ALTER TABLE public.subscriptiondependencies OWNER TO tahiti;

--
-- Name: subscriptiondependenciesseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE subscriptiondependenciesseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscriptiondependenciesseq OWNER TO tahiti;

--
-- Name: systemapplication; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE systemapplication (
    id bigint NOT NULL,
    appid character varying(255) NOT NULL,
    appname text NOT NULL,
    changes text,
    version character varying(255) NOT NULL,
    screenshotpath text,
    installerpath text NOT NULL,
    description text,
    deviceclass character varying(20) NOT NULL
);


ALTER TABLE public.systemapplication OWNER TO tahiti;

--
-- Name: systemapplicationseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE systemapplicationseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.systemapplicationseq OWNER TO tahiti;

--
-- Name: tahitiversion; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE tahitiversion (
    number bigint NOT NULL
);


ALTER TABLE public.tahitiversion OWNER TO tahiti;

--
-- Name: timezone; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE timezone (
    timezoneid bigint NOT NULL,
    timezonecode text,
    tagtreenodeid bigint
);


ALTER TABLE public.timezone OWNER TO tahiti;

--
-- Name: timezoneseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE timezoneseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.timezoneseq OWNER TO tahiti;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE user_roles (
    user_name character varying(50) NOT NULL,
    role_name character varying(50) NOT NULL
);


ALTER TABLE public.user_roles OWNER TO tahiti;

--
-- Name: userdesktop; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE userdesktop (
    id bigint NOT NULL,
    desktopid bigint,
    accountid bigint NOT NULL,
    "position" integer NOT NULL
);


ALTER TABLE public.userdesktop OWNER TO tahiti;

--
-- Name: userdesktopseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE userdesktopseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userdesktopseq OWNER TO tahiti;

--
-- Name: users; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE users (
    user_name character varying(50) NOT NULL,
    user_pass character varying(50) NOT NULL
);


ALTER TABLE public.users OWNER TO tahiti;

--
-- Name: userservice; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE userservice (
    userserviceid bigint NOT NULL,
    service character varying(255)
);


ALTER TABLE public.userservice OWNER TO tahiti;

--
-- Name: videoclubpluginconfig; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoclubpluginconfig (
    id bigint NOT NULL,
    renterrormessagei18n bigint
);


ALTER TABLE public.videoclubpluginconfig OWNER TO tahiti;

--
-- Name: videoclubpluginconfigseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE videoclubpluginconfigseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.videoclubpluginconfigseq OWNER TO tahiti;

--
-- Name: videocodec; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videocodec (
    videocodecid bigint NOT NULL,
    codec text NOT NULL
);


ALTER TABLE public.videocodec OWNER TO tahiti;

--
-- Name: videocodecseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE videocodecseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.videocodecseq OWNER TO tahiti;

--
-- Name: videoserver; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoserver (
    id bigint NOT NULL,
    name text NOT NULL,
    publicip character varying(255),
    publicport integer,
    internalip character varying(255),
    internalport integer,
    maxrequests integer,
    type text,
    videoservertype text,
    networkareaid bigint,
    maxinactivityseconds integer,
    active boolean DEFAULT true,
    protocol text
);


ALTER TABLE public.videoserver OWNER TO tahiti;

--
-- Name: videoserveraction; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoserveraction (
    id bigint NOT NULL,
    videoserverid bigint NOT NULL,
    appname text,
    creationdate timestamp with time zone NOT NULL,
    streamname text,
    action text
);


ALTER TABLE public.videoserveraction OWNER TO tahiti;

--
-- Name: videoserveractionseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE videoserveractionseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.videoserveractionseq OWNER TO tahiti;

--
-- Name: videoservercontent; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoservercontent (
    id bigint NOT NULL,
    videoserverid bigint NOT NULL,
    videoservercontent text
);


ALTER TABLE public.videoservercontent OWNER TO tahiti;

--
-- Name: videoservercontentseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE videoservercontentseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.videoservercontentseq OWNER TO tahiti;

--
-- Name: videoserverdevicetype; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoserverdevicetype (
    id bigint NOT NULL,
    videoserverid bigint NOT NULL,
    devicetypeid bigint NOT NULL
);


ALTER TABLE public.videoserverdevicetype OWNER TO tahiti;

--
-- Name: videoserverdevicetypeseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE videoserverdevicetypeseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.videoserverdevicetypeseq OWNER TO tahiti;

--
-- Name: videoservergroup; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoservergroup (
    id bigint NOT NULL,
    appname character varying(100) NOT NULL,
    type character varying(50) NOT NULL,
    storage text
);


ALTER TABLE public.videoservergroup OWNER TO tahiti;

--
-- Name: videoservergroupchanneldataplayinfo; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoservergroupchanneldataplayinfo (
    videoservergroupid bigint NOT NULL,
    channeldataplayinfoid bigint NOT NULL
);


ALTER TABLE public.videoservergroupchanneldataplayinfo OWNER TO tahiti;

--
-- Name: videoservergroupseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE videoservergroupseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.videoservergroupseq OWNER TO tahiti;

--
-- Name: videoservergroupvideoserver; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoservergroupvideoserver (
    videoservergroupid bigint NOT NULL,
    videoserverid bigint NOT NULL
);


ALTER TABLE public.videoservergroupvideoserver OWNER TO tahiti;

--
-- Name: videoserverseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE videoserverseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.videoserverseq OWNER TO tahiti;

--
-- Name: videoserverstatus; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoserverstatus (
    id bigint NOT NULL,
    videoserverid bigint NOT NULL,
    appname text,
    connectedclients integer,
    lastupdate timestamp with time zone NOT NULL
);


ALTER TABLE public.videoserverstatus OWNER TO tahiti;

--
-- Name: videoserverstatusseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE videoserverstatusseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.videoserverstatusseq OWNER TO tahiti;

--
-- Name: videoserverstreamstatus; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoserverstreamstatus (
    videoserverstatusid bigint,
    streamname text NOT NULL,
    bitrate bigint,
    running boolean,
    id bigint NOT NULL
);


ALTER TABLE public.videoserverstreamstatus OWNER TO tahiti;

--
-- Name: videoserverstreamstatusseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE videoserverstreamstatusseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.videoserverstreamstatusseq OWNER TO tahiti;

--
-- Name: videoserverswisstv; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoserverswisstv (
    id bigint NOT NULL,
    applicationkey text,
    login text,
    password text,
    encodingtype text,
    prefix text
);


ALTER TABLE public.videoserverswisstv OWNER TO tahiti;

--
-- Name: videoservervodkatickets; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoservervodkatickets (
    id bigint NOT NULL,
    ticketserverip text,
    ticketserverport integer
);


ALTER TABLE public.videoservervodkatickets OWNER TO tahiti;

--
-- Name: videoserverwowza; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE videoserverwowza (
    id bigint NOT NULL,
    ticketserverip text,
    ticketserverport integer
);


ALTER TABLE public.videoserverwowza OWNER TO tahiti;

--
-- Name: visualization; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE visualization (
    visualizationid bigint NOT NULL,
    rentid bigint NOT NULL,
    miliseconds bigint,
    date timestamp with time zone
);


ALTER TABLE public.visualization OWNER TO tahiti;

--
-- Name: visualizationseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE visualizationseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visualizationseq OWNER TO tahiti;

--
-- Name: voucher; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE voucher (
    id bigint NOT NULL,
    voucher text NOT NULL,
    discount double precision NOT NULL,
    creationdate timestamp with time zone,
    startdate timestamp with time zone,
    finishdate timestamp with time zone,
    durationdays integer,
    maxusers integer
);


ALTER TABLE public.voucher OWNER TO tahiti;

--
-- Name: voucherseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE voucherseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.voucherseq OWNER TO tahiti;

--
-- Name: vouchervalidpackage; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE vouchervalidpackage (
    id bigint NOT NULL,
    voucherid bigint NOT NULL,
    packageid bigint NOT NULL
);


ALTER TABLE public.vouchervalidpackage OWNER TO tahiti;

--
-- Name: vouchervalidpackageseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE vouchervalidpackageseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vouchervalidpackageseq OWNER TO tahiti;

--
-- Name: vouchervalidproduct; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE vouchervalidproduct (
    id bigint NOT NULL,
    voucherid bigint NOT NULL,
    productid bigint NOT NULL
);


ALTER TABLE public.vouchervalidproduct OWNER TO tahiti;

--
-- Name: vouchervalidproductseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE vouchervalidproductseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vouchervalidproductseq OWNER TO tahiti;

--
-- Name: webbrowsingpluginconfig; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE webbrowsingpluginconfig (
    id bigint NOT NULL,
    disclaimermessagei18n bigint
);


ALTER TABLE public.webbrowsingpluginconfig OWNER TO tahiti;

--
-- Name: webbrowsingpluginconfigseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE webbrowsingpluginconfigseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.webbrowsingpluginconfigseq OWNER TO tahiti;

--
-- Name: welcomechannel; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE welcomechannel (
    welcomechannelid bigint NOT NULL,
    vodkatvchannelid character varying(255) NOT NULL,
    locale character varying(255)
);


ALTER TABLE public.welcomechannel OWNER TO tahiti;

--
-- Name: welcomechannelseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE welcomechannelseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.welcomechannelseq OWNER TO tahiti;

--
-- Name: wowzaaessharedkey; Type: TABLE; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE TABLE wowzaaessharedkey (
    id bigint NOT NULL,
    key text NOT NULL,
    validuntil timestamp with time zone NOT NULL
);


ALTER TABLE public.wowzaaessharedkey OWNER TO tahiti;

--
-- Name: wowzaaessharedkeyseq; Type: SEQUENCE; Schema: public; Owner: tahiti
--

CREATE SEQUENCE wowzaaessharedkeyseq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wowzaaessharedkeyseq OWNER TO tahiti;

--
-- Data for Name: accessright; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessright (accessrightid, starttime, finishtime, sessionaccountingid, purchaseid, productitemid, accessrighttype, enabled, productid, packageid) FROM stdin;
\.
COPY accessright (accessrightid, starttime, finishtime, sessionaccountingid, purchaseid, productitemid, accessrighttype, enabled, productid, packageid) FROM '$$PATH$$/4158.dat';

--
-- Data for Name: accessrightallapps; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightallapps (accessrightid) FROM stdin;
\.
COPY accessrightallapps (accessrightid) FROM '$$PATH$$/4159.dat';

--
-- Data for Name: accessrightallchannels; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightallchannels (accessrightid, casstatus) FROM stdin;
\.
COPY accessrightallchannels (accessrightid, casstatus) FROM '$$PATH$$/4160.dat';

--
-- Data for Name: accessrightalldeviceclasses; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightalldeviceclasses (accessrightid) FROM stdin;
\.
COPY accessrightalldeviceclasses (accessrightid) FROM '$$PATH$$/4161.dat';

--
-- Data for Name: accessrightallplugins; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightallplugins (accessrightid) FROM stdin;
\.
COPY accessrightallplugins (accessrightid) FROM '$$PATH$$/4162.dat';

--
-- Data for Name: accessrightappid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightappid (accessrightid, appid) FROM stdin;
\.
COPY accessrightappid (accessrightid, appid) FROM '$$PATH$$/4163.dat';

--
-- Data for Name: accessrightcasstatus; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightcasstatus (accessrightcasstatusid, accessrightid, vodkatvchannelid, casresult) FROM stdin;
\.
COPY accessrightcasstatus (accessrightcasstatusid, accessrightid, vodkatvchannelid, casresult) FROM '$$PATH$$/4164.dat';

--
-- Name: accessrightcasstatusseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accessrightcasstatusseq', 1, false);


--
-- Data for Name: accessrightchannelcategory; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightchannelcategory (accessrightid, categoryid, casstatus) FROM stdin;
\.
COPY accessrightchannelcategory (accessrightid, categoryid, casstatus) FROM '$$PATH$$/4166.dat';

--
-- Data for Name: accessrightchannelid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightchannelid (accessrightid, vodkatvchannelid, casstatus) FROM stdin;
\.
COPY accessrightchannelid (accessrightid, vodkatvchannelid, casstatus) FROM '$$PATH$$/4167.dat';

--
-- Data for Name: accessrightconcurrentusers; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightconcurrentusers (accessrightid, deviceclassid, usersnum) FROM stdin;
\.
COPY accessrightconcurrentusers (accessrightid, deviceclassid, usersnum) FROM '$$PATH$$/4168.dat';

--
-- Data for Name: accessrightdeviceclassid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightdeviceclassid (accessrightid, deviceclassid, deviceid) FROM stdin;
\.
COPY accessrightdeviceclassid (accessrightid, deviceclassid, deviceid) FROM '$$PATH$$/4169.dat';

--
-- Data for Name: accessrightpluginid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightpluginid (accessrightid, pluginconfigurationid) FROM stdin;
\.
COPY accessrightpluginid (accessrightid, pluginconfigurationid) FROM '$$PATH$$/4170.dat';

--
-- Name: accessrightseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accessrightseq', 8543, true);


--
-- Data for Name: accessrightuserserviceid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accessrightuserserviceid (accessrightid, userserviceid) FROM stdin;
\.
COPY accessrightuserserviceid (accessrightid, userserviceid) FROM '$$PATH$$/4172.dat';

--
-- Name: accessseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accessseq', 1, false);


--
-- Name: accessvideoseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accessvideoseq', 1, false);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY account (accountid, accountname, creditid, sessionaccountingid, startday, finishday) FROM stdin;
\.
COPY account (accountid, accountname, creditid, sessionaccountingid, startday, finishday) FROM '$$PATH$$/4175.dat';

--
-- Data for Name: accountaccountrole; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accountaccountrole (id, rolename, accountid) FROM stdin;
\.
COPY accountaccountrole (id, rolename, accountid) FROM '$$PATH$$/4176.dat';

--
-- Name: accountaccountroleseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accountaccountroleseq', 1, false);


--
-- Data for Name: accountlastplayedmedia; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accountlastplayedmedia (accountid, mediatype, mediaid) FROM stdin;
\.
COPY accountlastplayedmedia (accountid, mediatype, mediaid) FROM '$$PATH$$/4178.dat';

--
-- Data for Name: accountpin; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accountpin (accountpinid, accountid, pinvalue, pintype) FROM stdin;
\.
COPY accountpin (accountpinid, accountid, pinvalue, pintype) FROM '$$PATH$$/4179.dat';

--
-- Name: accountpinseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accountpinseq', 12, true);


--
-- Data for Name: accountpreference; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accountpreference (id, deviceid, preferencekey, preferencevalue, accountid) FROM stdin;
\.
COPY accountpreference (id, deviceid, preferencekey, preferencevalue, accountid) FROM '$$PATH$$/4181.dat';

--
-- Name: accountpreferenceseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accountpreferenceseq', 25408, true);


--
-- Data for Name: accountrecordingchannel; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accountrecordingchannel (accountrecordingchannelid, accountid, vodkatvchannelid, recconfirmdate, recactive) FROM stdin;
\.
COPY accountrecordingchannel (accountrecordingchannelid, accountid, vodkatvchannelid, recconfirmdate, recactive) FROM '$$PATH$$/4183.dat';

--
-- Name: accountrecordingchannelseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accountrecordingchannelseq', 1, false);


--
-- Data for Name: accountremoteaccess; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accountremoteaccess (id, accountid, loginname, encpassword, creationdate, activationdate, activationcode, activationcodevaliduntil, passwordrecoverycode, passwordrecoverycodevaliduntil) FROM stdin;
\.
COPY accountremoteaccess (id, accountid, loginname, encpassword, creationdate, activationdate, activationcode, activationcodevaliduntil, passwordrecoverycode, passwordrecoverycodevaliduntil) FROM '$$PATH$$/4185.dat';

--
-- Name: accountremoteaccessseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accountremoteaccessseq', 8544, true);


--
-- Data for Name: accountrole; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accountrole (name) FROM stdin;
\.
COPY accountrole (name) FROM '$$PATH$$/4187.dat';

--
-- Data for Name: accountscreensaver; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY accountscreensaver (id, accountid, screensaverid) FROM stdin;
\.
COPY accountscreensaver (id, accountid, screensaverid) FROM '$$PATH$$/4188.dat';

--
-- Name: accountscreensaverseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accountscreensaverseq', 1, false);


--
-- Name: accountseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('accountseq', 8557, true);


--
-- Data for Name: advertisingconfig; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY advertisingconfig (id, frequencyonplay, frequencyonzapping, skipoffset, maxperday, maxperweek, maxpermonth) FROM stdin;
\.
COPY advertisingconfig (id, frequencyonplay, frequencyonzapping, skipoffset, maxperday, maxperweek, maxpermonth) FROM '$$PATH$$/4191.dat';

--
-- Name: advertisingconfigseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('advertisingconfigseq', 1, false);


--
-- Data for Name: advertisingmedia; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY advertisingmedia (id, assetid, advertisingtype, clickurl, maxperday, maxperweek, maxpermonth) FROM stdin;
\.
COPY advertisingmedia (id, assetid, advertisingtype, clickurl, maxperday, maxperweek, maxpermonth) FROM '$$PATH$$/4193.dat';

--
-- Name: advertisingmediaseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('advertisingmediaseq', 1, false);


--
-- Data for Name: advertisingmetadataserver; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY advertisingmetadataserver (id, hostmetadataserver, portmetadataserver, loginmetadataserver, passwordmetadataserver) FROM stdin;
\.
COPY advertisingmetadataserver (id, hostmetadataserver, portmetadataserver, loginmetadataserver, passwordmetadataserver) FROM '$$PATH$$/4195.dat';

--
-- Name: advertisingmetadataserverseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('advertisingmetadataserverseq', 1, false);


--
-- Data for Name: advertisingtagtreenode; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY advertisingtagtreenode (id, tagnodeid, assetid) FROM stdin;
\.
COPY advertisingtagtreenode (id, tagnodeid, assetid) FROM '$$PATH$$/4197.dat';

--
-- Name: advertisingtagtreenodeseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('advertisingtagtreenodeseq', 1, false);


--
-- Data for Name: advertisingvisualization; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY advertisingvisualization (id, accountid, assetid, advertisingtype, creationtime) FROM stdin;
\.
COPY advertisingvisualization (id, accountid, assetid, advertisingtype, creationtime) FROM '$$PATH$$/4199.dat';

--
-- Name: advertisingvisualizationseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('advertisingvisualizationseq', 1, false);


--
-- Name: am_alarmobjectseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('am_alarmobjectseq', 1, false);


--
-- Data for Name: am_multicastgroupalarm; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY am_multicastgroupalarm (id, state, multicastgroup, port) FROM stdin;
\.
COPY am_multicastgroupalarm (id, state, multicastgroup, port) FROM '$$PATH$$/4202.dat';

--
-- Data for Name: am_stbalarm; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY am_stbalarm (id, state, ipaddress) FROM stdin;
\.
COPY am_stbalarm (id, state, ipaddress) FROM '$$PATH$$/4203.dat';

--
-- Data for Name: application; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY application (id, appname, iconpathenabled, iconpathdisabled, installerpath, enabled, exectype, appid, version) FROM stdin;
\.
COPY application (id, appname, iconpathenabled, iconpathdisabled, installerpath, enabled, exectype, appid, version) FROM '$$PATH$$/4204.dat';

--
-- Data for Name: applicationorder; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY applicationorder (appid, parentappid, "position", id) FROM stdin;
\.
COPY applicationorder (appid, parentappid, "position", id) FROM '$$PATH$$/4205.dat';

--
-- Name: applicationorderseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('applicationorderseq', 25, true);


--
-- Data for Name: asseti18n; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY asseti18n (asseti18nid, userid, assetid, assettitle, localeid) FROM stdin;
\.
COPY asseti18n (asseti18nid, userid, assetid, assettitle, localeid) FROM '$$PATH$$/4207.dat';

--
-- Name: asseti18nseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('asseti18nseq', 1, false);


--
-- Data for Name: audiocodec; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY audiocodec (audiocodecid, codec) FROM stdin;
\.
COPY audiocodec (audiocodecid, codec) FROM '$$PATH$$/4209.dat';

--
-- Name: audiocodecseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('audiocodecseq', 3, true);


--
-- Data for Name: authtoken; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY authtoken (deviceid, physicalid, accountid, sessionaccountingid, deviceip, finishdate, token, useragent, userid, finishdatepersistence, creationdate, renewdate, lastupdatedeviceip, deviceclass, deletiondate, lastaccessdate) FROM stdin;
\.
COPY authtoken (deviceid, physicalid, accountid, sessionaccountingid, deviceip, finishdate, token, useragent, userid, finishdatepersistence, creationdate, renewdate, lastupdatedeviceip, deviceclass, deletiondate, lastaccessdate) FROM '$$PATH$$/4211.dat';

--
-- Data for Name: banner; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY banner (filename, bannerid, tagtreenodeid, name, link, namei18nid) FROM stdin;
\.
COPY banner (filename, bannerid, tagtreenodeid, name, link, namei18nid) FROM '$$PATH$$/4213.dat';

--
-- Name: bannerseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('bannerseq', 1, false);


--
-- Data for Name: basicpackage; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY basicpackage (id, name, namei18n, price, subscriptiontype, renovationtype, tagtreenodeid, initialprice, initialpricedurationdays, starttime, endtime, active, currencyid, logofilename, descriptioni18n, shortdescriptioni18n, stbcustomizationid, pccustomizationid, discount, registrationfee, imagefilename, trialdays, clientpurchasedenied) FROM stdin;
\.
COPY basicpackage (id, name, namei18n, price, subscriptiontype, renovationtype, tagtreenodeid, initialprice, initialpricedurationdays, starttime, endtime, active, currencyid, logofilename, descriptioni18n, shortdescriptioni18n, stbcustomizationid, pccustomizationid, discount, registrationfee, imagefilename, trialdays, clientpurchasedenied) FROM '$$PATH$$/4215.dat';

--
-- Name: basicpackageseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('basicpackageseq', 8459, true);


--
-- Data for Name: billing; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY billing (billingid, purchaseid, starttime, finishtime, price, creationtime, sessionaccountingid, currencyid, billingtype) FROM stdin;
\.
COPY billing (billingid, purchaseid, starttime, finishtime, price, creationtime, sessionaccountingid, currencyid, billingtype) FROM '$$PATH$$/4217.dat';

--
-- Name: billingseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('billingseq', 8471, true);


--
-- Data for Name: cacheserver; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY cacheserver (id, host, port) FROM stdin;
\.
COPY cacheserver (id, host, port) FROM '$$PATH$$/4224.dat';

--
-- Name: cacheserverseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('cacheserverseq', 1, false);


--
-- Data for Name: cacheversion; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY cacheversion (cachetype, version) FROM stdin;
\.
COPY cacheversion (cachetype, version) FROM '$$PATH$$/4226.dat';

--
-- Data for Name: catalogtree; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY catalogtree (catalogtreename) FROM stdin;
\.
COPY catalogtree (catalogtreename) FROM '$$PATH$$/4227.dat';

--
-- Data for Name: catalogtreenode; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY catalogtreenode (catalogtreename, catalogtreenodeid, parentcatalogtreenodeid, catalogtreenodenameid, "position") FROM stdin;
\.
COPY catalogtreenode (catalogtreename, catalogtreenodeid, parentcatalogtreenodeid, catalogtreenodenameid, "position") FROM '$$PATH$$/4228.dat';

--
-- Data for Name: catalogtreenodeasset; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY catalogtreenodeasset (catalogtreenodeassetid, catalogtreenodeid, assetid, "position") FROM stdin;
\.
COPY catalogtreenodeasset (catalogtreenodeassetid, catalogtreenodeid, assetid, "position") FROM '$$PATH$$/4229.dat';

--
-- Name: catalogtreenodeassetseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('catalogtreenodeassetseq', 1, false);


--
-- Data for Name: catalogtreenodename; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY catalogtreenodename (catalogtreenodenameid, catalogtreenodeid, shortname, name, locale) FROM stdin;
\.
COPY catalogtreenodename (catalogtreenodenameid, catalogtreenodeid, shortname, name, locale) FROM '$$PATH$$/4231.dat';

--
-- Name: catalogtreenodenameseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('catalogtreenodenameseq', 2, true);


--
-- Data for Name: catalogtreenodeproperty; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY catalogtreenodeproperty (catalogtreenodepropertyid, catalogtreenodeid, skey, svalue) FROM stdin;
\.
COPY catalogtreenodeproperty (catalogtreenodepropertyid, catalogtreenodeid, skey, svalue) FROM '$$PATH$$/4233.dat';

--
-- Name: catalogtreenodepropertyseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('catalogtreenodepropertyseq', 1, false);


--
-- Data for Name: catalogtreenoderole; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY catalogtreenoderole (id, catalogtreenodeid, roleid) FROM stdin;
\.
COPY catalogtreenoderole (id, catalogtreenodeid, roleid) FROM '$$PATH$$/4235.dat';

--
-- Name: catalogtreenoderoleseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('catalogtreenoderoleseq', 1, false);


--
-- Name: catalogtreenodeseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('catalogtreenodeseq', 4, true);


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY category (categoryid, miliseconds, ispremiere) FROM stdin;
\.
COPY category (categoryid, miliseconds, ispremiere) FROM '$$PATH$$/4238.dat';

--
-- Data for Name: channelaccessarea; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channelaccessarea (id, vodkatvchannelid, networkareaid, tagnodeid) FROM stdin;
\.
COPY channelaccessarea (id, vodkatvchannelid, networkareaid, tagnodeid) FROM '$$PATH$$/4239.dat';

--
-- Name: channelaccessareaseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channelaccessareaseq', 22, true);


--
-- Data for Name: channelaccesstypesubscription; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channelaccesstypesubscription (channelaccesstypesubscriptionid, accountid, channelaccesstype) FROM stdin;
\.
COPY channelaccesstypesubscription (channelaccesstypesubscriptionid, accountid, channelaccesstype) FROM '$$PATH$$/4241.dat';

--
-- Name: channelaccesstypesubscriptionseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channelaccesstypesubscriptionseq', 25683, true);


--
-- Data for Name: channelaudiopid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channelaudiopid (channelaudiopidid, language, pid, channeldataplayinfoid, codec) FROM stdin;
\.
COPY channelaudiopid (channelaudiopidid, language, pid, channeldataplayinfoid, codec) FROM '$$PATH$$/4243.dat';

--
-- Name: channelaudiopidseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channelaudiopidseq', 1, false);


--
-- Data for Name: channelcategory; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channelcategory (channelcategoryid, vodkatvchannelid, categoryid) FROM stdin;
\.
COPY channelcategory (channelcategoryid, vodkatvchannelid, categoryid) FROM '$$PATH$$/4245.dat';

--
-- Name: channelcategoryseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channelcategoryseq', 1, false);


--
-- Data for Name: channeldata; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channeldata (vodkatvchannelid, channeltype, languagecode, countrycode, textchannelid, npvrpausesupported, npvrstartoversupported, npvrprerollassetid, pauselivetvtgaptimestart, pauselivetvtgaptimeend, startovergaptimestart, startovergaptimeend, channelid, npvrfragmentsize, npvrstartoverdefaulttimestart, npvrstartoverdefaulttimeend, channeldescription, npvrrectime, channelname, logourl, pvrsupported, accesstype, caschannelid, availableepgdays, active, localpvrsupported, hbbtvurl, id, parentalratingid) FROM stdin;
\.
COPY channeldata (vodkatvchannelid, channeltype, languagecode, countrycode, textchannelid, npvrpausesupported, npvrstartoversupported, npvrprerollassetid, pauselivetvtgaptimestart, pauselivetvtgaptimeend, startovergaptimestart, startovergaptimeend, channelid, npvrfragmentsize, npvrstartoverdefaulttimestart, npvrstartoverdefaulttimeend, channeldescription, npvrrectime, channelname, logourl, pvrsupported, accesstype, caschannelid, availableepgdays, active, localpvrsupported, hbbtvurl, id, parentalratingid) FROM '$$PATH$$/4247.dat';

--
-- Data for Name: channeldataplayinfo; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channeldataplayinfo (channeldataplayinfoid, vodkatvchannelid, devicetypeid, "position", channelurl, prebuffermillis, prebuffernetpvrmillis, netpvrurl, netpvrchannelid, aclchannelid, aclchannelprotocol, sourceuri, streamname) FROM stdin;
\.
COPY channeldataplayinfo (channeldataplayinfoid, vodkatvchannelid, devicetypeid, "position", channelurl, prebuffermillis, prebuffernetpvrmillis, netpvrurl, netpvrchannelid, aclchannelid, aclchannelprotocol, sourceuri, streamname) FROM '$$PATH$$/4248.dat';

--
-- Name: channeldataplayinfoseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channeldataplayinfoseq', 38, true);


--
-- Name: channeldataseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channeldataseq', 7146582, true);


--
-- Data for Name: channellist; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channellist (id, name, typelist) FROM stdin;
\.
COPY channellist (id, name, typelist) FROM '$$PATH$$/4251.dat';

--
-- Data for Name: channellistitem; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channellistitem (id, channellistid, channelnumber, visible, internalchannelid) FROM stdin;
\.
COPY channellistitem (id, channellistid, channelnumber, visible, internalchannelid) FROM '$$PATH$$/4252.dat';

--
-- Name: channellistitemseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channellistitemseq', 8457283, true);


--
-- Name: channellistseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channellistseq', 8462, true);


--
-- Data for Name: channelnumber; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channelnumber (id, deviceid, vodkatvchannelid, channelnumber, ord, accountid) FROM stdin;
\.
COPY channelnumber (id, deviceid, vodkatvchannelid, channelnumber, ord, accountid) FROM '$$PATH$$/4255.dat';

--
-- Name: channelnumberseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channelnumberseq', 1, false);


--
-- Data for Name: channelsourceuri; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channelsourceuri (channelsourceuriid, channeldataplayinfoid, sourceuri, bitrate) FROM stdin;
\.
COPY channelsourceuri (channelsourceuriid, channeldataplayinfoid, sourceuri, bitrate) FROM '$$PATH$$/4257.dat';

--
-- Name: channelsourceuriseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channelsourceuriseq', 41, true);


--
-- Data for Name: channelvideopid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channelvideopid (channelvideopidid, channeldataplayinfoid, codec, pid) FROM stdin;
\.
COPY channelvideopid (channelvideopidid, channeldataplayinfoid, codec, pid) FROM '$$PATH$$/4259.dat';

--
-- Name: channelvideopidseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channelvideopidseq', 1, false);


--
-- Data for Name: channelvisibility; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY channelvisibility (id, deviceid, vodkatvchannelid, visible, accountid) FROM stdin;
\.
COPY channelvisibility (id, deviceid, vodkatvchannelid, visible, accountid) FROM '$$PATH$$/4261.dat';

--
-- Name: channelvisibilityseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('channelvisibilityseq', 1, false);


--
-- Data for Name: collectionrule; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY collectionrule (collectionruleid, ruleid, collectionid) FROM stdin;
\.
COPY collectionrule (collectionruleid, ruleid, collectionid) FROM '$$PATH$$/4263.dat';

--
-- Name: collectionruleseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('collectionruleseq', 1, false);


--
-- Data for Name: contentcategory; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY contentcategory (categoryid, categoryname) FROM stdin;
\.
COPY contentcategory (categoryid, categoryname) FROM '$$PATH$$/4265.dat';

--
-- Name: contentcategoryseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('contentcategoryseq', 1, false);


--
-- Data for Name: credit; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY credit (creditid, amount) FROM stdin;
\.
COPY credit (creditid, amount) FROM '$$PATH$$/4267.dat';

--
-- Name: creditseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('creditseq', 8496, true);


--
-- Data for Name: currency; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY currency (currencyid, visualname, defaultcurrency, currencykey) FROM stdin;
\.
COPY currency (currencyid, visualname, defaultcurrency, currencykey) FROM '$$PATH$$/4269.dat';

--
-- Name: currencyseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('currencyseq', 8458, true);


--
-- Data for Name: customization; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY customization (id, name, description, screenshotfilename, deviceclass, mainapplicationid) FROM stdin;
\.
COPY customization (id, name, description, screenshotfilename, deviceclass, mainapplicationid) FROM '$$PATH$$/4271.dat';

--
-- Data for Name: customizationpath; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY customizationpath (id, deviceclass, customizationid, path) FROM stdin;
\.
COPY customizationpath (id, deviceclass, customizationid, path) FROM '$$PATH$$/4272.dat';

--
-- Name: customizationpathseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('customizationpathseq', 1, false);


--
-- Name: customizationseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('customizationseq', 1, true);


--
-- Data for Name: customizationsystemapplication; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY customizationsystemapplication (id, customizationid, systemapplicationid) FROM stdin;
\.
COPY customizationsystemapplication (id, customizationid, systemapplicationid) FROM '$$PATH$$/4275.dat';

--
-- Name: customizationsystemapplicationseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('customizationsystemapplicationseq', 40, true);


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase) FROM stdin;
\.
COPY databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase) FROM '$$PATH$$/4277.dat';

--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
\.
COPY databasechangeloglock (id, locked, lockgranted, lockedby) FROM '$$PATH$$/4278.dat';

--
-- Data for Name: defaultbasicpackage; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY defaultbasicpackage (id, packageid, tagtreenodeid) FROM stdin;
\.
COPY defaultbasicpackage (id, packageid, tagtreenodeid) FROM '$$PATH$$/4279.dat';

--
-- Name: defaultbasicpackageseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('defaultbasicpackageseq', 1, false);


--
-- Data for Name: desktop; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktop (id, title) FROM stdin;
\.
COPY desktop (id, title) FROM '$$PATH$$/4281.dat';

--
-- Data for Name: desktoparea; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktoparea (id, x, y, width, height, name, desktopareatype, desktopid, texti18n, backgroundi18n) FROM stdin;
\.
COPY desktoparea (id, x, y, width, height, name, desktopareatype, desktopid, texti18n, backgroundi18n) FROM '$$PATH$$/4282.dat';

--
-- Name: desktopareaseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('desktopareaseq', 1, false);


--
-- Data for Name: desktopconfig; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktopconfig (id, packageid) FROM stdin;
\.
COPY desktopconfig (id, packageid) FROM '$$PATH$$/4284.dat';

--
-- Data for Name: desktopconfigdesktop; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktopconfigdesktop (id, desktopconfigid, desktopid, defaultdesktop, "position") FROM stdin;
\.
COPY desktopconfigdesktop (id, desktopconfigid, desktopid, defaultdesktop, "position") FROM '$$PATH$$/4285.dat';

--
-- Name: desktopconfigdesktopseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('desktopconfigdesktopseq', 3, true);


--
-- Name: desktopconfigseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('desktopconfigseq', 2, true);


--
-- Data for Name: desktopitem; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktopitem (id, x, y, width, height, title, iconfocus, iconblur, desktopitemtype, desktopid, useritem, userdesktopid, focusable, titlei18n) FROM stdin;
\.
COPY desktopitem (id, x, y, width, height, title, iconfocus, iconblur, desktopitemtype, desktopid, useritem, userdesktopid, focusable, titlei18n) FROM '$$PATH$$/4288.dat';

--
-- Data for Name: desktopitemapp; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktopitemapp (id, appid) FROM stdin;
\.
COPY desktopitemapp (id, appid) FROM '$$PATH$$/4289.dat';

--
-- Data for Name: desktopitemmedia; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktopitemmedia (id, subtype, vodkatvchannelid, file, assetid, url, dtvchannelid, filetype, device, path, playlistid, elementid) FROM stdin;
\.
COPY desktopitemmedia (id, subtype, vodkatvchannelid, file, assetid, url, dtvchannelid, filetype, device, path, playlistid, elementid) FROM '$$PATH$$/4290.dat';

--
-- Data for Name: desktopitemplugin; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktopitemplugin (id, appid, pluginconfigurationid) FROM stdin;
\.
COPY desktopitemplugin (id, appid, pluginconfigurationid) FROM '$$PATH$$/4291.dat';

--
-- Name: desktopitemseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('desktopitemseq', 1, true);


--
-- Data for Name: desktopitemweb; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktopitemweb (id, url) FROM stdin;
\.
COPY desktopitemweb (id, url) FROM '$$PATH$$/4293.dat';

--
-- Data for Name: desktopitemwidget; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY desktopitemwidget (id, subtype, appid, url, refreshsecs) FROM stdin;
\.
COPY desktopitemwidget (id, subtype, appid, url, refreshsecs) FROM '$$PATH$$/4294.dat';

--
-- Name: desktopseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('desktopseq', 1, true);


--
-- Data for Name: developer; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY developer (developerid, description) FROM stdin;
\.
COPY developer (developerid, description) FROM '$$PATH$$/4296.dat';

--
-- Name: developerseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('developerseq', 1, false);


--
-- Data for Name: device; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY device (id, deviceclass, roomid, physicalid, description, tagtreenodeid, finishtime) FROM stdin;
\.
COPY device (id, deviceclass, roomid, physicalid, description, tagtreenodeid, finishtime) FROM '$$PATH$$/4219.dat';

--
-- Data for Name: deviceclass; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY deviceclass (id, visualname) FROM stdin;
\.
COPY deviceclass (id, visualname) FROM '$$PATH$$/4298.dat';

--
-- Name: deviceseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('deviceseq', 9107, true);


--
-- Data for Name: devicestatuseventsserver; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY devicestatuseventsserver (deviceid, token, lastconnectiontoeventsserver, lastdisconnectionfromeventsserver) FROM stdin;
\.
COPY devicestatuseventsserver (deviceid, token, lastconnectiontoeventsserver, lastdisconnectionfromeventsserver) FROM '$$PATH$$/4300.dat';

--
-- Data for Name: devicetype; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY devicetype (devicetypeid, useragent, name, deviceclass) FROM stdin;
\.
COPY devicetype (devicetypeid, useragent, name, deviceclass) FROM '$$PATH$$/4301.dat';

--
-- Name: devicetypeseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('devicetypeseq', 4, true);


--
-- Data for Name: dialingcode; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY dialingcode (id, code, country) FROM stdin;
\.
COPY dialingcode (id, code, country) FROM '$$PATH$$/4303.dat';

--
-- Name: dialingcodeseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('dialingcodeseq', 229, true);


--
-- Data for Name: emailtemplate; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY emailtemplate (id, subject, content, type) FROM stdin;
\.
COPY emailtemplate (id, subject, content, type) FROM '$$PATH$$/4305.dat';

--
-- Name: emailtemplateseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('emailtemplateseq', 3, true);


--
-- Data for Name: eventsserver; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY eventsserver (id, internalhost, internalwsport, httpport, publichost, publicwsport) FROM stdin;
\.
COPY eventsserver (id, internalhost, internalwsport, httpport, publichost, publicwsport) FROM '$$PATH$$/4307.dat';

--
-- Name: eventsserverseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('eventsserverseq', 6, true);


--
-- Data for Name: favorite; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY favorite (favoriteid, accountid, assetid, favoritedate) FROM stdin;
\.
COPY favorite (favoriteid, accountid, assetid, favoritedate) FROM '$$PATH$$/4309.dat';

--
-- Data for Name: favoritechannel; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY favoritechannel (id, vodkatvchannelid, accountid, "position") FROM stdin;
\.
COPY favoritechannel (id, vodkatvchannelid, accountid, "position") FROM '$$PATH$$/4310.dat';

--
-- Name: favoritechannelseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('favoritechannelseq', 1, false);


--
-- Name: favoriteseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('favoriteseq', 1, false);


--
-- Data for Name: filterlistconfiguration; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY filterlistconfiguration (filterlistconfigurationid, listconfigurationid, count, assetcollectionid) FROM stdin;
\.
COPY filterlistconfiguration (filterlistconfigurationid, listconfigurationid, count, assetcollectionid) FROM '$$PATH$$/4313.dat';

--
-- Name: filterlistconfigurationseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('filterlistconfigurationseq', 1, false);


--
-- Data for Name: firmware; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY firmware (version, filename, description, creationtime) FROM stdin;
\.
COPY firmware (version, filename, description, creationtime) FROM '$$PATH$$/4315.dat';

--
-- Name: firmwareseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('firmwareseq', 1, false);


--
-- Data for Name: genericinfo; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY genericinfo (id, type, name, description, address, phone) FROM stdin;
\.
COPY genericinfo (id, type, name, description, address, phone) FROM '$$PATH$$/4317.dat';

--
-- Name: genericinfoseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('genericinfoseq', 1, false);


--
-- Data for Name: guest; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY guest (sessionaccountingid, name, locale, guesttitle, surname, birthday, phonenumber, mobilephonenumber, email, address, zipcode, city, countrycode, countryoforigincode) FROM stdin;
\.
COPY guest (sessionaccountingid, name, locale, guesttitle, surname, birthday, phonenumber, mobilephonenumber, email, address, zipcode, city, countrycode, countryoforigincode) FROM '$$PATH$$/4319.dat';

--
-- Data for Name: guestservices; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY guestservices (id, hotelservicesurl, hotelservicesurltopcss, hotelservicesurlleftcss, hotelservicesurlwidthcss, hotelservicesurlheightcss, hotelnamei18n, hotelimagefilename, expresscheckoutinfomessagei18n, expresscheckoutconfirmationmessagei18n, expresscheckouterrormessagei18n, hotelhelpurl, hotelhelpurltopcss, hotelhelpurlleftcss, hotelhelpurlwidthcss, hotelhelpurlheightcss, showremotecheckoutoption, welcomemessagei18n) FROM stdin;
\.
COPY guestservices (id, hotelservicesurl, hotelservicesurltopcss, hotelservicesurlleftcss, hotelservicesurlwidthcss, hotelservicesurlheightcss, hotelnamei18n, hotelimagefilename, expresscheckoutinfomessagei18n, expresscheckoutconfirmationmessagei18n, expresscheckouterrormessagei18n, hotelhelpurl, hotelhelpurltopcss, hotelhelpurlleftcss, hotelhelpurlwidthcss, hotelhelpurlheightcss, showremotecheckoutoption, welcomemessagei18n) FROM '$$PATH$$/4320.dat';

--
-- Name: guestservicesseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('guestservicesseq', 1, true);


--
-- Data for Name: hotel; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY hotel (id, name, description) FROM stdin;
\.
COPY hotel (id, name, description) FROM '$$PATH$$/4322.dat';

--
-- Name: hotelseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('hotelseq', 1, false);


--
-- Data for Name: i18n; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY i18n (i18nid, es, en, it, fr, ar, de) FROM stdin;
\.
COPY i18n (i18nid, es, en, it, fr, ar, de) FROM '$$PATH$$/4324.dat';

--
-- Name: i18nseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('i18nseq', 51203, true);


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY image (filename, bytes) FROM stdin;
\.
COPY image (filename, bytes) FROM '$$PATH$$/4326.dat';

--
-- Data for Name: incompatibleproduct; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY incompatibleproduct (id, productid, incompatibleproductid) FROM stdin;
\.
COPY incompatibleproduct (id, productid, incompatibleproductid) FROM '$$PATH$$/4327.dat';

--
-- Name: incompatibleproductseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('incompatibleproductseq', 1, false);


--
-- Data for Name: interaction; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY interaction (assetid, accountid, points) FROM stdin;
\.
COPY interaction (assetid, accountid, points) FROM '$$PATH$$/4329.dat';

--
-- Data for Name: itemmappingscreen; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY itemmappingscreen (itemmappingscreenid, playlistmappingscreenid, "position", assetid, runtime, vodkatvchannelid) FROM stdin;
\.
COPY itemmappingscreen (itemmappingscreenid, playlistmappingscreenid, "position", assetid, runtime, vodkatvchannelid) FROM '$$PATH$$/4330.dat';

--
-- Name: itemmappingscreenseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('itemmappingscreenseq', 1, false);


--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY language (languageid, language, languagei18n) FROM stdin;
\.
COPY language (languageid, language, languagei18n) FROM '$$PATH$$/4332.dat';

--
-- Data for Name: link; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY link (id, name, namei18nid, description, url) FROM stdin;
\.
COPY link (id, name, namei18nid, description, url) FROM '$$PATH$$/4333.dat';

--
-- Name: linkseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('linkseq', 1, false);


--
-- Data for Name: listconfiguration; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY listconfiguration (listconfigurationid, name, description, count, assetcollectionid, sortby, newassetsposition, sortbynewassetsposition, orderassets, ordernewassetsposition) FROM stdin;
\.
COPY listconfiguration (listconfigurationid, name, description, count, assetcollectionid, sortby, newassetsposition, sortbynewassetsposition, orderassets, ordernewassetsposition) FROM '$$PATH$$/4335.dat';

--
-- Data for Name: listconfigurationasset; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY listconfigurationasset (listconfigurationassetid, listconfigurationid, assetid, "position") FROM stdin;
\.
COPY listconfigurationasset (listconfigurationassetid, listconfigurationid, assetid, "position") FROM '$$PATH$$/4336.dat';

--
-- Name: listconfigurationassetseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('listconfigurationassetseq', 1, false);


--
-- Name: listconfigurationseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('listconfigurationseq', 1, false);


--
-- Data for Name: logging_event; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY logging_event (timestmp, formatted_message, logger_name, level_string, thread_name, reference_flag, caller_filename, caller_class, caller_method, caller_line, event_id) FROM stdin;
\.
COPY logging_event (timestmp, formatted_message, logger_name, level_string, thread_name, reference_flag, caller_filename, caller_class, caller_method, caller_line, event_id) FROM '$$PATH$$/4340.dat';

--
-- Data for Name: logging_event_exception; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY logging_event_exception (event_id, i, trace_line) FROM stdin;
\.
COPY logging_event_exception (event_id, i, trace_line) FROM '$$PATH$$/4341.dat';

--
-- Name: logging_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('logging_event_id_seq', 1, false);


--
-- Data for Name: logging_event_property; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY logging_event_property (event_id, mapped_key, mapped_value) FROM stdin;
\.
COPY logging_event_property (event_id, mapped_key, mapped_value) FROM '$$PATH$$/4342.dat';

--
-- Data for Name: mappingscreenconfiguration; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY mappingscreenconfiguration (reloadeversec, reloadonstartvideo, reloadonstartcycle, vodkatvchannelid) FROM stdin;
\.
COPY mappingscreenconfiguration (reloadeversec, reloadonstartvideo, reloadonstartcycle, vodkatvchannelid) FROM '$$PATH$$/4343.dat';

--
-- Data for Name: masternode; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY masternode (ip, lasttime) FROM stdin;
\.
COPY masternode (ip, lasttime) FROM '$$PATH$$/4344.dat';

--
-- Data for Name: memcachedkey; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY memcachedkey (id, cachekey, accountid, sessionaccountingid, deviceid, creationtime, validuntil, cachetype) FROM stdin;
\.
COPY memcachedkey (id, cachekey, accountid, sessionaccountingid, deviceid, creationtime, validuntil, cachetype) FROM '$$PATH$$/4345.dat';

--
-- Name: memcachedkeyseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('memcachedkeyseq', 563, true);


--
-- Data for Name: menuoption; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY menuoption (id, labeli18n, helpmessagei18n, type, path, "position", parentmenuid) FROM stdin;
\.
COPY menuoption (id, labeli18n, helpmessagei18n, type, path, "position", parentmenuid) FROM '$$PATH$$/4347.dat';

--
-- Name: menuoptionseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('menuoptionseq', 1, false);


--
-- Name: menuseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('menuseq', 1, false);


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY message (id, creationdate, type, status, statuschangedate, stbid, accountid, messageidpms, expirationdate) FROM stdin;
\.
COPY message (id, creationdate, type, status, statuschangedate, stbid, accountid, messageidpms, expirationdate) FROM '$$PATH$$/4350.dat';

--
-- Data for Name: messagemail; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY messagemail (id, subject, content) FROM stdin;
\.
COPY messagemail (id, subject, content) FROM '$$PATH$$/4351.dat';

--
-- Data for Name: messagepopup; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY messagepopup (id, title, text, size) FROM stdin;
\.
COPY messagepopup (id, title, text, size) FROM '$$PATH$$/4352.dat';

--
-- Data for Name: messagescript; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY messagescript (id, script) FROM stdin;
\.
COPY messagescript (id, script) FROM '$$PATH$$/4353.dat';

--
-- Name: messageseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('messageseq', 1, false);


--
-- Data for Name: messagewakeup; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY messagewakeup (id, wakeupdate, label, state) FROM stdin;
\.
COPY messagewakeup (id, wakeupdate, label, state) FROM '$$PATH$$/4355.dat';

--
-- Data for Name: networkarea; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY networkarea (id, name) FROM stdin;
\.
COPY networkarea (id, name) FROM '$$PATH$$/4356.dat';

--
-- Data for Name: networkareacountry; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY networkareacountry (id, networkareaid, countrycode) FROM stdin;
\.
COPY networkareacountry (id, networkareaid, countrycode) FROM '$$PATH$$/4357.dat';

--
-- Name: networkareacountryseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('networkareacountryseq', 1, false);


--
-- Data for Name: networkareaipv4subnet; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY networkareaipv4subnet (id, networkareaid, subnet, mask) FROM stdin;
\.
COPY networkareaipv4subnet (id, networkareaid, subnet, mask) FROM '$$PATH$$/4359.dat';

--
-- Name: networkareaipv4subnetseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('networkareaipv4subnetseq', 5, true);


--
-- Name: networkareaseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('networkareaseq', 2, true);


--
-- Data for Name: outputsprotection; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY outputsprotection (accountid, outputsprotection) FROM stdin;
\.
COPY outputsprotection (accountid, outputsprotection) FROM '$$PATH$$/4362.dat';

--
-- Data for Name: parentalcontrollevel; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY parentalcontrollevel (accountid, maxratingid) FROM stdin;
\.
COPY parentalcontrollevel (accountid, maxratingid) FROM '$$PATH$$/4363.dat';

--
-- Data for Name: parentalrating; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY parentalrating (name, "position", id) FROM stdin;
\.
COPY parentalrating (name, "position", id) FROM '$$PATH$$/4364.dat';

--
-- Data for Name: parentalratingmapping; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY parentalratingmapping (id, parentalratingid, mediaparentalratingid) FROM stdin;
\.
COPY parentalratingmapping (id, parentalratingid, mediaparentalratingid) FROM '$$PATH$$/4365.dat';

--
-- Name: parentalratingmappingseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('parentalratingmappingseq', 1, false);


--
-- Name: parentalratingseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('parentalratingseq', 12, true);


--
-- Data for Name: periodicity; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY periodicity (periodicityid, ruleid, weekday, starttime, finishtime, day) FROM stdin;
\.
COPY periodicity (periodicityid, ruleid, weekday, starttime, finishtime, day) FROM '$$PATH$$/4368.dat';

--
-- Name: periodicityseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('periodicityseq', 1, false);


--
-- Data for Name: photo; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY photo (id, name, description, image, filename) FROM stdin;
\.
COPY photo (id, name, description, image, filename) FROM '$$PATH$$/4370.dat';

--
-- Name: photoseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('photoseq', 1, false);


--
-- Data for Name: pingtable; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY pingtable (foo) FROM stdin;
\.
COPY pingtable (foo) FROM '$$PATH$$/4372.dat';

--
-- Data for Name: playerconfiguration; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY playerconfiguration (playerconfigurationid, protocol, prebuffermillis, inactivitynotificationtimeminutes) FROM stdin;
\.
COPY playerconfiguration (playerconfigurationid, protocol, prebuffermillis, inactivitynotificationtimeminutes) FROM '$$PATH$$/4373.dat';

--
-- Name: playerconfigurationseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('playerconfigurationseq', 5, true);


--
-- Data for Name: playlistmappingscreen; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY playlistmappingscreen (playlistmappingscreenid, roomid, active) FROM stdin;
\.
COPY playlistmappingscreen (playlistmappingscreenid, roomid, active) FROM '$$PATH$$/4375.dat';

--
-- Name: playlistmappingscreenseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('playlistmappingscreenseq', 1, false);


--
-- Data for Name: plugin_webbrows_stburlitem; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY plugin_webbrows_stburlitem (id, stbid, lft, rgt, itemid, typenode, url, topcss, leftcss, widthcss, heightcss) FROM stdin;
\.
COPY plugin_webbrows_stburlitem (id, stbid, lft, rgt, itemid, typenode, url, topcss, leftcss, widthcss, heightcss) FROM '$$PATH$$/4377.dat';

--
-- Data for Name: plugin_webbrows_stburlitemlang; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY plugin_webbrows_stburlitemlang (id, stburlitemid, code, str) FROM stdin;
\.
COPY plugin_webbrows_stburlitemlang (id, stburlitemid, code, str) FROM '$$PATH$$/4378.dat';

--
-- Name: plugin_webbrows_stburlitemlangseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('plugin_webbrows_stburlitemlangseq', 1, false);


--
-- Name: plugin_webbrows_stburlitemseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('plugin_webbrows_stburlitemseq', 1, false);


--
-- Data for Name: pluginconfiguration; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY pluginconfiguration (pluginconfigurationid, pluginscreenid, selectaccount, password, classnameinformation, imgmenuon, imgmenuoff, beta, version, applicationid, corelib, jsdk) FROM stdin;
\.
COPY pluginconfiguration (pluginconfigurationid, pluginscreenid, selectaccount, password, classnameinformation, imgmenuon, imgmenuoff, beta, version, applicationid, corelib, jsdk) FROM '$$PATH$$/4381.dat';

--
-- Data for Name: pluginconfigurationstart; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY pluginconfigurationstart (pluginconfigurationstartid, pluginconfigurationid, paramname, paramvalue, paramvariable, paramproperty, stbtypeid) FROM stdin;
\.
COPY pluginconfigurationstart (pluginconfigurationstartid, pluginconfigurationid, paramname, paramvalue, paramvariable, paramproperty, stbtypeid) FROM '$$PATH$$/4382.dat';

--
-- Name: pluginconfigurationstartseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('pluginconfigurationstartseq', 1, false);


--
-- Data for Name: pluginscreen; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY pluginscreen (pluginscreenid, pluginconfigurationid, actionclass, returnpage, id, stbtypeid) FROM stdin;
\.
COPY pluginscreen (pluginscreenid, pluginconfigurationid, actionclass, returnpage, id, stbtypeid) FROM '$$PATH$$/4384.dat';

--
-- Name: pluginscreenseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('pluginscreenseq', 1, false);


--
-- Data for Name: predefinedmessage; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY predefinedmessage (id, title, size, type, subject, content, text, script) FROM stdin;
\.
COPY predefinedmessage (id, title, size, type, subject, content, text, script) FROM '$$PATH$$/4386.dat';

--
-- Name: predefinedmessageseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('predefinedmessageseq', 6, true);


--
-- Data for Name: preferencemenuoption; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY preferencemenuoption (preferencemenuoptionid, preferencemenuoptionparentid, preferencemenuoptionposition) FROM stdin;
\.
COPY preferencemenuoption (preferencemenuoptionid, preferencemenuoptionparentid, preferencemenuoptionposition) FROM '$$PATH$$/4388.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY product (id, name, price, subscriptiontype, renovationtype, tagtreenodeid, initialprice, initialpricedurationdays, starttime, endtime, active, currencyid, namei18n, descriptioni18n, logofilename, shortdescriptioni18n, discount, registrationfee, imagefilename, trialdays, clientpurchasedenied) FROM stdin;
\.
COPY product (id, name, price, subscriptiontype, renovationtype, tagtreenodeid, initialprice, initialpricedurationdays, starttime, endtime, active, currencyid, namei18n, descriptioni18n, logofilename, shortdescriptioni18n, discount, registrationfee, imagefilename, trialdays, clientpurchasedenied) FROM '$$PATH$$/4389.dat';

--
-- Data for Name: productincluded; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productincluded (id, packageid, productid) FROM stdin;
\.
COPY productincluded (id, packageid, productid) FROM '$$PATH$$/4390.dat';

--
-- Name: productincludedseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('productincludedseq', 8462, true);


--
-- Data for Name: productitem; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitem (productitemid, productid, itemtype, starttime, endtime, durationtimedays) FROM stdin;
\.
COPY productitem (productitemid, productid, itemtype, starttime, endtime, durationtimedays) FROM '$$PATH$$/4392.dat';

--
-- Data for Name: productitemallapps; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemallapps (productitemid) FROM stdin;
\.
COPY productitemallapps (productitemid) FROM '$$PATH$$/4393.dat';

--
-- Data for Name: productitemallchannels; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemallchannels (productitemid) FROM stdin;
\.
COPY productitemallchannels (productitemid) FROM '$$PATH$$/4394.dat';

--
-- Data for Name: productitemalldeviceclasses; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemalldeviceclasses (productitemid) FROM stdin;
\.
COPY productitemalldeviceclasses (productitemid) FROM '$$PATH$$/4395.dat';

--
-- Data for Name: productitemallplugins; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemallplugins (productitemid) FROM stdin;
\.
COPY productitemallplugins (productitemid) FROM '$$PATH$$/4396.dat';

--
-- Data for Name: productitemappid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemappid (productitemid, appid) FROM stdin;
\.
COPY productitemappid (productitemid, appid) FROM '$$PATH$$/4397.dat';

--
-- Data for Name: productitemchannelcategory; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemchannelcategory (productitemid, categoryid) FROM stdin;
\.
COPY productitemchannelcategory (productitemid, categoryid) FROM '$$PATH$$/4398.dat';

--
-- Data for Name: productitemchannelid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemchannelid (productitemid, vodkatvchannelid) FROM stdin;
\.
COPY productitemchannelid (productitemid, vodkatvchannelid) FROM '$$PATH$$/4399.dat';

--
-- Data for Name: productitemconcurrentusers; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemconcurrentusers (productitemid, deviceclassid, usersnum) FROM stdin;
\.
COPY productitemconcurrentusers (productitemid, deviceclassid, usersnum) FROM '$$PATH$$/4400.dat';

--
-- Data for Name: productitemdeviceclassid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemdeviceclassid (productitemid, deviceclassid) FROM stdin;
\.
COPY productitemdeviceclassid (productitemid, deviceclassid) FROM '$$PATH$$/4401.dat';

--
-- Data for Name: productitempluginid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitempluginid (productitemid, pluginconfigurationid) FROM stdin;
\.
COPY productitempluginid (productitemid, pluginconfigurationid) FROM '$$PATH$$/4402.dat';

--
-- Name: productitemseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('productitemseq', 8470, true);


--
-- Data for Name: productitemuserserviceid; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY productitemuserserviceid (productitemid, userserviceid) FROM stdin;
\.
COPY productitemuserserviceid (productitemid, userserviceid) FROM '$$PATH$$/4404.dat';

--
-- Name: productseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('productseq', 8459, true);


--
-- Data for Name: property; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY property (propertyid, propertyname, propertyvalue, propertyvalueasstring) FROM stdin;
\.
COPY property (propertyid, propertyname, propertyvalue, propertyvalueasstring) FROM '$$PATH$$/4406.dat';

--
-- Name: propertyseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('propertyseq', 60285, true);


--
-- Data for Name: protectedtargetaudience; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY protectedtargetaudience (targetaudienceid, isprotected) FROM stdin;
\.
COPY protectedtargetaudience (targetaudienceid, isprotected) FROM '$$PATH$$/4408.dat';

--
-- Name: protectedtargetaudienceseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('protectedtargetaudienceseq', 1, false);


--
-- Data for Name: purchase; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY purchase (purchaseid, sessionaccountingid, productid, productname, contractdate, cancelationdate, subscriptiontype, renovationtype, lastprocessdate, enabled, packageid, validuntil, renewalday, initialperiod, activationdate, trialfinishdate, purchasedate, roomdescription, tagtreenodename, voucherid, voucher, voucherfinishdate) FROM stdin;
\.
COPY purchase (purchaseid, sessionaccountingid, productid, productname, contractdate, cancelationdate, subscriptiontype, renovationtype, lastprocessdate, enabled, packageid, validuntil, renewalday, initialperiod, activationdate, trialfinishdate, purchasedate, roomdescription, tagtreenodename, voucherid, voucher, voucherfinishdate) FROM '$$PATH$$/4220.dat';

--
-- Name: purchaseconfigseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('purchaseconfigseq', 1, false);


--
-- Name: purchaseseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('purchaseseq', 8474, true);


--
-- Data for Name: pvrtask; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY pvrtask (pvrtaskid, pvrhedid, stbid, vodkatvchannelid, starttime, finishtime, pvrstate, name, observation, accountid, archived, filename, dtvchannelid, channelname) FROM stdin;
\.
COPY pvrtask (pvrtaskid, pvrhedid, stbid, vodkatvchannelid, starttime, finishtime, pvrstate, name, observation, accountid, archived, filename, dtvchannelid, channelname) FROM '$$PATH$$/4412.dat';

--
-- Name: pvrtaskseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('pvrtaskseq', 5, true);


--
-- Data for Name: rent; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY rent (rentid, stbid, accountid, assetid, title, rulename, ruleid, price, sessionaccountingid, currency, starttime, finishtime, pmsstate) FROM stdin;
\.
COPY rent (rentid, stbid, accountid, assetid, title, rulename, ruleid, price, sessionaccountingid, currency, starttime, finishtime, pmsstate) FROM '$$PATH$$/4414.dat';

--
-- Data for Name: rentingvalidity; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY rentingvalidity (rentingvalidityid, assetcollectionid, validity, rentingvalidityposition) FROM stdin;
\.
COPY rentingvalidity (rentingvalidityid, assetcollectionid, validity, rentingvalidityposition) FROM '$$PATH$$/4415.dat';

--
-- Name: rentingvalidityseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('rentingvalidityseq', 1, false);


--
-- Name: rentseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('rentseq', 6, true);


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY role (name) FROM stdin;
\.
COPY role (name) FROM '$$PATH$$/4418.dat';

--
-- Data for Name: roleassetcollection; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY roleassetcollection (id, roleid, assetcollectioncontentid) FROM stdin;
\.
COPY roleassetcollection (id, roleid, assetcollectioncontentid) FROM '$$PATH$$/4419.dat';

--
-- Data for Name: roleassetcollectioncontent; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY roleassetcollectioncontent (id, showcontents) FROM stdin;
\.
COPY roleassetcollectioncontent (id, showcontents) FROM '$$PATH$$/4420.dat';

--
-- Name: roleassetcollectionseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('roleassetcollectionseq', 1, false);


--
-- Data for Name: roleattribute; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY roleattribute (id, rolename, classname, attrtohide) FROM stdin;
\.
COPY roleattribute (id, rolename, classname, attrtohide) FROM '$$PATH$$/4422.dat';

--
-- Name: roleattributeseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('roleattributeseq', 1, false);


--
-- Data for Name: rolemenuoption; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY rolemenuoption (rolename, menuoptionid, id) FROM stdin;
\.
COPY rolemenuoption (rolename, menuoptionid, id) FROM '$$PATH$$/4424.dat';

--
-- Name: rolemenuoptionseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('rolemenuoptionseq', 1, false);


--
-- Data for Name: room; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY room (roomid, description, tagtreenodeid) FROM stdin;
\.
COPY room (roomid, description, tagtreenodeid) FROM '$$PATH$$/4221.dat';

--
-- Data for Name: rss; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY rss (id, name, namei18nid, description, url, count) FROM stdin;
\.
COPY rss (id, name, namei18nid, description, url, count) FROM '$$PATH$$/4426.dat';

--
-- Name: rssseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('rssseq', 1, false);


--
-- Data for Name: rule; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY rule (ruleid, rulename, ruleposition, categoryid, genreid, floornumber, rulescollectionname, roomid, price, factorbahamasprice, stbid) FROM stdin;
\.
COPY rule (ruleid, rulename, ruleposition, categoryid, genreid, floornumber, rulescollectionname, roomid, price, factorbahamasprice, stbid) FROM '$$PATH$$/4428.dat';

--
-- Data for Name: rulescollection; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY rulescollection (rulescollectionname, startvalidtime, finishvalidtime) FROM stdin;
\.
COPY rulescollection (rulescollectionname, startvalidtime, finishvalidtime) FROM '$$PATH$$/4429.dat';

--
-- Name: ruleseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('ruleseq', 1, true);


--
-- Data for Name: schedulelink; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY schedulelink (id, name, namei18nid, description, url, starttime, finishtime, enabled) FROM stdin;
\.
COPY schedulelink (id, name, namei18nid, description, url, starttime, finishtime, enabled) FROM '$$PATH$$/4431.dat';

--
-- Name: schedulelinkseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('schedulelinkseq', 4, true);


--
-- Data for Name: screensaver; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY screensaver (id, name, version, namei18nid, url) FROM stdin;
\.
COPY screensaver (id, name, version, namei18nid, url) FROM '$$PATH$$/4433.dat';

--
-- Name: screensaverseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('screensaverseq', 1, false);


--
-- Data for Name: sessionaccounting; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY sessionaccounting (sessionaccountingid, roomid, startday, finishday, disabled, datefirstuse, inactive, datelastaccess) FROM stdin;
\.
COPY sessionaccounting (sessionaccountingid, roomid, startday, finishday, disabled, datefirstuse, inactive, datelastaccess) FROM '$$PATH$$/4222.dat';

--
-- Name: sessionaccountingseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('sessionaccountingseq', 1, false);


--
-- Data for Name: stbinformationscreen; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY stbinformationscreen (stbid, forceupdate, isplaying, lastcode, firstrequest, lastrequest, lastrequestforceupdate) FROM stdin;
\.
COPY stbinformationscreen (stbid, forceupdate, isplaying, lastcode, firstrequest, lastrequest, lastrequestforceupdate) FROM '$$PATH$$/4436.dat';

--
-- Name: stblanguageseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('stblanguageseq', 1, false);


--
-- Data for Name: stbsession; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY stbsession (stbid, newsession, startdate) FROM stdin;
\.
COPY stbsession (stbid, newsession, startdate) FROM '$$PATH$$/4438.dat';

--
-- Data for Name: stbstatus; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY stbstatus (stbid, version, ean, batch, id, serverup, mwversion, wifidevice, wifimac, wifistatus, wifiap, wifiessid, wifikey, wifiquality, wifiip, wifimask, wifigw, wifidns, wifidhcp, wireddevice, wiredmac, wiredstatus, wiredip, wiredmask, wiredgw, wireddns, wireddhcp, lastupdatetime, useragent, remoteaddr, token) FROM stdin;
\.
COPY stbstatus (stbid, version, ean, batch, id, serverup, mwversion, wifidevice, wifimac, wifistatus, wifiap, wifiessid, wifikey, wifiquality, wifiip, wifimask, wifigw, wifidns, wifidhcp, wireddevice, wiredmac, wiredstatus, wiredip, wiredmask, wiredgw, wireddns, wireddhcp, lastupdatetime, useragent, remoteaddr, token) FROM '$$PATH$$/4439.dat';

--
-- Name: stbstatusseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('stbstatusseq', 1, false);


--
-- Data for Name: stbstatusstorage; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY stbstatusstorage (token, version, mwversion, updatetime, id, stbid) FROM stdin;
\.
COPY stbstatusstorage (token, version, mwversion, updatetime, id, stbid) FROM '$$PATH$$/4212.dat';

--
-- Name: stbstatusstorageseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('stbstatusstorageseq', 27, true);


--
-- Data for Name: stbtagtree; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY stbtagtree (id, name) FROM stdin;
\.
COPY stbtagtree (id, name) FROM '$$PATH$$/4442.dat';

--
-- Data for Name: stbtagtreenode; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY stbtagtreenode (id, treeid, name, lft, rgt, parentid, pos) FROM stdin;
\.
COPY stbtagtreenode (id, treeid, name, lft, rgt, parentid, pos) FROM '$$PATH$$/4223.dat';

--
-- Data for Name: stbtagtreenodechannellist; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY stbtagtreenodechannellist (stbtagtreenodeid, channellistid) FROM stdin;
\.
COPY stbtagtreenodechannellist (stbtagtreenodeid, channellistid) FROM '$$PATH$$/4443.dat';

--
-- Name: stbtagtreenodeseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('stbtagtreenodeseq', 1, true);


--
-- Name: stbtagtreeseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('stbtagtreeseq', 1, true);


--
-- Data for Name: stbupgrade; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY stbupgrade (id, fromversion, toversion, stbid, forced, creationtime, scheduletime, notifiedtime, lasttime, lastprogress, laststatus, state, result) FROM stdin;
\.
COPY stbupgrade (id, fromversion, toversion, stbid, forced, creationtime, scheduletime, notifiedtime, lasttime, lastprogress, laststatus, state, result) FROM '$$PATH$$/4446.dat';

--
-- Name: stbupgradeseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('stbupgradeseq', 1, true);


--
-- Data for Name: subscriptioncatalog; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY subscriptioncatalog (id, productid, packageid, "position") FROM stdin;
\.
COPY subscriptioncatalog (id, productid, packageid, "position") FROM '$$PATH$$/4448.dat';

--
-- Name: subscriptioncatalogseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('subscriptioncatalogseq', 2, true);


--
-- Data for Name: subscriptiondependencies; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY subscriptiondependencies (id, productid, packageid) FROM stdin;
\.
COPY subscriptiondependencies (id, productid, packageid) FROM '$$PATH$$/4450.dat';

--
-- Name: subscriptiondependenciesseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('subscriptiondependenciesseq', 1, false);


--
-- Data for Name: systemapplication; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY systemapplication (id, appid, appname, changes, version, screenshotpath, installerpath, description, deviceclass) FROM stdin;
\.
COPY systemapplication (id, appid, appname, changes, version, screenshotpath, installerpath, description, deviceclass) FROM '$$PATH$$/4452.dat';

--
-- Name: systemapplicationseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('systemapplicationseq', 5, true);


--
-- Data for Name: tahitiversion; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY tahitiversion (number) FROM stdin;
\.
COPY tahitiversion (number) FROM '$$PATH$$/4454.dat';

--
-- Data for Name: timezone; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY timezone (timezoneid, timezonecode, tagtreenodeid) FROM stdin;
\.
COPY timezone (timezoneid, timezonecode, tagtreenodeid) FROM '$$PATH$$/4455.dat';

--
-- Name: timezoneseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('timezoneseq', 1, false);


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY user_roles (user_name, role_name) FROM stdin;
\.
COPY user_roles (user_name, role_name) FROM '$$PATH$$/4457.dat';

--
-- Data for Name: userdesktop; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY userdesktop (id, desktopid, accountid, "position") FROM stdin;
\.
COPY userdesktop (id, desktopid, accountid, "position") FROM '$$PATH$$/4458.dat';

--
-- Name: userdesktopseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('userdesktopseq', 1, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY users (user_name, user_pass) FROM stdin;
\.
COPY users (user_name, user_pass) FROM '$$PATH$$/4460.dat';

--
-- Data for Name: userservice; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY userservice (userserviceid, service) FROM stdin;
\.
COPY userservice (userserviceid, service) FROM '$$PATH$$/4461.dat';

--
-- Data for Name: videoclubpluginconfig; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoclubpluginconfig (id, renterrormessagei18n) FROM stdin;
\.
COPY videoclubpluginconfig (id, renterrormessagei18n) FROM '$$PATH$$/4462.dat';

--
-- Name: videoclubpluginconfigseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('videoclubpluginconfigseq', 1, true);


--
-- Data for Name: videocodec; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videocodec (videocodecid, codec) FROM stdin;
\.
COPY videocodec (videocodecid, codec) FROM '$$PATH$$/4464.dat';

--
-- Name: videocodecseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('videocodecseq', 4, true);


--
-- Data for Name: videoserver; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoserver (id, name, publicip, publicport, internalip, internalport, maxrequests, type, videoservertype, networkareaid, maxinactivityseconds, active, protocol) FROM stdin;
\.
COPY videoserver (id, name, publicip, publicport, internalip, internalport, maxrequests, type, videoservertype, networkareaid, maxinactivityseconds, active, protocol) FROM '$$PATH$$/4466.dat';

--
-- Data for Name: videoserveraction; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoserveraction (id, videoserverid, appname, creationdate, streamname, action) FROM stdin;
\.
COPY videoserveraction (id, videoserverid, appname, creationdate, streamname, action) FROM '$$PATH$$/4467.dat';

--
-- Name: videoserveractionseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('videoserveractionseq', 1, false);


--
-- Data for Name: videoservercontent; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoservercontent (id, videoserverid, videoservercontent) FROM stdin;
\.
COPY videoservercontent (id, videoserverid, videoservercontent) FROM '$$PATH$$/4469.dat';

--
-- Name: videoservercontentseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('videoservercontentseq', 59, true);


--
-- Data for Name: videoserverdevicetype; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoserverdevicetype (id, videoserverid, devicetypeid) FROM stdin;
\.
COPY videoserverdevicetype (id, videoserverid, devicetypeid) FROM '$$PATH$$/4471.dat';

--
-- Name: videoserverdevicetypeseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('videoserverdevicetypeseq', 5, true);


--
-- Data for Name: videoservergroup; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoservergroup (id, appname, type, storage) FROM stdin;
\.
COPY videoservergroup (id, appname, type, storage) FROM '$$PATH$$/4473.dat';

--
-- Data for Name: videoservergroupchanneldataplayinfo; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoservergroupchanneldataplayinfo (videoservergroupid, channeldataplayinfoid) FROM stdin;
\.
COPY videoservergroupchanneldataplayinfo (videoservergroupid, channeldataplayinfoid) FROM '$$PATH$$/4474.dat';

--
-- Name: videoservergroupseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('videoservergroupseq', 17, true);


--
-- Data for Name: videoservergroupvideoserver; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoservergroupvideoserver (videoservergroupid, videoserverid) FROM stdin;
\.
COPY videoservergroupvideoserver (videoservergroupid, videoserverid) FROM '$$PATH$$/4476.dat';

--
-- Name: videoserverseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('videoserverseq', 70, true);


--
-- Data for Name: videoserverstatus; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoserverstatus (id, videoserverid, appname, connectedclients, lastupdate) FROM stdin;
\.
COPY videoserverstatus (id, videoserverid, appname, connectedclients, lastupdate) FROM '$$PATH$$/4478.dat';

--
-- Name: videoserverstatusseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('videoserverstatusseq', 3, true);


--
-- Data for Name: videoserverstreamstatus; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoserverstreamstatus (videoserverstatusid, streamname, bitrate, running, id) FROM stdin;
\.
COPY videoserverstreamstatus (videoserverstatusid, streamname, bitrate, running, id) FROM '$$PATH$$/4480.dat';

--
-- Name: videoserverstreamstatusseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('videoserverstreamstatusseq', 2, true);


--
-- Data for Name: videoserverswisstv; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoserverswisstv (id, applicationkey, login, password, encodingtype, prefix) FROM stdin;
\.
COPY videoserverswisstv (id, applicationkey, login, password, encodingtype, prefix) FROM '$$PATH$$/4482.dat';

--
-- Data for Name: videoservervodkatickets; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoservervodkatickets (id, ticketserverip, ticketserverport) FROM stdin;
\.
COPY videoservervodkatickets (id, ticketserverip, ticketserverport) FROM '$$PATH$$/4483.dat';

--
-- Data for Name: videoserverwowza; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY videoserverwowza (id, ticketserverip, ticketserverport) FROM stdin;
\.
COPY videoserverwowza (id, ticketserverip, ticketserverport) FROM '$$PATH$$/4484.dat';

--
-- Data for Name: visualization; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY visualization (visualizationid, rentid, miliseconds, date) FROM stdin;
\.
COPY visualization (visualizationid, rentid, miliseconds, date) FROM '$$PATH$$/4485.dat';

--
-- Name: visualizationseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('visualizationseq', 1, false);


--
-- Data for Name: voucher; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY voucher (id, voucher, discount, creationdate, startdate, finishdate, durationdays, maxusers) FROM stdin;
\.
COPY voucher (id, voucher, discount, creationdate, startdate, finishdate, durationdays, maxusers) FROM '$$PATH$$/4487.dat';

--
-- Name: voucherseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('voucherseq', 1, true);


--
-- Data for Name: vouchervalidpackage; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY vouchervalidpackage (id, voucherid, packageid) FROM stdin;
\.
COPY vouchervalidpackage (id, voucherid, packageid) FROM '$$PATH$$/4489.dat';

--
-- Name: vouchervalidpackageseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('vouchervalidpackageseq', 3, true);


--
-- Data for Name: vouchervalidproduct; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY vouchervalidproduct (id, voucherid, productid) FROM stdin;
\.
COPY vouchervalidproduct (id, voucherid, productid) FROM '$$PATH$$/4491.dat';

--
-- Name: vouchervalidproductseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('vouchervalidproductseq', 1, true);


--
-- Data for Name: webbrowsingpluginconfig; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY webbrowsingpluginconfig (id, disclaimermessagei18n) FROM stdin;
\.
COPY webbrowsingpluginconfig (id, disclaimermessagei18n) FROM '$$PATH$$/4493.dat';

--
-- Name: webbrowsingpluginconfigseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('webbrowsingpluginconfigseq', 1, true);


--
-- Data for Name: welcomechannel; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY welcomechannel (welcomechannelid, vodkatvchannelid, locale) FROM stdin;
\.
COPY welcomechannel (welcomechannelid, vodkatvchannelid, locale) FROM '$$PATH$$/4495.dat';

--
-- Name: welcomechannelseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('welcomechannelseq', 1, false);


--
-- Data for Name: wowzaaessharedkey; Type: TABLE DATA; Schema: public; Owner: tahiti
--

COPY wowzaaessharedkey (id, key, validuntil) FROM stdin;
\.
COPY wowzaaessharedkey (id, key, validuntil) FROM '$$PATH$$/4497.dat';

--
-- Name: wowzaaessharedkeyseq; Type: SEQUENCE SET; Schema: public; Owner: tahiti
--

SELECT pg_catalog.setval('wowzaaessharedkeyseq', 1, true);


--
-- Name: accessrightallappspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightallapps
    ADD CONSTRAINT accessrightallappspk PRIMARY KEY (accessrightid);


--
-- Name: accessrightallchannelspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightallchannels
    ADD CONSTRAINT accessrightallchannelspk PRIMARY KEY (accessrightid);


--
-- Name: accessrightalldeviceclassespk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightalldeviceclasses
    ADD CONSTRAINT accessrightalldeviceclassespk PRIMARY KEY (accessrightid);


--
-- Name: accessrightallpluginspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightallplugins
    ADD CONSTRAINT accessrightallpluginspk PRIMARY KEY (accessrightid);


--
-- Name: accessrightappidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightappid
    ADD CONSTRAINT accessrightappidpk PRIMARY KEY (accessrightid);


--
-- Name: accessrightcasstatuspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightcasstatus
    ADD CONSTRAINT accessrightcasstatuspk PRIMARY KEY (accessrightcasstatusid);


--
-- Name: accessrightchannelcategorypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightchannelcategory
    ADD CONSTRAINT accessrightchannelcategorypk PRIMARY KEY (accessrightid);


--
-- Name: accessrightchannelidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightchannelid
    ADD CONSTRAINT accessrightchannelidpk PRIMARY KEY (accessrightid);


--
-- Name: accessrightconcurrentuserspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightconcurrentusers
    ADD CONSTRAINT accessrightconcurrentuserspk PRIMARY KEY (accessrightid);


--
-- Name: accessrightdeviceclassidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightdeviceclassid
    ADD CONSTRAINT accessrightdeviceclassidpk PRIMARY KEY (accessrightid);


--
-- Name: accessrightpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessright
    ADD CONSTRAINT accessrightpk PRIMARY KEY (accessrightid);


--
-- Name: accessrightpluginidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightpluginid
    ADD CONSTRAINT accessrightpluginidpk PRIMARY KEY (accessrightid);


--
-- Name: accessrightuserserviceidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accessrightuserserviceid
    ADD CONSTRAINT accessrightuserserviceidpk PRIMARY KEY (accessrightid);


--
-- Name: accountaccountrolepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountaccountrole
    ADD CONSTRAINT accountaccountrolepk PRIMARY KEY (id);


--
-- Name: accountlastplayedmediapk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountlastplayedmedia
    ADD CONSTRAINT accountlastplayedmediapk PRIMARY KEY (accountid);


--
-- Name: accountpinpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountpin
    ADD CONSTRAINT accountpinpk PRIMARY KEY (accountpinid);


--
-- Name: accountpinunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountpin
    ADD CONSTRAINT accountpinunique UNIQUE (accountid, pintype);


--
-- Name: accountpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY account
    ADD CONSTRAINT accountpk PRIMARY KEY (accountid);


--
-- Name: accountrecordingchannelpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountrecordingchannel
    ADD CONSTRAINT accountrecordingchannelpk PRIMARY KEY (accountrecordingchannelid);


--
-- Name: accountremoteaccessactivationcodeunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountremoteaccess
    ADD CONSTRAINT accountremoteaccessactivationcodeunique UNIQUE (activationcode);


--
-- Name: accountremoteaccesspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountremoteaccess
    ADD CONSTRAINT accountremoteaccesspk PRIMARY KEY (id);


--
-- Name: accountrolepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountrole
    ADD CONSTRAINT accountrolepk PRIMARY KEY (name);


--
-- Name: accountscreensaverpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY screensaver
    ADD CONSTRAINT accountscreensaverpk PRIMARY KEY (id);


--
-- Name: advertisingconfigpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY advertisingconfig
    ADD CONSTRAINT advertisingconfigpk PRIMARY KEY (id);


--
-- Name: advertisingmediapk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY advertisingmedia
    ADD CONSTRAINT advertisingmediapk PRIMARY KEY (id);


--
-- Name: advertisingmediauniqueassetidadvertisingtype; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY advertisingmedia
    ADD CONSTRAINT advertisingmediauniqueassetidadvertisingtype UNIQUE (assetid, advertisingtype);


--
-- Name: advertisingmetadataserverpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY advertisingmetadataserver
    ADD CONSTRAINT advertisingmetadataserverpk PRIMARY KEY (id);


--
-- Name: advertisingtagnodepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY advertisingtagtreenode
    ADD CONSTRAINT advertisingtagnodepk PRIMARY KEY (id);


--
-- Name: advertisingvisualizationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY advertisingvisualization
    ADD CONSTRAINT advertisingvisualizationpk PRIMARY KEY (id);


--
-- Name: am_multicastgrouppkid; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY am_multicastgroupalarm
    ADD CONSTRAINT am_multicastgrouppkid PRIMARY KEY (id);


--
-- Name: am_stbalarmpkid; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY am_stbalarm
    ADD CONSTRAINT am_stbalarmpkid PRIMARY KEY (id);


--
-- Name: applicationorderpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY applicationorder
    ADD CONSTRAINT applicationorderpk PRIMARY KEY (id);


--
-- Name: applicationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY application
    ADD CONSTRAINT applicationpk PRIMARY KEY (id);


--
-- Name: assetcollectionidunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rentingvalidity
    ADD CONSTRAINT assetcollectionidunique UNIQUE (assetcollectionid);


--
-- Name: asseti18npk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY asseti18n
    ADD CONSTRAINT asseti18npk PRIMARY KEY (asseti18nid);


--
-- Name: asseti18unique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY asseti18n
    ADD CONSTRAINT asseti18unique UNIQUE (userid, assetid, localeid);


--
-- Name: audiocodec_codec_key; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY audiocodec
    ADD CONSTRAINT audiocodec_codec_key UNIQUE (codec);


--
-- Name: audiocodecpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY audiocodec
    ADD CONSTRAINT audiocodecpk PRIMARY KEY (audiocodecid);


--
-- Name: auth_token_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY authtoken
    ADD CONSTRAINT auth_token_pkey PRIMARY KEY (token);


--
-- Name: banner_bannerid_key; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY banner
    ADD CONSTRAINT banner_bannerid_key UNIQUE (bannerid);


--
-- Name: banner_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY banner
    ADD CONSTRAINT banner_pkey PRIMARY KEY (bannerid);


--
-- Name: basicpackagepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT basicpackagepk PRIMARY KEY (id);


--
-- Name: billingpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY billing
    ADD CONSTRAINT billingpk PRIMARY KEY (billingid);


--
-- Name: cacheserverpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY cacheserver
    ADD CONSTRAINT cacheserverpk PRIMARY KEY (id);


--
-- Name: cacheversionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY cacheversion
    ADD CONSTRAINT cacheversionpk PRIMARY KEY (cachetype);


--
-- Name: catalogtreenodeassetpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY catalogtreenodeasset
    ADD CONSTRAINT catalogtreenodeassetpk PRIMARY KEY (catalogtreenodeassetid);


--
-- Name: catalogtreenodenamepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY catalogtreenodename
    ADD CONSTRAINT catalogtreenodenamepk PRIMARY KEY (catalogtreenodenameid);


--
-- Name: catalogtreenodenameunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY catalogtreenodename
    ADD CONSTRAINT catalogtreenodenameunique UNIQUE (catalogtreenodeid, locale);


--
-- Name: catalogtreenodepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY catalogtreenode
    ADD CONSTRAINT catalogtreenodepk PRIMARY KEY (catalogtreenodeid);


--
-- Name: catalogtreenodepropertypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY catalogtreenodeproperty
    ADD CONSTRAINT catalogtreenodepropertypk PRIMARY KEY (catalogtreenodepropertyid);


--
-- Name: catalogtreenodepropertyunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY catalogtreenodeproperty
    ADD CONSTRAINT catalogtreenodepropertyunique UNIQUE (catalogtreenodeid, skey);


--
-- Name: catalogtreenoderolepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY catalogtreenoderole
    ADD CONSTRAINT catalogtreenoderolepk PRIMARY KEY (id);


--
-- Name: catalogtreenodeunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY catalogtreenode
    ADD CONSTRAINT catalogtreenodeunique UNIQUE (parentcatalogtreenodeid, "position");


--
-- Name: catalogtreepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY catalogtree
    ADD CONSTRAINT catalogtreepk PRIMARY KEY (catalogtreename);


--
-- Name: categorypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT categorypk PRIMARY KEY (categoryid);


--
-- Name: channelaccesstypesubscriptionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelaccesstypesubscription
    ADD CONSTRAINT channelaccesstypesubscriptionpk PRIMARY KEY (channelaccesstypesubscriptionid);


--
-- Name: channelaccesstypesubscriptionunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelaccesstypesubscription
    ADD CONSTRAINT channelaccesstypesubscriptionunique UNIQUE (accountid, channelaccesstype);


--
-- Name: channelaudiopidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelaudiopid
    ADD CONSTRAINT channelaudiopidpk PRIMARY KEY (channelaudiopidid);


--
-- Name: channelcategorypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelcategory
    ADD CONSTRAINT channelcategorypk PRIMARY KEY (channelcategoryid);


--
-- Name: channeldata_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channeldata
    ADD CONSTRAINT channeldata_pkey PRIMARY KEY (id);


--
-- Name: channeldataplayinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channeldataplayinfo
    ADD CONSTRAINT channeldataplayinfo_pkey PRIMARY KEY (channeldataplayinfoid);


--
-- Name: channellistidandchannelnumberuniquechannellistitem; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channellistitem
    ADD CONSTRAINT channellistidandchannelnumberuniquechannellistitem UNIQUE (channellistid, channelnumber);


--
-- Name: channellistitempk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channellistitem
    ADD CONSTRAINT channellistitempk PRIMARY KEY (id);


--
-- Name: channellistpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channellist
    ADD CONSTRAINT channellistpk PRIMARY KEY (id);


--
-- Name: channellisttagpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY stbtagtreenodechannellist
    ADD CONSTRAINT channellisttagpk PRIMARY KEY (stbtagtreenodeid, channellistid);


--
-- Name: channelnetworkareapk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelaccessarea
    ADD CONSTRAINT channelnetworkareapk PRIMARY KEY (id);


--
-- Name: channelplayinfoiduniquelanguage; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelaudiopid
    ADD CONSTRAINT channelplayinfoiduniquelanguage UNIQUE (channeldataplayinfoid, language);


--
-- Name: channelsourceuripk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelsourceuri
    ADD CONSTRAINT channelsourceuripk PRIMARY KEY (channelsourceuriid);


--
-- Name: channelvideopidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelvideopid
    ADD CONSTRAINT channelvideopidpk PRIMARY KEY (channelvideopidid);


--
-- Name: collectionrulepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY collectionrule
    ADD CONSTRAINT collectionrulepk PRIMARY KEY (collectionruleid);


--
-- Name: contentcategorypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY contentcategory
    ADD CONSTRAINT contentcategorypk PRIMARY KEY (categoryid);


--
-- Name: contentcategoryunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY contentcategory
    ADD CONSTRAINT contentcategoryunique UNIQUE (categoryname);


--
-- Name: creditpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY credit
    ADD CONSTRAINT creditpk PRIMARY KEY (creditid);


--
-- Name: currencycurrencykeyunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY currency
    ADD CONSTRAINT currencycurrencykeyunique UNIQUE (currencykey);


--
-- Name: currencypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY currency
    ADD CONSTRAINT currencypk PRIMARY KEY (currencyid);


--
-- Name: customizationapplicationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY customizationsystemapplication
    ADD CONSTRAINT customizationapplicationpk PRIMARY KEY (id);


--
-- Name: customizationapplicationunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY customizationsystemapplication
    ADD CONSTRAINT customizationapplicationunique UNIQUE (customizationid, systemapplicationid);


--
-- Name: customizationpathpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY customizationpath
    ADD CONSTRAINT customizationpathpk PRIMARY KEY (id);


--
-- Name: customizationpathuniquedeviceclasspath; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY customizationpath
    ADD CONSTRAINT customizationpathuniquedeviceclasspath UNIQUE (deviceclass, path);


--
-- Name: customizationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY customization
    ADD CONSTRAINT customizationpk PRIMARY KEY (id);


--
-- Name: customizationuniquefilename; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY customization
    ADD CONSTRAINT customizationuniquefilename UNIQUE (screenshotfilename);


--
-- Name: defaultbasicpackagepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY defaultbasicpackage
    ADD CONSTRAINT defaultbasicpackagepk PRIMARY KEY (id);


--
-- Name: desktopareapk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktoparea
    ADD CONSTRAINT desktopareapk PRIMARY KEY (id);


--
-- Name: desktopconfigdesktoppk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktopconfigdesktop
    ADD CONSTRAINT desktopconfigdesktoppk PRIMARY KEY (id);


--
-- Name: desktopconfigpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktopconfig
    ADD CONSTRAINT desktopconfigpk PRIMARY KEY (id);


--
-- Name: desktopitemapppk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktopitemapp
    ADD CONSTRAINT desktopitemapppk PRIMARY KEY (id);


--
-- Name: desktopitemmediapk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktopitemmedia
    ADD CONSTRAINT desktopitemmediapk PRIMARY KEY (id);


--
-- Name: desktopitempk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktopitem
    ADD CONSTRAINT desktopitempk PRIMARY KEY (id);


--
-- Name: desktopitempluginpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktopitemplugin
    ADD CONSTRAINT desktopitempluginpk PRIMARY KEY (id);


--
-- Name: desktopitemwebpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktopitemweb
    ADD CONSTRAINT desktopitemwebpk PRIMARY KEY (id);


--
-- Name: desktopitemwidgetpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktopitemwidget
    ADD CONSTRAINT desktopitemwidgetpk PRIMARY KEY (id);


--
-- Name: desktoppk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY desktop
    ADD CONSTRAINT desktoppk PRIMARY KEY (id);


--
-- Name: developerpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY developer
    ADD CONSTRAINT developerpk PRIMARY KEY (developerid);


--
-- Name: devicestatuseventsserverpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY devicestatuseventsserver
    ADD CONSTRAINT devicestatuseventsserverpk PRIMARY KEY (deviceid);


--
-- Name: devicetypepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY devicetype
    ADD CONSTRAINT devicetypepk PRIMARY KEY (devicetypeid);


--
-- Name: dialingcodepkid; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY dialingcode
    ADD CONSTRAINT dialingcodepkid PRIMARY KEY (id);


--
-- Name: emailtemplatepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY emailtemplate
    ADD CONSTRAINT emailtemplatepk PRIMARY KEY (id);


--
-- Name: eventsserverpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY eventsserver
    ADD CONSTRAINT eventsserverpk PRIMARY KEY (id);


--
-- Name: favoritechannelpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY favoritechannel
    ADD CONSTRAINT favoritechannelpk PRIMARY KEY (id);


--
-- Name: favoritechannelunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY favoritechannel
    ADD CONSTRAINT favoritechannelunique UNIQUE (accountid, vodkatvchannelid);


--
-- Name: favoritepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY favorite
    ADD CONSTRAINT favoritepk PRIMARY KEY (favoriteid);


--
-- Name: filterlistconfigurationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY filterlistconfiguration
    ADD CONSTRAINT filterlistconfigurationpk PRIMARY KEY (filterlistconfigurationid);


--
-- Name: firmwarepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY firmware
    ADD CONSTRAINT firmwarepk PRIMARY KEY (version);


--
-- Name: genericinfopkid; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY genericinfo
    ADD CONSTRAINT genericinfopkid PRIMARY KEY (id);


--
-- Name: guestpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY guest
    ADD CONSTRAINT guestpk PRIMARY KEY (sessionaccountingid);


--
-- Name: guestservicespk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY guestservices
    ADD CONSTRAINT guestservicespk PRIMARY KEY (id);


--
-- Name: hotelpkid; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY hotel
    ADD CONSTRAINT hotelpkid PRIMARY KEY (id);


--
-- Name: i18npk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY i18n
    ADD CONSTRAINT i18npk PRIMARY KEY (i18nid);


--
-- Name: imagepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY image
    ADD CONSTRAINT imagepk PRIMARY KEY (filename);


--
-- Name: incompatibleproductpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY incompatibleproduct
    ADD CONSTRAINT incompatibleproductpk PRIMARY KEY (id);


--
-- Name: interactionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY interaction
    ADD CONSTRAINT interactionpk PRIMARY KEY (assetid, accountid);


--
-- Name: itemmappingscreenpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY itemmappingscreen
    ADD CONSTRAINT itemmappingscreenpk PRIMARY KEY (itemmappingscreenid);


--
-- Name: languagepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY language
    ADD CONSTRAINT languagepk PRIMARY KEY (languageid);


--
-- Name: linknameunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY link
    ADD CONSTRAINT linknameunique UNIQUE (name);


--
-- Name: linkpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY link
    ADD CONSTRAINT linkpk PRIMARY KEY (id);


--
-- Name: listconfigurationassetpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY listconfigurationasset
    ADD CONSTRAINT listconfigurationassetpk PRIMARY KEY (listconfigurationassetid);


--
-- Name: listconfigurationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY listconfiguration
    ADD CONSTRAINT listconfigurationpk PRIMARY KEY (listconfigurationid);


--
-- Name: logging_event_exception_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY logging_event_exception
    ADD CONSTRAINT logging_event_exception_pkey PRIMARY KEY (event_id, i);


--
-- Name: logging_event_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY logging_event
    ADD CONSTRAINT logging_event_pkey PRIMARY KEY (event_id);


--
-- Name: logging_event_property_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY logging_event_property
    ADD CONSTRAINT logging_event_property_pkey PRIMARY KEY (event_id, mapped_key);


--
-- Name: loginnameunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountremoteaccess
    ADD CONSTRAINT loginnameunique UNIQUE (loginname);


--
-- Name: masternodepkid; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY masternode
    ADD CONSTRAINT masternodepkid PRIMARY KEY (ip);


--
-- Name: memcachedkeypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY memcachedkey
    ADD CONSTRAINT memcachedkeypk PRIMARY KEY (id);


--
-- Name: menuoptionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY menuoption
    ADD CONSTRAINT menuoptionpk PRIMARY KEY (id);


--
-- Name: messagemailmessagepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY messagemail
    ADD CONSTRAINT messagemailmessagepk PRIMARY KEY (id);


--
-- Name: messagepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY predefinedmessage
    ADD CONSTRAINT messagepk PRIMARY KEY (id);


--
-- Name: messagepopuppk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY messagepopup
    ADD CONSTRAINT messagepopuppk PRIMARY KEY (id);


--
-- Name: messagescriptmessagepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY messagescript
    ADD CONSTRAINT messagescriptmessagepk PRIMARY KEY (id);


--
-- Name: messagespk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY message
    ADD CONSTRAINT messagespk PRIMARY KEY (id);


--
-- Name: messagewakeuppk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY messagewakeup
    ADD CONSTRAINT messagewakeuppk PRIMARY KEY (id);


--
-- Name: nameandtypeuniquechannellist; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channellist
    ADD CONSTRAINT nameandtypeuniquechannellist UNIQUE (name, typelist);


--
-- Name: nameuniquestbtagtree; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY stbtagtree
    ADD CONSTRAINT nameuniquestbtagtree UNIQUE (name);


--
-- Name: networkareacountrypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY networkareacountry
    ADD CONSTRAINT networkareacountrypk PRIMARY KEY (id);


--
-- Name: networkareaidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY networkarea
    ADD CONSTRAINT networkareaidpk PRIMARY KEY (id);


--
-- Name: networkareaipv4subnetpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY networkareaipv4subnet
    ADD CONSTRAINT networkareaipv4subnetpk PRIMARY KEY (id);


--
-- Name: outputsprotectionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY outputsprotection
    ADD CONSTRAINT outputsprotectionpk PRIMARY KEY (accountid);


--
-- Name: parentalcontrollevelpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY parentalcontrollevel
    ADD CONSTRAINT parentalcontrollevelpk PRIMARY KEY (accountid);


--
-- Name: parentalrating_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY parentalrating
    ADD CONSTRAINT parentalrating_pkey PRIMARY KEY (id);


--
-- Name: parentalratingmappingpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY parentalratingmapping
    ADD CONSTRAINT parentalratingmappingpk PRIMARY KEY (id);


--
-- Name: periodicitypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY periodicity
    ADD CONSTRAINT periodicitypk PRIMARY KEY (periodicityid);


--
-- Name: photopkid; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY photo
    ADD CONSTRAINT photopkid PRIMARY KEY (id);


--
-- Name: pk_databasechangeloglock; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY databasechangeloglock
    ADD CONSTRAINT pk_databasechangeloglock PRIMARY KEY (id);


--
-- Name: playerconfiguration_protocol_key; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY playerconfiguration
    ADD CONSTRAINT playerconfiguration_protocol_key UNIQUE (protocol);


--
-- Name: playerconfigurationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY playerconfiguration
    ADD CONSTRAINT playerconfigurationpk PRIMARY KEY (playerconfigurationid);


--
-- Name: playlistmappingscreenpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY playlistmappingscreen
    ADD CONSTRAINT playlistmappingscreenpk PRIMARY KEY (playlistmappingscreenid);


--
-- Name: plugin_webbrows_stburlitem_stbid_itemid_key; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY plugin_webbrows_stburlitem
    ADD CONSTRAINT plugin_webbrows_stburlitem_stbid_itemid_key UNIQUE (stbid, itemid);


--
-- Name: plugin_webbrows_stburlitemlang_stburlitemid_code_key; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY plugin_webbrows_stburlitemlang
    ADD CONSTRAINT plugin_webbrows_stburlitemlang_stburlitemid_code_key UNIQUE (stburlitemid, code);


--
-- Name: plugin_webbrows_stburlitemlangpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY plugin_webbrows_stburlitemlang
    ADD CONSTRAINT plugin_webbrows_stburlitemlangpk PRIMARY KEY (id);


--
-- Name: plugin_webbrows_stburlitempk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY plugin_webbrows_stburlitem
    ADD CONSTRAINT plugin_webbrows_stburlitempk PRIMARY KEY (id);


--
-- Name: pluginconfigurationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY pluginconfiguration
    ADD CONSTRAINT pluginconfigurationpk PRIMARY KEY (pluginconfigurationid);


--
-- Name: pluginconfigurationstartpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY pluginconfigurationstart
    ADD CONSTRAINT pluginconfigurationstartpk PRIMARY KEY (pluginconfigurationstartid);


--
-- Name: pluginscreenpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY pluginscreen
    ADD CONSTRAINT pluginscreenpk PRIMARY KEY (id);


--
-- Name: preferencemenuoptionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY preferencemenuoption
    ADD CONSTRAINT preferencemenuoptionpk PRIMARY KEY (preferencemenuoptionid);


--
-- Name: preferencemenuoptionunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY preferencemenuoption
    ADD CONSTRAINT preferencemenuoptionunique UNIQUE (preferencemenuoptionposition, preferencemenuoptionparentid);


--
-- Name: productincludedpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productincluded
    ADD CONSTRAINT productincludedpk PRIMARY KEY (id);


--
-- Name: productitemallappspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemallapps
    ADD CONSTRAINT productitemallappspk PRIMARY KEY (productitemid);


--
-- Name: productitemallchannelspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemallchannels
    ADD CONSTRAINT productitemallchannelspk PRIMARY KEY (productitemid);


--
-- Name: productitemalldeviceclassespk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemalldeviceclasses
    ADD CONSTRAINT productitemalldeviceclassespk PRIMARY KEY (productitemid);


--
-- Name: productitemallpluginspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemallplugins
    ADD CONSTRAINT productitemallpluginspk PRIMARY KEY (productitemid);


--
-- Name: productitemappidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemappid
    ADD CONSTRAINT productitemappidpk PRIMARY KEY (productitemid);


--
-- Name: productitemchannelcategorypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemchannelcategory
    ADD CONSTRAINT productitemchannelcategorypk PRIMARY KEY (productitemid);


--
-- Name: productitemchannelidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemchannelid
    ADD CONSTRAINT productitemchannelidpk PRIMARY KEY (productitemid);


--
-- Name: productitemconcurrentuserspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemconcurrentusers
    ADD CONSTRAINT productitemconcurrentuserspk PRIMARY KEY (productitemid);


--
-- Name: productitemdeviceclassidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemdeviceclassid
    ADD CONSTRAINT productitemdeviceclassidpk PRIMARY KEY (productitemid);


--
-- Name: productitempk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitem
    ADD CONSTRAINT productitempk PRIMARY KEY (productitemid);


--
-- Name: productitempluginidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitempluginid
    ADD CONSTRAINT productitempluginidpk PRIMARY KEY (productitemid);


--
-- Name: productitemuserserviceidpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY productitemuserserviceid
    ADD CONSTRAINT productitemuserserviceidpk PRIMARY KEY (productitemid);


--
-- Name: productpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY product
    ADD CONSTRAINT productpk PRIMARY KEY (id);


--
-- Name: propertypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY property
    ADD CONSTRAINT propertypk PRIMARY KEY (propertyid);


--
-- Name: protectedtargetaudiencepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY protectedtargetaudience
    ADD CONSTRAINT protectedtargetaudiencepk PRIMARY KEY (targetaudienceid);


--
-- Name: purchasepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY purchase
    ADD CONSTRAINT purchasepk PRIMARY KEY (purchaseid);


--
-- Name: pvrtaskpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY pvrtask
    ADD CONSTRAINT pvrtaskpk PRIMARY KEY (pvrtaskid);


--
-- Name: ratingorderunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY parentalrating
    ADD CONSTRAINT ratingorderunique UNIQUE (name, "position");


--
-- Name: rentingvaliditypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rentingvalidity
    ADD CONSTRAINT rentingvaliditypk PRIMARY KEY (rentingvalidityid);


--
-- Name: rentingvalidityunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rentingvalidity
    ADD CONSTRAINT rentingvalidityunique UNIQUE (rentingvalidityposition);


--
-- Name: rentpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rent
    ADD CONSTRAINT rentpk PRIMARY KEY (rentid);


--
-- Name: roleassetcollectioncontentpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY roleassetcollectioncontent
    ADD CONSTRAINT roleassetcollectioncontentpk PRIMARY KEY (id);


--
-- Name: roleassetcollectionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY roleassetcollection
    ADD CONSTRAINT roleassetcollectionpk PRIMARY KEY (id);


--
-- Name: roleassetcollectionunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY roleassetcollection
    ADD CONSTRAINT roleassetcollectionunique UNIQUE (roleid, assetcollectioncontentid);


--
-- Name: roleattributepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY roleattribute
    ADD CONSTRAINT roleattributepk PRIMARY KEY (id);


--
-- Name: rolemenuoption_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rolemenuoption
    ADD CONSTRAINT rolemenuoption_pkey PRIMARY KEY (id);


--
-- Name: rolenamemenuoptionidunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rolemenuoption
    ADD CONSTRAINT rolenamemenuoptionidunique UNIQUE (rolename, menuoptionid);


--
-- Name: rolepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT rolepk PRIMARY KEY (name);


--
-- Name: roompk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY room
    ADD CONSTRAINT roompk PRIMARY KEY (roomid);


--
-- Name: rssnameunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rss
    ADD CONSTRAINT rssnameunique UNIQUE (name);


--
-- Name: rsspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rss
    ADD CONSTRAINT rsspk PRIMARY KEY (id);


--
-- Name: rulenameandrulescollectionnameuniquerule; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT rulenameandrulescollectionnameuniquerule UNIQUE (rulename, rulescollectionname);


--
-- Name: rulepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT rulepk PRIMARY KEY (ruleid);


--
-- Name: rulepositionandrulescollectionnameuniquerule; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT rulepositionandrulescollectionnameuniquerule UNIQUE (ruleposition, rulescollectionname);


--
-- Name: rullescollectionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY rulescollection
    ADD CONSTRAINT rullescollectionpk PRIMARY KEY (rulescollectionname);


--
-- Name: schedulelinknameunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY schedulelink
    ADD CONSTRAINT schedulelinknameunique UNIQUE (name);


--
-- Name: schedulelinkpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY schedulelink
    ADD CONSTRAINT schedulelinkpk PRIMARY KEY (id);


--
-- Name: screensaverpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountscreensaver
    ADD CONSTRAINT screensaverpk PRIMARY KEY (id);


--
-- Name: sessionaccountingpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY sessionaccounting
    ADD CONSTRAINT sessionaccountingpk PRIMARY KEY (sessionaccountingid);


--
-- Name: stbchannelnumberpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelnumber
    ADD CONSTRAINT stbchannelnumberpk PRIMARY KEY (id);


--
-- Name: stbchannelvisibilitypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channelvisibility
    ADD CONSTRAINT stbchannelvisibilitypk PRIMARY KEY (id);


--
-- Name: stbinformationscreenpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY stbinformationscreen
    ADD CONSTRAINT stbinformationscreenpk PRIMARY KEY (stbid);


--
-- Name: stbpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY device
    ADD CONSTRAINT stbpk PRIMARY KEY (id);


--
-- Name: stbpreferencepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountpreference
    ADD CONSTRAINT stbpreferencepk PRIMARY KEY (id);


--
-- Name: stbpreferenceunique_stb_account_key; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY accountpreference
    ADD CONSTRAINT stbpreferenceunique_stb_account_key UNIQUE (deviceid, accountid, preferencekey);


--
-- Name: stbsessionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY stbsession
    ADD CONSTRAINT stbsessionpk PRIMARY KEY (stbid);


--
-- Name: stbstatuspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY stbstatus
    ADD CONSTRAINT stbstatuspk PRIMARY KEY (stbid);


--
-- Name: stbstatusstorage_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY stbstatusstorage
    ADD CONSTRAINT stbstatusstorage_pkey PRIMARY KEY (id);


--
-- Name: stbtagtreenodepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY stbtagtreenode
    ADD CONSTRAINT stbtagtreenodepk PRIMARY KEY (id);


--
-- Name: stbtagtreepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY stbtagtree
    ADD CONSTRAINT stbtagtreepk PRIMARY KEY (id);


--
-- Name: stbtypepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY deviceclass
    ADD CONSTRAINT stbtypepk PRIMARY KEY (id);


--
-- Name: stbunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY device
    ADD CONSTRAINT stbunique UNIQUE (physicalid);


--
-- Name: stbupgradepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY stbupgrade
    ADD CONSTRAINT stbupgradepk PRIMARY KEY (id);


--
-- Name: subscriptioncatalogpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY subscriptioncatalog
    ADD CONSTRAINT subscriptioncatalogpk PRIMARY KEY (id);


--
-- Name: subscriptiondependenciespk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY subscriptiondependencies
    ADD CONSTRAINT subscriptiondependenciespk PRIMARY KEY (id);


--
-- Name: systemapplicationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY systemapplication
    ADD CONSTRAINT systemapplicationpk PRIMARY KEY (id);


--
-- Name: systemapplicationuniqueversion; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY systemapplication
    ADD CONSTRAINT systemapplicationuniqueversion UNIQUE (installerpath);


--
-- Name: timezonepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY timezone
    ADD CONSTRAINT timezonepk PRIMARY KEY (timezoneid);


--
-- Name: timezoneunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY timezone
    ADD CONSTRAINT timezoneunique UNIQUE (tagtreenodeid);


--
-- Name: user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_name, role_name);


--
-- Name: userdesktoppk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY userdesktop
    ADD CONSTRAINT userdesktoppk PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_name);


--
-- Name: userservicepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY userservice
    ADD CONSTRAINT userservicepk PRIMARY KEY (userserviceid);


--
-- Name: videocodec_codec_key; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videocodec
    ADD CONSTRAINT videocodec_codec_key UNIQUE (codec);


--
-- Name: videocodecpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videocodec
    ADD CONSTRAINT videocodecpk PRIMARY KEY (videocodecid);


--
-- Name: videoserveractionpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserveraction
    ADD CONSTRAINT videoserveractionpk PRIMARY KEY (id);


--
-- Name: videoserverchannelstatusunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserverstreamstatus
    ADD CONSTRAINT videoserverchannelstatusunique UNIQUE (videoserverstatusid, streamname, bitrate);


--
-- Name: videoservercontentpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoservercontent
    ADD CONSTRAINT videoservercontentpk PRIMARY KEY (id);


--
-- Name: videoserverdevicetypepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserverdevicetype
    ADD CONSTRAINT videoserverdevicetypepk PRIMARY KEY (id);


--
-- Name: videoservergroupchanneldataplayinfopk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoservergroupchanneldataplayinfo
    ADD CONSTRAINT videoservergroupchanneldataplayinfopk PRIMARY KEY (videoservergroupid, channeldataplayinfoid);


--
-- Name: videoservergrouppk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoservergroup
    ADD CONSTRAINT videoservergrouppk PRIMARY KEY (id);


--
-- Name: videoservergroupvideoserverpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoservergroupvideoserver
    ADD CONSTRAINT videoservergroupvideoserverpk PRIMARY KEY (videoservergroupid, videoserverid);


--
-- Name: videoserveridpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserver
    ADD CONSTRAINT videoserveridpk PRIMARY KEY (id);


--
-- Name: videoserverstatuspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserverstatus
    ADD CONSTRAINT videoserverstatuspk PRIMARY KEY (id);


--
-- Name: videoserverstatusunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserverstatus
    ADD CONSTRAINT videoserverstatusunique UNIQUE (videoserverid, appname);


--
-- Name: videoserverstreamstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserverstreamstatus
    ADD CONSTRAINT videoserverstreamstatus_pkey PRIMARY KEY (id);


--
-- Name: videoserverswisstvpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserverswisstv
    ADD CONSTRAINT videoserverswisstvpk PRIMARY KEY (id);


--
-- Name: videoserverunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserver
    ADD CONSTRAINT videoserverunique UNIQUE (name);


--
-- Name: videoservervodkaticketspk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoservervodkatickets
    ADD CONSTRAINT videoservervodkaticketspk PRIMARY KEY (id);


--
-- Name: videoserverwowzapk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY videoserverwowza
    ADD CONSTRAINT videoserverwowzapk PRIMARY KEY (id);


--
-- Name: visualizationpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY visualization
    ADD CONSTRAINT visualizationpk PRIMARY KEY (visualizationid);


--
-- Name: vodkatvchanneliddeviceunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channeldataplayinfo
    ADD CONSTRAINT vodkatvchanneliddeviceunique UNIQUE (vodkatvchannelid, devicetypeid);


--
-- Name: vodkatvchannelidunique; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY channeldata
    ADD CONSTRAINT vodkatvchannelidunique UNIQUE (vodkatvchannelid);


--
-- Name: voucherpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY voucher
    ADD CONSTRAINT voucherpk PRIMARY KEY (id);


--
-- Name: vouchervalidpackagepk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY vouchervalidpackage
    ADD CONSTRAINT vouchervalidpackagepk PRIMARY KEY (id);


--
-- Name: vouchervalidproductpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY vouchervalidproduct
    ADD CONSTRAINT vouchervalidproductpk PRIMARY KEY (id);


--
-- Name: welcomechannelpk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY welcomechannel
    ADD CONSTRAINT welcomechannelpk PRIMARY KEY (welcomechannelid);


--
-- Name: welcomechanneluniquelocale; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY welcomechannel
    ADD CONSTRAINT welcomechanneluniquelocale UNIQUE (locale);


--
-- Name: wowzaaessharedkeypk; Type: CONSTRAINT; Schema: public; Owner: tahiti; Tablespace: 
--

ALTER TABLE ONLY wowzaaessharedkey
    ADD CONSTRAINT wowzaaessharedkeypk PRIMARY KEY (id);


--
-- Name: accessrightallappsbyaccessrightid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightallappsbyaccessrightid ON accessrightallapps USING btree (accessrightid);


--
-- Name: accessrightallchannelsbyaccessrightid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightallchannelsbyaccessrightid ON accessrightallchannels USING btree (accessrightid);


--
-- Name: accessrightallpluginsbyaccessrightid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightallpluginsbyaccessrightid ON accessrightallplugins USING btree (accessrightid);


--
-- Name: accessrightappidbyaccessrightid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightappidbyaccessrightid ON accessrightappid USING btree (accessrightid);


--
-- Name: accessrightbyaccessrightid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightbyaccessrightid ON accessright USING btree (accessrightid);


--
-- Name: accessrightbysessionaccountingid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightbysessionaccountingid ON accessright USING btree (sessionaccountingid);


--
-- Name: accessrightcasstatusid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightcasstatusid ON accessrightcasstatus USING btree (accessrightcasstatusid);


--
-- Name: accessrightchannelcategorybyaccessrightid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightchannelcategorybyaccessrightid ON accessrightchannelcategory USING btree (accessrightid);


--
-- Name: accessrightchannelidbyaccessrightid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightchannelidbyaccessrightid ON accessrightchannelid USING btree (accessrightid);


--
-- Name: accessrightpluginidbyaccessrightid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightpluginidbyaccessrightid ON accessrightpluginid USING btree (accessrightid);


--
-- Name: accessrightuserserviceidbyaccessrightid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accessrightuserserviceidbyaccessrightid ON accessrightuserserviceid USING btree (accessrightid);


--
-- Name: accountaccountrolebyaccountid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accountaccountrolebyaccountid ON accountaccountrole USING btree (accountid);


--
-- Name: accountindexbyaccountid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accountindexbyaccountid ON account USING btree (accountid);


--
-- Name: accountlastplayedmediaid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accountlastplayedmediaid ON accountlastplayedmedia USING btree (accountid);


--
-- Name: accountpinbyaccountid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accountpinbyaccountid ON accountpin USING btree (accountpinid);


--
-- Name: accountrecordingchannelindexbyaccountingid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accountrecordingchannelindexbyaccountingid ON accountrecordingchannel USING btree (accountid);


--
-- Name: accountrecordingchannelindexbyaccountrecordingchannelid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accountrecordingchannelindexbyaccountrecordingchannelid ON accountrecordingchannel USING btree (accountrecordingchannelid);


--
-- Name: accountrecordingchannelindexbyvodkatvchannelid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accountrecordingchannelindexbyvodkatvchannelid ON accountrecordingchannel USING btree (vodkatvchannelid);


--
-- Name: accountremoteaccessindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX accountremoteaccessindexbyid ON accountremoteaccess USING btree (id);


--
-- Name: am_multicastgroupalarmindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX am_multicastgroupalarmindexbyid ON am_multicastgroupalarm USING btree (id);


--
-- Name: am_stbalarmindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX am_stbalarmindexbyid ON am_stbalarm USING btree (id);


--
-- Name: applicationbyappid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX applicationbyappid ON application USING btree (id);


--
-- Name: applicationorderid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX applicationorderid ON applicationorder USING btree (appid);


--
-- Name: asseti18nindexbyasseti18nid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX asseti18nindexbyasseti18nid ON asseti18n USING btree (asseti18nid);


--
-- Name: authtokenaccountidindex; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX authtokenaccountidindex ON authtoken USING btree (accountid);


--
-- Name: authtokendeviceidindex; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX authtokendeviceidindex ON authtoken USING btree (deviceid);


--
-- Name: authtokensessionaccountingidindex; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX authtokensessionaccountingidindex ON authtoken USING btree (sessionaccountingid);


--
-- Name: basicpackagebyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX basicpackagebyid ON basicpackage USING btree (id);


--
-- Name: billingbybillingid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX billingbybillingid ON billing USING btree (billingid);


--
-- Name: cacheversionbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX cacheversionbyid ON cacheversion USING btree (cachetype);


--
-- Name: catalogtreeindexbycatalogtreeid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX catalogtreeindexbycatalogtreeid ON catalogtree USING btree (catalogtreename);


--
-- Name: catalogtreenodeassetindexbycatalogtreenodeid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX catalogtreenodeassetindexbycatalogtreenodeid ON catalogtreenodeasset USING btree (catalogtreenodeassetid);


--
-- Name: catalogtreenodeindexbycatalogtreenodeid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX catalogtreenodeindexbycatalogtreenodeid ON catalogtreenode USING btree (catalogtreenodeid);


--
-- Name: catalogtreenodenameindexbycatalogtreenodenameid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX catalogtreenodenameindexbycatalogtreenodenameid ON catalogtreenodename USING btree (catalogtreenodenameid);


--
-- Name: catalogtreenodepropertyindexbycatalogtreenodeid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX catalogtreenodepropertyindexbycatalogtreenodeid ON catalogtreenodeproperty USING btree (catalogtreenodeid);


--
-- Name: categoryindexbycategoryid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX categoryindexbycategoryid ON category USING btree (categoryid);


--
-- Name: channelaccesstypesubscriptionbyaccountid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channelaccesstypesubscriptionbyaccountid ON channelaccesstypesubscription USING btree (accountid);


--
-- Name: channelaccesstypesubscriptionbychannelaccesstypesubscriptionid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channelaccesstypesubscriptionbychannelaccesstypesubscriptionid ON channelaccesstypesubscription USING btree (channelaccesstypesubscriptionid);


--
-- Name: channelaudiopidindexbychannelaudiopidid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channelaudiopidindexbychannelaudiopidid ON channelaudiopid USING btree (channelaudiopidid);


--
-- Name: channelaudiopidindexbychanneldataplayinfoid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channelaudiopidindexbychanneldataplayinfoid ON channelaudiopid USING btree (channeldataplayinfoid);


--
-- Name: channelcategorybychannelcategoryid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channelcategorybychannelcategoryid ON channelcategory USING btree (channelcategoryid);


--
-- Name: channeldataindexbychannelid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channeldataindexbychannelid ON channeldata USING btree (vodkatvchannelid);


--
-- Name: channellistitemaccessbychannellistid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channellistitemaccessbychannellistid ON channellistitem USING btree (channellistid);


--
-- Name: channelsourceuriindexbychanneldataplayinfoid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channelsourceuriindexbychanneldataplayinfoid ON channelsourceuri USING btree (channeldataplayinfoid);


--
-- Name: channelsourceuriindexbychannelsourceuriid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channelsourceuriindexbychannelsourceuriid ON channelsourceuri USING btree (channelsourceuriid);


--
-- Name: channelvideopidindexbychanneldataplayinfoid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channelvideopidindexbychanneldataplayinfoid ON channelvideopid USING btree (channeldataplayinfoid);


--
-- Name: channelvideopidindexbychannelvideopidid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX channelvideopidindexbychannelvideopidid ON channelvideopid USING btree (channelvideopidid);


--
-- Name: collectionruleindexbycollectionruleid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX collectionruleindexbycollectionruleid ON collectionrule USING btree (collectionruleid);


--
-- Name: contentcategorybycategoryid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX contentcategorybycategoryid ON contentcategory USING btree (categoryid);


--
-- Name: contentcategorybycategoryname; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX contentcategorybycategoryname ON contentcategory USING btree (categoryname);


--
-- Name: creditindexbycreditid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX creditindexbycreditid ON credit USING btree (creditid);


--
-- Name: currencybycurrencyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX currencybycurrencyid ON currency USING btree (currencyid);


--
-- Name: currencybyvisualname; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX currencybyvisualname ON currency USING btree (visualname);


--
-- Name: customizationapplicationbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX customizationapplicationbyid ON customizationsystemapplication USING btree (id);


--
-- Name: customizationbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX customizationbyid ON customization USING btree (id);


--
-- Name: customizationpathbydeviceclasspath; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX customizationpathbydeviceclasspath ON customizationpath USING btree (deviceclass, path);


--
-- Name: customizationpathbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX customizationpathbyid ON customizationpath USING btree (id);


--
-- Name: defaultbasicpackageindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX defaultbasicpackageindexbyid ON defaultbasicpackage USING btree (id);


--
-- Name: desktopareabyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopareabyid ON desktoparea USING btree (id);


--
-- Name: desktopbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopbyid ON desktop USING btree (id);


--
-- Name: desktopconfigbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopconfigbyid ON desktopconfig USING btree (id);


--
-- Name: desktopconfigdesktopbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopconfigdesktopbyid ON desktopconfigdesktop USING btree (id);


--
-- Name: desktopitemappbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopitemappbyid ON desktopitemapp USING btree (id);


--
-- Name: desktopitembyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopitembyid ON desktopitem USING btree (id);


--
-- Name: desktopitemmediabyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopitemmediabyid ON desktopitemmedia USING btree (id);


--
-- Name: desktopitempluginbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopitempluginbyid ON desktopitemplugin USING btree (id);


--
-- Name: desktopitemwebbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopitemwebbyid ON desktopitemweb USING btree (id);


--
-- Name: desktopitemwidgetbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX desktopitemwidgetbyid ON desktopitemwidget USING btree (id);


--
-- Name: developerindexbydeveloperid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX developerindexbydeveloperid ON developer USING btree (developerid);


--
-- Name: dialingcodeindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX dialingcodeindexbyid ON dialingcode USING btree (id);


--
-- Name: favoritechannelbyaccountid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX favoritechannelbyaccountid ON favoritechannel USING btree (accountid);


--
-- Name: favoritechannelbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX favoritechannelbyid ON favoritechannel USING btree (id);


--
-- Name: favoriteindexbyfavoriteid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX favoriteindexbyfavoriteid ON favorite USING btree (favoriteid);


--
-- Name: filterlistconfigurationindexbyfilterlistconfigurationid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX filterlistconfigurationindexbyfilterlistconfigurationid ON filterlistconfiguration USING btree (filterlistconfigurationid);


--
-- Name: firmwareversion; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX firmwareversion ON firmware USING btree (version);


--
-- Name: genericinfoindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX genericinfoindexbyid ON genericinfo USING btree (id);


--
-- Name: guestindexbyguestid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX guestindexbyguestid ON guest USING btree (sessionaccountingid);


--
-- Name: guestservicesid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX guestservicesid ON guestservices USING btree (id);


--
-- Name: hotelindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX hotelindexbyid ON hotel USING btree (id);


--
-- Name: interactionindexbyinteractionkey; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX interactionindexbyinteractionkey ON interaction USING btree (assetid, accountid);


--
-- Name: itemmappingscreenbyitemmappingscreenid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX itemmappingscreenbyitemmappingscreenid ON itemmappingscreen USING btree (itemmappingscreenid);


--
-- Name: listconfigurationassetindexbylistconfigurationassetid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX listconfigurationassetindexbylistconfigurationassetid ON listconfigurationasset USING btree (listconfigurationassetid);


--
-- Name: listconfigurationbylistconfigurationid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX listconfigurationbylistconfigurationid ON listconfiguration USING btree (listconfigurationid);


--
-- Name: masternodeindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX masternodeindexbyid ON masternode USING btree (ip);


--
-- Name: memcachedkeycachekeycachetypeindex; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX memcachedkeycachekeycachetypeindex ON memcachedkey USING btree (cachekey, cachetype);


--
-- Name: memcachedkeyindexbyaccountid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX memcachedkeyindexbyaccountid ON memcachedkey USING btree (accountid);


--
-- Name: memcachedkeyindexbydeviceid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX memcachedkeyindexbydeviceid ON memcachedkey USING btree (deviceid);


--
-- Name: memcachedkeyindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX memcachedkeyindexbyid ON memcachedkey USING btree (id);


--
-- Name: memcachedkeyindexbysessionaccountingid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX memcachedkeyindexbysessionaccountingid ON memcachedkey USING btree (sessionaccountingid);


--
-- Name: memcachedkeyvaliduntilindex; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX memcachedkeyvaliduntilindex ON memcachedkey USING btree (validuntil);


--
-- Name: messageindexby_id; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX messageindexby_id ON message USING btree (id);


--
-- Name: messagemailbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX messagemailbyid ON messagemail USING btree (id);


--
-- Name: messagepopupbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX messagepopupbyid ON messagepopup USING btree (id);


--
-- Name: messagescriptbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX messagescriptbyid ON messagescript USING btree (id);


--
-- Name: messagewakeupbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX messagewakeupbyid ON messagewakeup USING btree (id);


--
-- Name: networkareaipv4subnetbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX networkareaipv4subnetbyid ON networkareaipv4subnet USING btree (id);


--
-- Name: outputsprotectionbyaccountid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX outputsprotectionbyaccountid ON outputsprotection USING btree (accountid);


--
-- Name: parentalcontrollevelbyaccountid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX parentalcontrollevelbyaccountid ON parentalcontrollevel USING btree (accountid);


--
-- Name: periodicityindexbyperiodicityid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX periodicityindexbyperiodicityid ON periodicity USING btree (periodicityid);


--
-- Name: photoindexbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX photoindexbyid ON photo USING btree (id);


--
-- Name: playerconfigurationbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX playerconfigurationbyid ON playerconfiguration USING btree (playerconfigurationid);


--
-- Name: playerconfigurationbyprotocol; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX playerconfigurationbyprotocol ON playerconfiguration USING btree (protocol);


--
-- Name: playlistmappingscreenbyplaylistmappingscreenid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX playlistmappingscreenbyplaylistmappingscreenid ON playlistmappingscreen USING btree (playlistmappingscreenid);


--
-- Name: plugin_webbrows_stburlitemaccessbystbid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX plugin_webbrows_stburlitemaccessbystbid ON plugin_webbrows_stburlitem USING btree (stbid);


--
-- Name: pluginconfigurationbypluginconfigurationid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX pluginconfigurationbypluginconfigurationid ON pluginconfiguration USING btree (pluginconfigurationid);


--
-- Name: pluginconfigurationstartbypluginconfigurationstartid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX pluginconfigurationstartbypluginconfigurationstartid ON pluginconfigurationstart USING btree (pluginconfigurationstartid);


--
-- Name: pluginscreenbypluginid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX pluginscreenbypluginid ON pluginscreen USING btree (id);


--
-- Name: prdocutbyproductid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX prdocutbyproductid ON product USING btree (id);


--
-- Name: prdocutbystbtagtreenodeid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX prdocutbystbtagtreenodeid ON product USING btree (tagtreenodeid);


--
-- Name: prdocutitembyproductid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX prdocutitembyproductid ON productitem USING btree (productid);


--
-- Name: prdocutitembyproductitemid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX prdocutitembyproductitemid ON productitem USING btree (productitemid);


--
-- Name: predefinedmessageindexbymessageid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX predefinedmessageindexbymessageid ON predefinedmessage USING btree (id);


--
-- Name: preferencemenuoptionindexbypreferencemenuoptionidid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX preferencemenuoptionindexbypreferencemenuoptionidid ON preferencemenuoption USING btree (preferencemenuoptionid);


--
-- Name: productincludedbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX productincludedbyid ON productincluded USING btree (id);


--
-- Name: productitemallappsbyproductitemid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX productitemallappsbyproductitemid ON productitemallapps USING btree (productitemid);


--
-- Name: productitemallchannelsbyproductitemid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX productitemallchannelsbyproductitemid ON productitemallchannels USING btree (productitemid);


--
-- Name: productitemallpluginsbyproductitemid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX productitemallpluginsbyproductitemid ON productitemallplugins USING btree (productitemid);


--
-- Name: productitemappidbyproductitemid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX productitemappidbyproductitemid ON productitemappid USING btree (productitemid);


--
-- Name: productitemchannelcategorybyproductitemid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX productitemchannelcategorybyproductitemid ON productitemchannelcategory USING btree (productitemid);


--
-- Name: productitemchannelidbyproductitemid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX productitemchannelidbyproductitemid ON productitemchannelid USING btree (productitemid);


--
-- Name: productitempluginidbyproductitemid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX productitempluginidbyproductitemid ON productitempluginid USING btree (productitemid);


--
-- Name: propertyindexbypropertyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX propertyindexbypropertyid ON property USING btree (propertyid);


--
-- Name: protectedtargetaudiencebytargetaudienceid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX protectedtargetaudiencebytargetaudienceid ON protectedtargetaudience USING btree (targetaudienceid);


--
-- Name: purchasebyproductid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX purchasebyproductid ON purchase USING btree (productid);


--
-- Name: purchasebypurchaseid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX purchasebypurchaseid ON purchase USING btree (purchaseid);


--
-- Name: purchasebysessionaccountingid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX purchasebysessionaccountingid ON purchase USING btree (sessionaccountingid);


--
-- Name: pvrtaskindexbyprvtaskid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX pvrtaskindexbyprvtaskid ON pvrtask USING btree (pvrtaskid);


--
-- Name: pvrtaskindexbypvrstate; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX pvrtaskindexbypvrstate ON pvrtask USING btree (pvrstate);


--
-- Name: pvrtaskindexbystbid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX pvrtaskindexbystbid ON pvrtask USING btree (stbid);


--
-- Name: rentindexbyrentid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX rentindexbyrentid ON rent USING btree (rentid);


--
-- Name: rentingvalidityindexbyassetcollectionid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX rentingvalidityindexbyassetcollectionid ON rentingvalidity USING btree (assetcollectionid);


--
-- Name: rentingvalidityindexbyrentingvalidityid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX rentingvalidityindexbyrentingvalidityid ON rentingvalidity USING btree (rentingvalidityid);


--
-- Name: roomindexbyroomid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX roomindexbyroomid ON room USING btree (roomid);


--
-- Name: ruleindexbyruleid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX ruleindexbyruleid ON rule USING btree (ruleid);


--
-- Name: rulescollectionindexbyrulescollectionname; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX rulescollectionindexbyrulescollectionname ON rulescollection USING btree (rulescollectionname);


--
-- Name: sessionaccountingindexbysessionaccountingid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX sessionaccountingindexbysessionaccountingid ON sessionaccounting USING btree (sessionaccountingid);


--
-- Name: stbchannelnumberindexbystbchannelnumberid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbchannelnumberindexbystbchannelnumberid ON channelnumber USING btree (id);


--
-- Name: stbchannelvisibilityindexbystbchannelvisibilityid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbchannelvisibilityindexbystbchannelvisibilityid ON channelvisibility USING btree (id);


--
-- Name: stbindexbystbid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbindexbystbid ON device USING btree (id);


--
-- Name: stbindexbystbphysicalid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbindexbystbphysicalid ON device USING btree (physicalid);


--
-- Name: stbinformationscreenbystbid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbinformationscreenbystbid ON stbinformationscreen USING btree (stbid);


--
-- Name: stbpreferenceindexbystb_account; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbpreferenceindexbystb_account ON accountpreference USING btree (deviceid, accountid);


--
-- Name: stbpreferenceindexbystb_account_key; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbpreferenceindexbystb_account_key ON accountpreference USING btree (deviceid, accountid, preferencekey);


--
-- Name: stbstatusid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbstatusid ON stbstatus USING btree (stbid);


--
-- Name: stbstatuslastupdatetime; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbstatuslastupdatetime ON stbstatus USING btree (lastupdatetime);


--
-- Name: stbtagtreenodeaccessbytreeid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbtagtreenodeaccessbytreeid ON stbtagtreenode USING btree (treeid);


--
-- Name: stbtypeindexbystbtypeid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbtypeindexbystbtypeid ON deviceclass USING btree (id);


--
-- Name: stbupgradeid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbupgradeid ON stbupgrade USING btree (id);


--
-- Name: stbupgradestbid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX stbupgradestbid ON stbupgrade USING btree (stbid);


--
-- Name: systemapplicationbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX systemapplicationbyid ON systemapplication USING btree (id);


--
-- Name: timezonebyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX timezonebyid ON timezone USING btree (timezoneid);


--
-- Name: timezonebytagtreenodeid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX timezonebytagtreenodeid ON timezone USING btree (tagtreenodeid);


--
-- Name: userdesktopbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX userdesktopbyid ON userdesktop USING btree (id);


--
-- Name: videoclubpluginconfigbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX videoclubpluginconfigbyid ON videoclubpluginconfig USING btree (id);


--
-- Name: videoserveractionbyvideoserveridandappname; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX videoserveractionbyvideoserveridandappname ON videoserveraction USING btree (videoserverid, appname);


--
-- Name: videoserverstreamstatusbyvideoserverandappname; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX videoserverstreamstatusbyvideoserverandappname ON videoserverstreamstatus USING btree (videoserverstatusid);


--
-- Name: visualizationindexbyvisualizationid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX visualizationindexbyvisualizationid ON visualization USING btree (visualizationid);


--
-- Name: webbrowsingpluginconfigbyid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX webbrowsingpluginconfigbyid ON webbrowsingpluginconfig USING btree (id);


--
-- Name: welcomechannelindexbywelcomechannelid; Type: INDEX; Schema: public; Owner: tahiti; Tablespace: 
--

CREATE INDEX welcomechannelindexbywelcomechannelid ON welcomechannel USING btree (welcomechannelid);


--
-- Name: delete_parent_accessrightappid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_accessrightappid AS
    ON DELETE TO accessrightappid DO  DELETE FROM accessright
  WHERE ((accessright.accessrightid = old.accessrightid) AND ((accessright.accessrighttype)::text = 'ACCESS_RIGHT_APP_ID'::text));


--
-- Name: delete_parent_accessrightchannelcategory; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_accessrightchannelcategory AS
    ON DELETE TO accessrightchannelcategory DO  DELETE FROM accessright
  WHERE ((accessright.accessrightid = old.accessrightid) AND ((accessright.accessrighttype)::text = 'ACCESS_RIGHT_CHANNEL_CATEGORY'::text));


--
-- Name: delete_parent_accessrightchannelid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_accessrightchannelid AS
    ON DELETE TO accessrightchannelid DO  DELETE FROM accessright
  WHERE ((accessright.accessrightid = old.accessrightid) AND ((accessright.accessrighttype)::text = 'ACCESS_RIGHT_CHANNEL_ID'::text));


--
-- Name: delete_parent_accessrightconcurrentusers; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_accessrightconcurrentusers AS
    ON DELETE TO accessrightconcurrentusers DO  DELETE FROM accessright
  WHERE ((accessright.accessrightid = old.accessrightid) AND ((accessright.accessrighttype)::text = 'ACCESS_RIGHT_CONCURRENT_USERS'::text));


--
-- Name: delete_parent_accessrightdeviceclassid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_accessrightdeviceclassid AS
    ON DELETE TO accessrightdeviceclassid DO  DELETE FROM accessright
  WHERE ((accessright.accessrightid = old.accessrightid) AND ((accessright.accessrighttype)::text = 'ACCESS_RIGHT_DEVICE_CLASS_ID'::text));


--
-- Name: delete_parent_accessrightpluginid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_accessrightpluginid AS
    ON DELETE TO accessrightpluginid DO  DELETE FROM accessright
  WHERE ((accessright.accessrightid = old.accessrightid) AND ((accessright.accessrighttype)::text = 'ACCESS_RIGHT_PLUGIN_ID'::text));


--
-- Name: delete_parent_accessrightuserserviceid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_accessrightuserserviceid AS
    ON DELETE TO accessrightuserserviceid DO  DELETE FROM accessright
  WHERE ((accessright.accessrightid = old.accessrightid) AND ((accessright.accessrighttype)::text = 'ACCESS_RIGHT_USER_SERVICE_ID'::text));


--
-- Name: delete_parent_desktopitemapp; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_desktopitemapp AS
    ON DELETE TO desktopitemapp DO  DELETE FROM desktopitem
  WHERE ((desktopitem.id = old.id) AND (desktopitem.desktopitemtype = 'app'::text));


--
-- Name: delete_parent_desktopitemmedia; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_desktopitemmedia AS
    ON DELETE TO desktopitemmedia DO  DELETE FROM desktopitem
  WHERE ((desktopitem.id = old.id) AND (desktopitem.desktopitemtype = 'media'::text));


--
-- Name: delete_parent_desktopitemplugin; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_desktopitemplugin AS
    ON DELETE TO desktopitemplugin DO  DELETE FROM desktopitem
  WHERE ((desktopitem.id = old.id) AND (desktopitem.desktopitemtype = 'plugin'::text));


--
-- Name: delete_parent_desktopitemweb; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_desktopitemweb AS
    ON DELETE TO desktopitemweb DO  DELETE FROM desktopitem
  WHERE ((desktopitem.id = old.id) AND (desktopitem.desktopitemtype = 'web'::text));


--
-- Name: delete_parent_desktopitemwidget; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_desktopitemwidget AS
    ON DELETE TO desktopitemwidget DO  DELETE FROM desktopitem
  WHERE ((desktopitem.id = old.id) AND (desktopitem.desktopitemtype = 'widget'::text));


--
-- Name: delete_parent_productitemappid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_productitemappid AS
    ON DELETE TO productitemappid DO  DELETE FROM productitem
  WHERE ((productitem.productitemid = old.productitemid) AND ((productitem.itemtype)::text = 'PRODUCT_ITEM_APP_ID'::text));


--
-- Name: delete_parent_productitemchannelcategory; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_productitemchannelcategory AS
    ON DELETE TO productitemchannelcategory DO  DELETE FROM productitem
  WHERE ((productitem.productitemid = old.productitemid) AND ((productitem.itemtype)::text = 'PRODUCT_ITEM_CHANNEL_CATEGORY'::text));


--
-- Name: delete_parent_productitemchannelid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_productitemchannelid AS
    ON DELETE TO productitemchannelid DO  DELETE FROM productitem
  WHERE ((productitem.productitemid = old.productitemid) AND ((productitem.itemtype)::text = 'PRODUCT_ITEM_CHANNEL_ID'::text));


--
-- Name: delete_parent_productitemconcurrentusers; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_productitemconcurrentusers AS
    ON DELETE TO productitemconcurrentusers DO  DELETE FROM productitem
  WHERE (productitem.productitemid = old.productitemid);


--
-- Name: delete_parent_productitemdeviceclassid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_productitemdeviceclassid AS
    ON DELETE TO productitemdeviceclassid DO  DELETE FROM productitem
  WHERE (productitem.productitemid = old.productitemid);


--
-- Name: delete_parent_productitempluginid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_productitempluginid AS
    ON DELETE TO productitempluginid DO  DELETE FROM productitem
  WHERE ((productitem.productitemid = old.productitemid) AND ((productitem.itemtype)::text = 'PRODUCT_ITEM_PLUGIN_ID'::text));


--
-- Name: delete_parent_productitemuserserviceid; Type: RULE; Schema: public; Owner: tahiti
--

CREATE RULE delete_parent_productitemuserserviceid AS
    ON DELETE TO productitemuserserviceid DO  DELETE FROM productitem
  WHERE ((productitem.productitemid = old.productitemid) AND ((productitem.itemtype)::text = 'PRODUCT_ITEM_USER_SERVICE_ID'::text));


--
-- Name: accessrightallappsidaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightallapps
    ADD CONSTRAINT accessrightallappsidaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON DELETE CASCADE;


--
-- Name: accessrightallchannelsaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightallchannels
    ADD CONSTRAINT accessrightallchannelsaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON DELETE CASCADE;


--
-- Name: accessrightalldeviceclassesaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightalldeviceclasses
    ADD CONSTRAINT accessrightalldeviceclassesaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON DELETE CASCADE;


--
-- Name: accessrightallpluginsaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightallplugins
    ADD CONSTRAINT accessrightallpluginsaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON DELETE CASCADE;


--
-- Name: accessrightappidaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightappid
    ADD CONSTRAINT accessrightappidaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accessrightappidapplicationfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightappid
    ADD CONSTRAINT accessrightappidapplicationfk FOREIGN KEY (appid) REFERENCES application(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accessrightcasstatusfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightcasstatus
    ADD CONSTRAINT accessrightcasstatusfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accessrightchannelcategoryaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightchannelcategory
    ADD CONSTRAINT accessrightchannelcategoryaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accessrightchannelcategorycontentcategoryfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightchannelcategory
    ADD CONSTRAINT accessrightchannelcategorycontentcategoryfk FOREIGN KEY (categoryid) REFERENCES contentcategory(categoryid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accessrightchannelidaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightchannelid
    ADD CONSTRAINT accessrightchannelidaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accessrightchannelidfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightchannelid
    ADD CONSTRAINT accessrightchannelidfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accessrightconcurrentusersaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightconcurrentusers
    ADD CONSTRAINT accessrightconcurrentusersaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON DELETE CASCADE;


--
-- Name: accessrightconcurrentusersdeviceclassfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightconcurrentusers
    ADD CONSTRAINT accessrightconcurrentusersdeviceclassfk FOREIGN KEY (deviceclassid) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: accessrightdeviceclassidaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightdeviceclassid
    ADD CONSTRAINT accessrightdeviceclassidaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON DELETE CASCADE;


--
-- Name: accessrightdeviceclassiddeviceclassfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightdeviceclassid
    ADD CONSTRAINT accessrightdeviceclassiddeviceclassfk FOREIGN KEY (deviceclassid) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: accessrightdeviceclassidfkdevice; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightdeviceclassid
    ADD CONSTRAINT accessrightdeviceclassidfkdevice FOREIGN KEY (deviceid) REFERENCES device(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: accessrightfkaccessrightcasstatus; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightcasstatus
    ADD CONSTRAINT accessrightfkaccessrightcasstatus FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON DELETE CASCADE;


--
-- Name: accessrightfksessionaccounting; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessright
    ADD CONSTRAINT accessrightfksessionaccounting FOREIGN KEY (sessionaccountingid) REFERENCES sessionaccounting(sessionaccountingid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accessrightpluginidaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightpluginid
    ADD CONSTRAINT accessrightpluginidaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON DELETE CASCADE;


--
-- Name: accessrightpluginidpluginconfigurationfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightpluginid
    ADD CONSTRAINT accessrightpluginidpluginconfigurationfk FOREIGN KEY (pluginconfigurationid) REFERENCES pluginconfiguration(pluginconfigurationid) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: accessrightproductfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessright
    ADD CONSTRAINT accessrightproductfk FOREIGN KEY (productid) REFERENCES product(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: accessrightproductitemfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessright
    ADD CONSTRAINT accessrightproductitemfk FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: accessrightpurchasefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessright
    ADD CONSTRAINT accessrightpurchasefk FOREIGN KEY (purchaseid) REFERENCES purchase(purchaseid) ON DELETE SET NULL;


--
-- Name: accessrightuserserviceidaccessrightfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightuserserviceid
    ADD CONSTRAINT accessrightuserserviceidaccessrightfk FOREIGN KEY (accessrightid) REFERENCES accessright(accessrightid) ON DELETE CASCADE;


--
-- Name: accessrightuserserviceiduserservicefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accessrightuserserviceid
    ADD CONSTRAINT accessrightuserserviceiduserservicefk FOREIGN KEY (userserviceid) REFERENCES userservice(userserviceid) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: accountaccountroleaccountfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountaccountrole
    ADD CONSTRAINT accountaccountroleaccountfk FOREIGN KEY (accountid) REFERENCES account(accountid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accountaccountroleaccountrolefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountaccountrole
    ADD CONSTRAINT accountaccountroleaccountrolefk FOREIGN KEY (rolename) REFERENCES accountrole(name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accountfkaccountrecordingchannel; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountrecordingchannel
    ADD CONSTRAINT accountfkaccountrecordingchannel FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: accountfkaccountremoteaccess; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountremoteaccess
    ADD CONSTRAINT accountfkaccountremoteaccess FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: accountfkfavorite; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY favorite
    ADD CONSTRAINT accountfkfavorite FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: accountfkinteraction; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY interaction
    ADD CONSTRAINT accountfkinteraction FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: accountfkrent; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rent
    ADD CONSTRAINT accountfkrent FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: accountfksessionaccounting; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY account
    ADD CONSTRAINT accountfksessionaccounting FOREIGN KEY (sessionaccountingid) REFERENCES sessionaccounting(sessionaccountingid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accountfkstbpreference; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountpreference
    ADD CONSTRAINT accountfkstbpreference FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: accountlastplayedmediafkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountlastplayedmedia
    ADD CONSTRAINT accountlastplayedmediafkaccount FOREIGN KEY (accountid) REFERENCES account(accountid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accountpinfkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountpin
    ADD CONSTRAINT accountpinfkaccount FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: accountrecordingchannelfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountrecordingchannel
    ADD CONSTRAINT accountrecordingchannelfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accountscreensaverscreensaverfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountscreensaver
    ADD CONSTRAINT accountscreensaverscreensaverfk FOREIGN KEY (screensaverid) REFERENCES screensaver(id) ON DELETE CASCADE;


--
-- Name: advertisingtagnodefkstbtagtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY advertisingtagtreenode
    ADD CONSTRAINT advertisingtagnodefkstbtagtreenode FOREIGN KEY (tagnodeid) REFERENCES stbtagtreenode(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: advertisingvisualizationfkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY advertisingvisualization
    ADD CONSTRAINT advertisingvisualizationfkaccount FOREIGN KEY (accountid) REFERENCES account(accountid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: applicationfkdesktopitemapp; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitemapp
    ADD CONSTRAINT applicationfkdesktopitemapp FOREIGN KEY (appid) REFERENCES application(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: applicationfkdesktopitemwidget; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitemwidget
    ADD CONSTRAINT applicationfkdesktopitemwidget FOREIGN KEY (appid) REFERENCES application(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: applicationorderfkapplication; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY applicationorder
    ADD CONSTRAINT applicationorderfkapplication FOREIGN KEY (appid) REFERENCES application(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: applicationorderparentfkapplication; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY applicationorder
    ADD CONSTRAINT applicationorderparentfkapplication FOREIGN KEY (parentappid) REFERENCES application(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: asseti18nfkuserid; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY asseti18n
    ADD CONSTRAINT asseti18nfkuserid FOREIGN KEY (userid) REFERENCES users(user_name) ON DELETE CASCADE;


--
-- Name: bannerfki18n; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY banner
    ADD CONSTRAINT bannerfki18n FOREIGN KEY (namei18nid) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bannerfktagtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY banner
    ADD CONSTRAINT bannerfktagtreenode FOREIGN KEY (tagtreenodeid) REFERENCES stbtagtreenode(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bannerimagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY banner
    ADD CONSTRAINT bannerimagefk FOREIGN KEY (filename) REFERENCES image(filename) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: basicpackagefkcustomization; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT basicpackagefkcustomization FOREIGN KEY (stbcustomizationid) REFERENCES customization(id);


--
-- Name: basicpackagefkdesktopconfig; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopconfig
    ADD CONSTRAINT basicpackagefkdesktopconfig FOREIGN KEY (packageid) REFERENCES basicpackage(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: basicpackagefkpccustomization; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT basicpackagefkpccustomization FOREIGN KEY (pccustomizationid) REFERENCES customization(id);


--
-- Name: basicpackagefkpurchase; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY purchase
    ADD CONSTRAINT basicpackagefkpurchase FOREIGN KEY (packageid) REFERENCES basicpackage(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: basicpackageimagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT basicpackageimagefk FOREIGN KEY (imagefilename) REFERENCES image(filename) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: basicpackagelogofk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT basicpackagelogofk FOREIGN KEY (logofilename) REFERENCES image(filename) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: billingfkcurrency; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY billing
    ADD CONSTRAINT billingfkcurrency FOREIGN KEY (currencyid) REFERENCES currency(currencyid) ON DELETE SET NULL;


--
-- Name: billingpurchasefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY billing
    ADD CONSTRAINT billingpurchasefk FOREIGN KEY (purchaseid) REFERENCES purchase(purchaseid) ON DELETE SET NULL;


--
-- Name: billingsessionaccountingfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY billing
    ADD CONSTRAINT billingsessionaccountingfk FOREIGN KEY (sessionaccountingid) REFERENCES sessionaccounting(sessionaccountingid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: catalogtreefkcatalogtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY catalogtreenode
    ADD CONSTRAINT catalogtreefkcatalogtreenode FOREIGN KEY (catalogtreename) REFERENCES catalogtree(catalogtreename) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: catalogtreenodeassetfkcatalogtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY catalogtreenodeasset
    ADD CONSTRAINT catalogtreenodeassetfkcatalogtreenode FOREIGN KEY (catalogtreenodeid) REFERENCES catalogtreenode(catalogtreenodeid) ON DELETE CASCADE;


--
-- Name: catalogtreenodefkcatalogtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY catalogtreenode
    ADD CONSTRAINT catalogtreenodefkcatalogtreenode FOREIGN KEY (parentcatalogtreenodeid) REFERENCES catalogtreenode(catalogtreenodeid) ON DELETE CASCADE;


--
-- Name: catalogtreenodefkcatalogtreenodename; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY catalogtreenodename
    ADD CONSTRAINT catalogtreenodefkcatalogtreenodename FOREIGN KEY (catalogtreenodeid) REFERENCES catalogtreenode(catalogtreenodeid) ON DELETE CASCADE;


--
-- Name: catalogtreenodepropertyfkcatalogtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY catalogtreenodeproperty
    ADD CONSTRAINT catalogtreenodepropertyfkcatalogtreenode FOREIGN KEY (catalogtreenodeid) REFERENCES catalogtreenode(catalogtreenodeid) ON DELETE CASCADE;


--
-- Name: catalogtreenoderolefkaccountrole; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY catalogtreenoderole
    ADD CONSTRAINT catalogtreenoderolefkaccountrole FOREIGN KEY (roleid) REFERENCES accountrole(name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: catalogtreenoderolefkcatalogtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY catalogtreenoderole
    ADD CONSTRAINT catalogtreenoderolefkcatalogtreenode FOREIGN KEY (catalogtreenodeid) REFERENCES catalogtreenode(catalogtreenodeid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categoryfkrule; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT categoryfkrule FOREIGN KEY (categoryid) REFERENCES category(categoryid) ON DELETE SET NULL;


--
-- Name: channelaccessareafkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelaccessarea
    ADD CONSTRAINT channelaccessareafkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channelaccessareafktagtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelaccessarea
    ADD CONSTRAINT channelaccessareafktagtreenode FOREIGN KEY (tagnodeid) REFERENCES stbtagtreenode(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channelaccesstypesubscriptionfkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelaccesstypesubscription
    ADD CONSTRAINT channelaccesstypesubscriptionfkaccount FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: channelaudiopidfkchanneldataplayinfoid; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelaudiopid
    ADD CONSTRAINT channelaudiopidfkchanneldataplayinfoid FOREIGN KEY (channeldataplayinfoid) REFERENCES channeldataplayinfo(channeldataplayinfoid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channelcategoryfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelcategory
    ADD CONSTRAINT channelcategoryfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channeldatafkparentalrating; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channeldata
    ADD CONSTRAINT channeldatafkparentalrating FOREIGN KEY (parentalratingid) REFERENCES parentalrating(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channeldataplayinfofk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoservergroupchanneldataplayinfo
    ADD CONSTRAINT channeldataplayinfofk FOREIGN KEY (channeldataplayinfoid) REFERENCES channeldataplayinfo(channeldataplayinfoid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channeldataplayinfofkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channeldataplayinfo
    ADD CONSTRAINT channeldataplayinfofkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channellistidfkchannellistitem; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channellistitem
    ADD CONSTRAINT channellistidfkchannellistitem FOREIGN KEY (channellistid) REFERENCES channellist(id) ON DELETE CASCADE;


--
-- Name: channellistitemfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channellistitem
    ADD CONSTRAINT channellistitemfkchanneldata FOREIGN KEY (internalchannelid) REFERENCES channeldata(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channellisttagfkchannellistid; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbtagtreenodechannellist
    ADD CONSTRAINT channellisttagfkchannellistid FOREIGN KEY (channellistid) REFERENCES channellist(id) ON DELETE CASCADE;


--
-- Name: channellisttagfkstbtagtreenodeid; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbtagtreenodechannellist
    ADD CONSTRAINT channellisttagfkstbtagtreenodeid FOREIGN KEY (stbtagtreenodeid) REFERENCES stbtagtreenode(id) ON DELETE CASCADE;


--
-- Name: channelnetworkareafknetworkarea; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelaccessarea
    ADD CONSTRAINT channelnetworkareafknetworkarea FOREIGN KEY (networkareaid) REFERENCES networkarea(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channelnumberfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelnumber
    ADD CONSTRAINT channelnumberfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channelsourceuripkchanneldataplayinfoid; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelsourceuri
    ADD CONSTRAINT channelsourceuripkchanneldataplayinfoid FOREIGN KEY (channeldataplayinfoid) REFERENCES channeldataplayinfo(channeldataplayinfoid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channelvideopidfkchanneldataplayinfoid; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelvideopid
    ADD CONSTRAINT channelvideopidfkchanneldataplayinfoid FOREIGN KEY (channeldataplayinfoid) REFERENCES channeldataplayinfo(channeldataplayinfoid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: channelvisibilityfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelvisibility
    ADD CONSTRAINT channelvisibilityfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: codecfkcodec; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelvideopid
    ADD CONSTRAINT codecfkcodec FOREIGN KEY (codec) REFERENCES videocodec(codec) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: codecfkcodec; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelaudiopid
    ADD CONSTRAINT codecfkcodec FOREIGN KEY (codec) REFERENCES audiocodec(codec) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contentcategorychannelcategory; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelcategory
    ADD CONSTRAINT contentcategorychannelcategory FOREIGN KEY (categoryid) REFERENCES contentcategory(categoryid) ON DELETE CASCADE;


--
-- Name: creditfkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY account
    ADD CONSTRAINT creditfkaccount FOREIGN KEY (creditid) REFERENCES credit(creditid) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: currencyfkbasicpackage; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT currencyfkbasicpackage FOREIGN KEY (currencyid) REFERENCES currency(currencyid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customizationapplicationfkcustomization; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY customizationsystemapplication
    ADD CONSTRAINT customizationapplicationfkcustomization FOREIGN KEY (customizationid) REFERENCES customization(id) ON DELETE CASCADE;


--
-- Name: customizationapplicationfksystemapplication; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY customizationsystemapplication
    ADD CONSTRAINT customizationapplicationfksystemapplication FOREIGN KEY (systemapplicationid) REFERENCES systemapplication(id) ON DELETE CASCADE;


--
-- Name: customizationfkdeviceclass; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY customization
    ADD CONSTRAINT customizationfkdeviceclass FOREIGN KEY (deviceclass) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customizationfksystemapplication; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY customization
    ADD CONSTRAINT customizationfksystemapplication FOREIGN KEY (mainapplicationid) REFERENCES systemapplication(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customizationimagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY customization
    ADD CONSTRAINT customizationimagefk FOREIGN KEY (screenshotfilename) REFERENCES image(filename) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: customizationpathfkcustomization; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY customizationpath
    ADD CONSTRAINT customizationpathfkcustomization FOREIGN KEY (customizationid) REFERENCES customization(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customizationpathfkdeviceclass; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY customizationpath
    ADD CONSTRAINT customizationpathfkdeviceclass FOREIGN KEY (deviceclass) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: defaultbasicpackagefkbasicpackage; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY defaultbasicpackage
    ADD CONSTRAINT defaultbasicpackagefkbasicpackage FOREIGN KEY (packageid) REFERENCES basicpackage(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: defaultbasicpackagefktagtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY defaultbasicpackage
    ADD CONSTRAINT defaultbasicpackagefktagtreenode FOREIGN KEY (tagtreenodeid) REFERENCES stbtagtreenode(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: descriptioni18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT descriptioni18nfk FOREIGN KEY (descriptioni18n) REFERENCES i18n(i18nid);


--
-- Name: desktopareabackgroundi18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktoparea
    ADD CONSTRAINT desktopareabackgroundi18nfk FOREIGN KEY (backgroundi18n) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopareatexti18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktoparea
    ADD CONSTRAINT desktopareatexti18nfk FOREIGN KEY (texti18n) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopconfigfkdesktopconfigdesktop; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopconfigdesktop
    ADD CONSTRAINT desktopconfigfkdesktopconfigdesktop FOREIGN KEY (desktopconfigid) REFERENCES desktopconfig(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopfkdesktoparea; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktoparea
    ADD CONSTRAINT desktopfkdesktoparea FOREIGN KEY (desktopid) REFERENCES desktop(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopfkdesktopconfigdesktop; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopconfigdesktop
    ADD CONSTRAINT desktopfkdesktopconfigdesktop FOREIGN KEY (desktopid) REFERENCES desktop(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopfkdesktopitem; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitem
    ADD CONSTRAINT desktopfkdesktopitem FOREIGN KEY (desktopid) REFERENCES desktop(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopitemfkdesktopitemapp; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitemapp
    ADD CONSTRAINT desktopitemfkdesktopitemapp FOREIGN KEY (id) REFERENCES desktopitem(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopitemfkdesktopitemmedia; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitemmedia
    ADD CONSTRAINT desktopitemfkdesktopitemmedia FOREIGN KEY (id) REFERENCES desktopitem(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopitemfkdesktopitemplugin; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitemplugin
    ADD CONSTRAINT desktopitemfkdesktopitemplugin FOREIGN KEY (id) REFERENCES desktopitem(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopitemfkdesktopitemweb; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitemweb
    ADD CONSTRAINT desktopitemfkdesktopitemweb FOREIGN KEY (id) REFERENCES desktopitem(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopitemfkdesktopitemwidget; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitemwidget
    ADD CONSTRAINT desktopitemfkdesktopitemwidget FOREIGN KEY (id) REFERENCES desktopitem(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: desktopitemwidgetfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitemmedia
    ADD CONSTRAINT desktopitemwidgetfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deviceclassfkdevice; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY device
    ADD CONSTRAINT deviceclassfkdevice FOREIGN KEY (deviceclass) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: devicestatuseventsserverfkauthtoken; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY devicestatuseventsserver
    ADD CONSTRAINT devicestatuseventsserverfkauthtoken FOREIGN KEY (token) REFERENCES authtoken(token) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: devicestatuseventsserverfkdevice; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY devicestatuseventsserver
    ADD CONSTRAINT devicestatuseventsserverfkdevice FOREIGN KEY (deviceid) REFERENCES device(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: devicetypedeviceclassfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY devicetype
    ADD CONSTRAINT devicetypedeviceclassfk FOREIGN KEY (deviceclass) REFERENCES deviceclass(id);


--
-- Name: emailtemplatecontentfki18n; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY emailtemplate
    ADD CONSTRAINT emailtemplatecontentfki18n FOREIGN KEY (subject) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: emailtemplatesubjectfki18n; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY emailtemplate
    ADD CONSTRAINT emailtemplatesubjectfki18n FOREIGN KEY (subject) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: favoritechannelfkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY favoritechannel
    ADD CONSTRAINT favoritechannelfkaccount FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: favoritechannelfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY favoritechannel
    ADD CONSTRAINT favoritechannelfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_channeldataplayinfo_devicetypeid; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channeldataplayinfo
    ADD CONSTRAINT fk_channeldataplayinfo_devicetypeid FOREIGN KEY (devicetypeid) REFERENCES devicetype(devicetypeid) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: guestfksessionaccounting; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY guest
    ADD CONSTRAINT guestfksessionaccounting FOREIGN KEY (sessionaccountingid) REFERENCES sessionaccounting(sessionaccountingid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: guestservicesimagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY guestservices
    ADD CONSTRAINT guestservicesimagefk FOREIGN KEY (hotelimagefilename) REFERENCES image(filename) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: i18nfkbasicpackage; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT i18nfkbasicpackage FOREIGN KEY (namei18n) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: incompatibleproductproductfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY incompatibleproduct
    ADD CONSTRAINT incompatibleproductproductfk FOREIGN KEY (productid) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: languagei18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY language
    ADD CONSTRAINT languagei18nfk FOREIGN KEY (languagei18n) REFERENCES i18n(i18nid);


--
-- Name: linkfki18n; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY link
    ADD CONSTRAINT linkfki18n FOREIGN KEY (namei18nid) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: listconfigurationassetfklistconfiguration; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY listconfigurationasset
    ADD CONSTRAINT listconfigurationassetfklistconfiguration FOREIGN KEY (listconfigurationid) REFERENCES listconfiguration(listconfigurationid) ON DELETE CASCADE;


--
-- Name: listconfigurationfkfilterlistconfiguration; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY filterlistconfiguration
    ADD CONSTRAINT listconfigurationfkfilterlistconfiguration FOREIGN KEY (listconfigurationid) REFERENCES listconfiguration(listconfigurationid) ON DELETE CASCADE;


--
-- Name: logging_event_exception_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY logging_event_exception
    ADD CONSTRAINT logging_event_exception_event_id_fkey FOREIGN KEY (event_id) REFERENCES logging_event(event_id);


--
-- Name: logging_event_property_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY logging_event_property
    ADD CONSTRAINT logging_event_property_event_id_fkey FOREIGN KEY (event_id) REFERENCES logging_event(event_id);


--
-- Name: menuoptionfkmenuoption; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY menuoption
    ADD CONSTRAINT menuoptionfkmenuoption FOREIGN KEY (parentmenuid) REFERENCES menuoption(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: menuoptionhelpmessagei18nfki18n; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY menuoption
    ADD CONSTRAINT menuoptionhelpmessagei18nfki18n FOREIGN KEY (helpmessagei18n) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: menuoptionlabeli18nfki18n; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY menuoption
    ADD CONSTRAINT menuoptionlabeli18nfki18n FOREIGN KEY (labeli18n) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messageaccountidfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY message
    ADD CONSTRAINT messageaccountidfk FOREIGN KEY (accountid) REFERENCES account(accountid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messagedeviceidfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY message
    ADD CONSTRAINT messagedeviceidfk FOREIGN KEY (stbid) REFERENCES device(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messagemailmessagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY messagemail
    ADD CONSTRAINT messagemailmessagefk FOREIGN KEY (id) REFERENCES message(id) ON DELETE CASCADE;


--
-- Name: messagepopupmessagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY messagepopup
    ADD CONSTRAINT messagepopupmessagefk FOREIGN KEY (id) REFERENCES message(id) ON DELETE CASCADE;


--
-- Name: messagescriptmessagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY messagescript
    ADD CONSTRAINT messagescriptmessagefk FOREIGN KEY (id) REFERENCES message(id) ON DELETE CASCADE;


--
-- Name: messagewakeupmessagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY messagewakeup
    ADD CONSTRAINT messagewakeupmessagefk FOREIGN KEY (id) REFERENCES message(id) ON DELETE CASCADE;


--
-- Name: networkareacountryfknetworkarea; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY networkareacountry
    ADD CONSTRAINT networkareacountryfknetworkarea FOREIGN KEY (networkareaid) REFERENCES networkarea(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: networkareafkvideoserver; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoserver
    ADD CONSTRAINT networkareafkvideoserver FOREIGN KEY (networkareaid) REFERENCES networkarea(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: networkareaipv4subnetfknetworkarea; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY networkareaipv4subnet
    ADD CONSTRAINT networkareaipv4subnetfknetworkarea FOREIGN KEY (networkareaid) REFERENCES networkarea(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: outputsprotectionfkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY outputsprotection
    ADD CONSTRAINT outputsprotectionfkaccount FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: packagefkproductincluded; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productincluded
    ADD CONSTRAINT packagefkproductincluded FOREIGN KEY (packageid) REFERENCES basicpackage(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parentalcontrollevelfkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY parentalcontrollevel
    ADD CONSTRAINT parentalcontrollevelfkaccount FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: parentalratingmappingfkparentalrating; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY parentalratingmapping
    ADD CONSTRAINT parentalratingmappingfkparentalrating FOREIGN KEY (parentalratingid) REFERENCES parentalrating(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parentidfkstbtagtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbtagtreenode
    ADD CONSTRAINT parentidfkstbtagtreenode FOREIGN KEY (parentid) REFERENCES stbtagtreenode(id) ON DELETE CASCADE;


--
-- Name: playlistmappingscreenfkitemmappingscreen; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY itemmappingscreen
    ADD CONSTRAINT playlistmappingscreenfkitemmappingscreen FOREIGN KEY (playlistmappingscreenid) REFERENCES playlistmappingscreen(playlistmappingscreenid) ON DELETE CASCADE;


--
-- Name: playlistmappingscreenfkroom; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY playlistmappingscreen
    ADD CONSTRAINT playlistmappingscreenfkroom FOREIGN KEY (roomid) REFERENCES room(roomid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: plugin_webbrows_stbfkstburlitem; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY plugin_webbrows_stburlitem
    ADD CONSTRAINT plugin_webbrows_stbfkstburlitem FOREIGN KEY (stbid) REFERENCES device(id) ON DELETE CASCADE;


--
-- Name: plugin_webbrows_stburlitemidfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY plugin_webbrows_stburlitemlang
    ADD CONSTRAINT plugin_webbrows_stburlitemidfk FOREIGN KEY (stburlitemid) REFERENCES plugin_webbrows_stburlitem(id) ON DELETE CASCADE;


--
-- Name: pluginconfigurationfkdesktopitemplugin; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitemplugin
    ADD CONSTRAINT pluginconfigurationfkdesktopitemplugin FOREIGN KEY (pluginconfigurationid) REFERENCES pluginconfiguration(pluginconfigurationid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pluginconfigurationfkpluginconfigurationstart; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY pluginconfigurationstart
    ADD CONSTRAINT pluginconfigurationfkpluginconfigurationstart FOREIGN KEY (pluginconfigurationid) REFERENCES pluginconfiguration(pluginconfigurationid) ON DELETE CASCADE;


--
-- Name: pluginconfigurationfkpluginscreen; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY pluginscreen
    ADD CONSTRAINT pluginconfigurationfkpluginscreen FOREIGN KEY (pluginconfigurationid) REFERENCES pluginconfiguration(pluginconfigurationid) ON DELETE CASCADE;


--
-- Name: product_currencyid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_currencyid_fkey FOREIGN KEY (currencyid) REFERENCES currency(currencyid) ON DELETE RESTRICT;


--
-- Name: productfkproductincluded; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productincluded
    ADD CONSTRAINT productfkproductincluded FOREIGN KEY (productid) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productimagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY product
    ADD CONSTRAINT productimagefk FOREIGN KEY (imagefilename) REFERENCES image(filename) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: productitemallappsproductitemfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemallapps
    ADD CONSTRAINT productitemallappsproductitemfk FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON DELETE CASCADE;


--
-- Name: productitemallchannelsproductitemfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemallchannels
    ADD CONSTRAINT productitemallchannelsproductitemfk FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON DELETE CASCADE;


--
-- Name: productitemalldeviceclassesfkproductitem; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemalldeviceclasses
    ADD CONSTRAINT productitemalldeviceclassesfkproductitem FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON DELETE CASCADE;


--
-- Name: productitemallpluginsproductitemfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemallplugins
    ADD CONSTRAINT productitemallpluginsproductitemfk FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON DELETE CASCADE;


--
-- Name: productitemappidpluginconfigurationfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemappid
    ADD CONSTRAINT productitemappidpluginconfigurationfk FOREIGN KEY (appid) REFERENCES application(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitemappidproductitemfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemappid
    ADD CONSTRAINT productitemappidproductitemfk FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitemchannelcategorycontentcategoryfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemchannelcategory
    ADD CONSTRAINT productitemchannelcategorycontentcategoryfk FOREIGN KEY (categoryid) REFERENCES contentcategory(categoryid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitemchannelcategoryproductitemfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemchannelcategory
    ADD CONSTRAINT productitemchannelcategoryproductitemfk FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitemchannelidfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemchannelid
    ADD CONSTRAINT productitemchannelidfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitemchannelidproductitemfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemchannelid
    ADD CONSTRAINT productitemchannelidproductitemfk FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitemconcurrentusersfkdeviceclass; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemconcurrentusers
    ADD CONSTRAINT productitemconcurrentusersfkdeviceclass FOREIGN KEY (deviceclassid) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitemconcurrentusersfkproductitem; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemconcurrentusers
    ADD CONSTRAINT productitemconcurrentusersfkproductitem FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON DELETE CASCADE;


--
-- Name: productitemdeviceclassidfkdeviceclass; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemdeviceclassid
    ADD CONSTRAINT productitemdeviceclassidfkdeviceclass FOREIGN KEY (deviceclassid) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitemdeviceclassidfkproductitem; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemdeviceclassid
    ADD CONSTRAINT productitemdeviceclassidfkproductitem FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitempluginidpluginconfigurationfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitempluginid
    ADD CONSTRAINT productitempluginidpluginconfigurationfk FOREIGN KEY (pluginconfigurationid) REFERENCES pluginconfiguration(pluginconfigurationid) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: productitempluginidproductitemfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitempluginid
    ADD CONSTRAINT productitempluginidproductitemfk FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON DELETE CASCADE;


--
-- Name: productitemproductfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitem
    ADD CONSTRAINT productitemproductfk FOREIGN KEY (productid) REFERENCES product(id) ON DELETE CASCADE;


--
-- Name: productitemuserserviceidfkproductitem; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemuserserviceid
    ADD CONSTRAINT productitemuserserviceidfkproductitem FOREIGN KEY (productitemid) REFERENCES productitem(productitemid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productitemuserserviceidfkuserservice; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY productitemuserserviceid
    ADD CONSTRAINT productitemuserserviceidfkuserservice FOREIGN KEY (userserviceid) REFERENCES userservice(userserviceid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: productlogofk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY product
    ADD CONSTRAINT productlogofk FOREIGN KEY (logofilename) REFERENCES image(filename) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- Name: productproductdesci18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY product
    ADD CONSTRAINT productproductdesci18nfk FOREIGN KEY (descriptioni18n) REFERENCES i18n(i18nid);


--
-- Name: productproductnamei18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY product
    ADD CONSTRAINT productproductnamei18nfk FOREIGN KEY (namei18n) REFERENCES i18n(i18nid);


--
-- Name: productproductshortdesci18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY product
    ADD CONSTRAINT productproductshortdesci18nfk FOREIGN KEY (shortdescriptioni18n) REFERENCES i18n(i18nid);


--
-- Name: productstbtagtreenodefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY product
    ADD CONSTRAINT productstbtagtreenodefk FOREIGN KEY (tagtreenodeid) REFERENCES stbtagtreenode(id) ON DELETE SET NULL;


--
-- Name: purchasefkvoucher; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY purchase
    ADD CONSTRAINT purchasefkvoucher FOREIGN KEY (voucherid) REFERENCES voucher(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchaseproductfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY purchase
    ADD CONSTRAINT purchaseproductfk FOREIGN KEY (productid) REFERENCES product(id) ON DELETE SET NULL;


--
-- Name: purchasesessionaccountingfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY purchase
    ADD CONSTRAINT purchasesessionaccountingfk FOREIGN KEY (sessionaccountingid) REFERENCES sessionaccounting(sessionaccountingid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pvrtaskfkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY pvrtask
    ADD CONSTRAINT pvrtaskfkaccount FOREIGN KEY (accountid) REFERENCES account(accountid) ON DELETE CASCADE;


--
-- Name: pvrtaskfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY pvrtask
    ADD CONSTRAINT pvrtaskfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pvrtaskfkstb; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY pvrtask
    ADD CONSTRAINT pvrtaskfkstb FOREIGN KEY (stbid) REFERENCES device(id) ON DELETE CASCADE;


--
-- Name: rentfksessionaccounting; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rent
    ADD CONSTRAINT rentfksessionaccounting FOREIGN KEY (sessionaccountingid) REFERENCES sessionaccounting(sessionaccountingid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rentfkvisualization; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY visualization
    ADD CONSTRAINT rentfkvisualization FOREIGN KEY (rentid) REFERENCES rent(rentid) ON DELETE CASCADE;


--
-- Name: roleassetcollectionfkrole; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY roleassetcollection
    ADD CONSTRAINT roleassetcollectionfkrole FOREIGN KEY (roleid) REFERENCES accountrole(name);


--
-- Name: roleassetcollectionfkroleassetcollectioncontent; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY roleassetcollection
    ADD CONSTRAINT roleassetcollectionfkroleassetcollectioncontent FOREIGN KEY (assetcollectioncontentid) REFERENCES roleassetcollectioncontent(id) ON DELETE CASCADE;


--
-- Name: roleattributefkrole; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY roleattribute
    ADD CONSTRAINT roleattributefkrole FOREIGN KEY (rolename) REFERENCES role(name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rolefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rolemenuoption
    ADD CONSTRAINT rolefk FOREIGN KEY (rolename) REFERENCES role(name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: roomfkstb; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY device
    ADD CONSTRAINT roomfkstb FOREIGN KEY (roomid) REFERENCES room(roomid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: roomfktagtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY room
    ADD CONSTRAINT roomfktagtreenode FOREIGN KEY (tagtreenodeid) REFERENCES stbtagtreenode(id) ON DELETE SET NULL;


--
-- Name: rssfki18n; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rss
    ADD CONSTRAINT rssfki18n FOREIGN KEY (namei18nid) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rulefkcollectionrule; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY collectionrule
    ADD CONSTRAINT rulefkcollectionrule FOREIGN KEY (ruleid) REFERENCES rule(ruleid) ON DELETE CASCADE;


--
-- Name: rulefkperiodicity; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY periodicity
    ADD CONSTRAINT rulefkperiodicity FOREIGN KEY (ruleid) REFERENCES rule(ruleid) ON DELETE CASCADE;


--
-- Name: rulefkrent; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rent
    ADD CONSTRAINT rulefkrent FOREIGN KEY (ruleid) REFERENCES rule(ruleid) ON DELETE SET NULL;


--
-- Name: rulefkroom; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT rulefkroom FOREIGN KEY (roomid) REFERENCES room(roomid) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rulescollectionfkrule; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT rulescollectionfkrule FOREIGN KEY (rulescollectionname) REFERENCES rulescollection(rulescollectionname) ON DELETE CASCADE;


--
-- Name: schedulelinkfki18n; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY schedulelink
    ADD CONSTRAINT schedulelinkfki18n FOREIGN KEY (namei18nid) REFERENCES i18n(i18nid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: screensaveri18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY screensaver
    ADD CONSTRAINT screensaveri18nfk FOREIGN KEY (namei18nid) REFERENCES i18n(i18nid) ON DELETE CASCADE;


--
-- Name: sessionaccountingfkroom; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY sessionaccounting
    ADD CONSTRAINT sessionaccountingfkroom FOREIGN KEY (roomid) REFERENCES room(roomid) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shortdescriptioni18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT shortdescriptioni18nfk FOREIGN KEY (shortdescriptioni18n) REFERENCES i18n(i18nid);


--
-- Name: stb_stbtagtreenodeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY device
    ADD CONSTRAINT stb_stbtagtreenodeid_fkey FOREIGN KEY (tagtreenodeid) REFERENCES stbtagtreenode(id) ON DELETE SET NULL;


--
-- Name: stbfkchannelnumber; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelnumber
    ADD CONSTRAINT stbfkchannelnumber FOREIGN KEY (deviceid) REFERENCES device(id) ON DELETE CASCADE;


--
-- Name: stbfkchannelvisibility; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY channelvisibility
    ADD CONSTRAINT stbfkchannelvisibility FOREIGN KEY (deviceid) REFERENCES device(id) ON DELETE CASCADE;


--
-- Name: stbfkrent; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rent
    ADD CONSTRAINT stbfkrent FOREIGN KEY (stbid) REFERENCES device(id) ON DELETE SET NULL;


--
-- Name: stbfkrule; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT stbfkrule FOREIGN KEY (stbid) REFERENCES device(id) ON DELETE SET NULL;


--
-- Name: stbfkstbinformationscreen; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbinformationscreen
    ADD CONSTRAINT stbfkstbinformationscreen FOREIGN KEY (stbid) REFERENCES device(id) ON DELETE CASCADE;


--
-- Name: stbfkstbpreference; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY accountpreference
    ADD CONSTRAINT stbfkstbpreference FOREIGN KEY (deviceid) REFERENCES device(id) ON DELETE CASCADE;


--
-- Name: stbfkstbsession; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbsession
    ADD CONSTRAINT stbfkstbsession FOREIGN KEY (stbid) REFERENCES device(id) ON DELETE CASCADE;


--
-- Name: stbitemmappingscreenfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY itemmappingscreen
    ADD CONSTRAINT stbitemmappingscreenfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stbmappingscreenconfigurationfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY mappingscreenconfiguration
    ADD CONSTRAINT stbmappingscreenconfigurationfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stbstatusfkstb; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbstatus
    ADD CONSTRAINT stbstatusfkstb FOREIGN KEY (stbid) REFERENCES device(id) ON DELETE CASCADE;


--
-- Name: stbstatusstoragefkstbstatus; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbstatusstorage
    ADD CONSTRAINT stbstatusstoragefkstbstatus FOREIGN KEY (stbid) REFERENCES stbstatus(stbid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stbtypefkpluginconfigurationstart; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY pluginconfigurationstart
    ADD CONSTRAINT stbtypefkpluginconfigurationstart FOREIGN KEY (stbtypeid) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stbtypefkpluginscreen; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY pluginscreen
    ADD CONSTRAINT stbtypefkpluginscreen FOREIGN KEY (stbtypeid) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stbupgradefkfirmware; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbupgrade
    ADD CONSTRAINT stbupgradefkfirmware FOREIGN KEY (toversion) REFERENCES firmware(version) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stbupgradefkstb; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbupgrade
    ADD CONSTRAINT stbupgradefkstb FOREIGN KEY (stbid) REFERENCES device(id) ON DELETE CASCADE;


--
-- Name: subscriptioncatalogpackagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY subscriptioncatalog
    ADD CONSTRAINT subscriptioncatalogpackagefk FOREIGN KEY (packageid) REFERENCES basicpackage(id) ON DELETE CASCADE;


--
-- Name: subscriptioncatalogproductfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY subscriptioncatalog
    ADD CONSTRAINT subscriptioncatalogproductfk FOREIGN KEY (productid) REFERENCES product(id) ON DELETE CASCADE;


--
-- Name: subscriptiondependenciespackagefk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY subscriptiondependencies
    ADD CONSTRAINT subscriptiondependenciespackagefk FOREIGN KEY (packageid) REFERENCES basicpackage(id) ON DELETE CASCADE;


--
-- Name: subscriptiondependenciesproductfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY subscriptiondependencies
    ADD CONSTRAINT subscriptiondependenciesproductfk FOREIGN KEY (productid) REFERENCES product(id) ON DELETE CASCADE;


--
-- Name: systemapplicationfkdeviceclass; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY systemapplication
    ADD CONSTRAINT systemapplicationfkdeviceclass FOREIGN KEY (deviceclass) REFERENCES deviceclass(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tagtreenodefkbasicpackage; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY basicpackage
    ADD CONSTRAINT tagtreenodefkbasicpackage FOREIGN KEY (tagtreenodeid) REFERENCES stbtagtreenode(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tagtreenodeidfkstbtagtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY timezone
    ADD CONSTRAINT tagtreenodeidfkstbtagtreenode FOREIGN KEY (tagtreenodeid) REFERENCES stbtagtreenode(id) ON DELETE CASCADE;


--
-- Name: titlei18nfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitem
    ADD CONSTRAINT titlei18nfk FOREIGN KEY (titlei18n) REFERENCES i18n(i18nid);


--
-- Name: treeidfkstbtagtreenode; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY stbtagtreenode
    ADD CONSTRAINT treeidfkstbtagtreenode FOREIGN KEY (treeid) REFERENCES stbtagtree(id) ON DELETE CASCADE;


--
-- Name: userdesktopfkaccount; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY userdesktop
    ADD CONSTRAINT userdesktopfkaccount FOREIGN KEY (accountid) REFERENCES account(accountid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: userdesktopfkdesktop; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY userdesktop
    ADD CONSTRAINT userdesktopfkdesktop FOREIGN KEY (desktopid) REFERENCES desktop(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: userdesktopfkdesktopitem; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY desktopitem
    ADD CONSTRAINT userdesktopfkdesktopitem FOREIGN KEY (userdesktopid) REFERENCES userdesktop(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: userrolesfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY user_roles
    ADD CONSTRAINT userrolesfk FOREIGN KEY (role_name) REFERENCES role(name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoserveractionfkvideoserver; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoserveraction
    ADD CONSTRAINT videoserveractionfkvideoserver FOREIGN KEY (videoserverid) REFERENCES videoserver(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoserverchannelstatusfkvideoserverstatus; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoserverstreamstatus
    ADD CONSTRAINT videoserverchannelstatusfkvideoserverstatus FOREIGN KEY (videoserverstatusid) REFERENCES videoserverstatus(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoservercontentfkvideoserver; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoservercontent
    ADD CONSTRAINT videoservercontentfkvideoserver FOREIGN KEY (videoserverid) REFERENCES videoserver(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoserverdevicetypefkdevicetype; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoserverdevicetype
    ADD CONSTRAINT videoserverdevicetypefkdevicetype FOREIGN KEY (devicetypeid) REFERENCES devicetype(devicetypeid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoserverdevicetypefkvideoserver; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoserverdevicetype
    ADD CONSTRAINT videoserverdevicetypefkvideoserver FOREIGN KEY (videoserverid) REFERENCES videoserver(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoserverfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoservergroupvideoserver
    ADD CONSTRAINT videoserverfk FOREIGN KEY (videoserverid) REFERENCES videoserver(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoserverfkvideoserverstatus; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoserverstatus
    ADD CONSTRAINT videoserverfkvideoserverstatus FOREIGN KEY (videoserverid) REFERENCES videoserver(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoservergroupfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoservergroupvideoserver
    ADD CONSTRAINT videoservergroupfk FOREIGN KEY (videoservergroupid) REFERENCES videoservergroup(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoservergroupfk; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoservergroupchanneldataplayinfo
    ADD CONSTRAINT videoservergroupfk FOREIGN KEY (videoservergroupid) REFERENCES videoservergroup(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoserverswisstvfkvideoserver; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoserverswisstv
    ADD CONSTRAINT videoserverswisstvfkvideoserver FOREIGN KEY (id) REFERENCES videoserver(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoservervodkaticketsfkvideoserver; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoservervodkatickets
    ADD CONSTRAINT videoservervodkaticketsfkvideoserver FOREIGN KEY (id) REFERENCES videoserver(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: videoserverwowzafkvideoserver; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY videoserverwowza
    ADD CONSTRAINT videoserverwowzafkvideoserver FOREIGN KEY (id) REFERENCES videoserver(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vouchervalidpackagefkbasicpackage; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY vouchervalidpackage
    ADD CONSTRAINT vouchervalidpackagefkbasicpackage FOREIGN KEY (packageid) REFERENCES basicpackage(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vouchervalidpackagefkvoucher; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY vouchervalidpackage
    ADD CONSTRAINT vouchervalidpackagefkvoucher FOREIGN KEY (voucherid) REFERENCES voucher(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vouchervalidproductfkproduct; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY vouchervalidproduct
    ADD CONSTRAINT vouchervalidproductfkproduct FOREIGN KEY (productid) REFERENCES product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vouchervalidproductfkvoucher; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY vouchervalidproduct
    ADD CONSTRAINT vouchervalidproductfkvoucher FOREIGN KEY (voucherid) REFERENCES voucher(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: welcomechannelfkchanneldata; Type: FK CONSTRAINT; Schema: public; Owner: tahiti
--

ALTER TABLE ONLY welcomechannel
    ADD CONSTRAINT welcomechannelfkchanneldata FOREIGN KEY (vodkatvchannelid) REFERENCES channeldata(vodkatvchannelid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

